package com.luxevaro.app.data.model

data class Product(
    val id: String,
    val title: String,
    val category: String,
    val price: Double,
    val priceFormatted: String,
    val currency: String = "USD",
    val image: String,
    val url: String,
    val inStock: Boolean = true,
    val rating: Double = 4.9,
    val reviewsCount: Int = 24,
    val freeShipping: Boolean = true,
    val dispatchDays: String = "1-2 Business Days",
    val isFeatured: Boolean = false,
    val isNewArrival: Boolean = false,
    val description: String = ""
)
