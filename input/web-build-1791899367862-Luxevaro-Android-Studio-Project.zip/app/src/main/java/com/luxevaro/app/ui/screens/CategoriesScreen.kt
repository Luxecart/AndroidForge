package com.luxevaro.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.luxevaro.app.data.model.Product
import com.luxevaro.app.data.repository.ProductRepository
import com.luxevaro.app.theme.*

@Composable
fun CategoriesScreen(
    navController: NavController,
    onProductClick: (Product) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("Home & Kitchen") }
    val categoryProducts = remember(selectedCategory) {
        ProductRepository.getProductsByCategory(selectedCategory)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(16.dp)
    ) {
        Text(
            text = "Categories",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(14.dp))

        ScrollableTabRow(
            selectedTabIndex = ProductRepository.categories.indexOf(selectedCategory).coerceAtLeast(0),
            containerColor = BackgroundDark,
            contentColor = GoldPrimary,
            edgePadding = 0.dp
        ) {
            ProductRepository.categories.forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = {
                        Text(
                            text = cat,
                            color = if (selectedCategory == cat) GoldPrimary else TextSecondary,
                            fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(categoryProducts) { product ->
                ProductListItem(product = product, onClick = { onProductClick(product) })
            }
        }
    }
}
