package com.luxevaro.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.luxevaro.app.theme.*

@Composable
fun AboutScreen(
    onBack: () -> Unit,
    onOpenWebsite: () -> Unit
) {
    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BackgroundDark)
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }
                Text("The Story of Luxevaro", fontFamily = FontFamily.Serif, fontSize = 18.sp, color = TextPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BackgroundDark)
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "The Story of Us",
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = GoldPrimary
            )

            Text(
                text = "1. Dispatch in less than 2 days, saving costs and time.\n\n" +
                       "2. High-quality products curated with rigorous scrutiny.\n\n" +
                       "3. No minimum order quantity (MOQ) requirement.\n\n" +
                       "4. Trending lifestyle products updated daily.\n\n" +
                       "5. Customer service managers on call 24 hours a day, 7 days a week.\n\n" +
                       "6. Fast express delivery worldwide across USA, UK, Canada, and UAE.\n\n" +
                       "7. World-renowned reputation and unequivocal customer compliment ratings.",
                color = TextSecondary,
                fontSize = 14.sp,
                lineHeight = 22.sp
            )

            Button(
                onClick = onOpenWebsite,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
            ) {
                Text("Visit Luxevaro.wed2c.com", color = BackgroundDark, fontWeight = FontWeight.Bold)
            }
        }
    }
}
