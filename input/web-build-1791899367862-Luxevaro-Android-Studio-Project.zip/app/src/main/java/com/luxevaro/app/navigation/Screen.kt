package com.luxevaro.app.navigation

sealed class Screen(val route: String, val title: String) {
    object Splash : Screen("splash", "Luxevaro")
    object Home : Screen("home", "Home")
    object Categories : Screen("categories", "Categories")
    object ProductDetails : Screen("product/{productId}", "Product Details") {
        fun createRoute(productId: String) = "product/$productId"
    }
    object Cart : Screen("cart", "Shopping Cart")
    object Wishlist : Screen("wishlist", "Wishlist")
    object Contact : Screen("contact", "Contact Us")
    object About : Screen("about", "About Luxevaro")
    object Shipping : Screen("shipping", "Orders & Shipping")
}
