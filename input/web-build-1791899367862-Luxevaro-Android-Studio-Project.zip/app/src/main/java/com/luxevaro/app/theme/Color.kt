package com.luxevaro.app.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF5E6BE)
val GoldDark = Color(0xFF997A15)
val BackgroundDark = Color(0xFF0A0A0B)
val CardDark = Color(0xFF141417)
val SurfaceDark = Color(0xFF1B1B20)
val TextPrimary = Color(0xFFEDEDED)
val TextSecondary = Color(0xFFA0A0A8)
val DividerDark = Color(0x33D4AF37)
val SuccessGreen = Color(0xFF4EBA6F)
val ErrorRed = Color(0xFFE55353)
