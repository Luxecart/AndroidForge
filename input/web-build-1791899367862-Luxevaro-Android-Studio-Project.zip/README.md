# Luxevaro - Native Android Shopping App

A luxury Android e-commerce application built with **Kotlin** and **Jetpack Compose**, integrated with the official **Luxevaro** online store (https://luxevaro.wed2c.com).

## Highlights
- **100% Jetpack Compose Material 3 UI**
- **Theme**: Luxury Black (#0A0A0B), White (#EDEDED), and Gold (#D4AF37)
- **Target Countries**: USA, UK, Canada, and UAE
- **Real Catalog & Pricing**: Direct sync with Luxevaro products
- **Safe Checkout**: Direct Chrome Custom Tabs integration to Luxevaro official product pages
- **Zero Fake Checkout**: Protects customer credentials

## Opening in Android Studio
1. Open Android Studio (Hedgehog 2023.1.1 or newer recommended)
2. Select **File > Open...** and choose this `android/` folder
3. Let Gradle sync dependencies
4. Run on any Android emulator or physical device running Android 8.0+ (API 26+)

## Tech Stack
- Kotlin 1.9.22
- Jetpack Compose BOM 2024.02.00
- Navigation Compose
- Coil Compose for asynchronous luxury image rendering
- AndroidX Browser (Chrome Custom Tabs for secure official checkout)
