export type Lang = 'ur-PK' | 'pa-IN' | 'en-US';
export interface Call { id: string; name: string; number: string; dir: 'in' | 'out' | 'missed'; startedAt: string; durationSec: number; summary: string; transcript: string[] }
export interface Contact { id: number; name: string; phone: string }
export interface Settings { aiName: string; lang: Lang; instructions: string; screening: 'off' | 'unknown' | 'spam'; recordConsent: boolean; analytics: boolean; phoneNumber: string }
export const DEFAULT_SETTINGS: Settings = {
  aiName: 'PakCall Assistant', lang: 'ur-PK',
  instructions: 'Greet politely, say you are an AI assistant, take a message, and keep replies short.',
  screening: 'unknown', recordConsent: false, analytics: false, phoneNumber: '',
};
export const LANGS: { id: Lang; label: string }[] = [
  { id: 'ur-PK', label: 'اردو Urdu' }, { id: 'pa-IN', label: 'ਪੰਜਾਬੀ Punjabi' }, { id: 'en-US', label: 'English' },
];
