import { Navigate, Route, Routes } from 'react-router-dom';
import { isFirebaseConfigured } from './lib/firebase';
import { ProtectedRoute, PublicOnlyRoute } from './auth/RouteGuards';
import Layout from './components/Layout';
import SetupRequired from './pages/SetupRequired';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import ForgotPassword from './pages/ForgotPassword';
import Home from './pages/Home';
import Assistant from './pages/Assistant';
import Calls from './pages/Calls';
import Contacts from './pages/Contacts';
import SettingsPage from './pages/Settings';

export default function App() {
  // Without credentials we never show a login form that cannot work.
  if (!isFirebaseConfigured) return <SetupRequired />;
  return (
    <Routes>
      <Route element={<PublicOnlyRoute />}>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/forgot" element={<ForgotPassword />} />
      </Route>
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/assistant" element={<Assistant />} />
          <Route path="/calls" element={<Calls />} />
          <Route path="/contacts" element={<Contacts />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
