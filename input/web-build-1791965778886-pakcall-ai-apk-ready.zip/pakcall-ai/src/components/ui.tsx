import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react';

const ICONS: Record<string, string> = {
  home: 'M3 11l9-8 9 8v10a1 1 0 01-1 1h-5v-7H9v7H4a1 1 0 01-1-1z',
  mic: 'M12 2a3 3 0 00-3 3v6a3 3 0 006 0V5a3 3 0 00-3-3zM5 11a7 7 0 0014 0M12 18v4',
  phone: 'M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z',
  users: 'M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM22 21v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8',
  gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1a7 7 0 00-2-1l-.5-2h-4L10 7a7 7 0 00-2 1L6 7 4 11l2 1v2l-2 1 2 4 2-1a7 7 0 002 1l.5 2h4L14 19a7 7 0 002-1l2 1 2-4-2-1z',
  shield: 'M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z',
  ban: 'M12 21a9 9 0 100-18 9 9 0 000 18zM5.6 5.6l12.8 12.8',
  trash: 'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',
  plus: 'M12 5v14M5 12h14',
};
export const Icon = ({ n }: { n: string }) => <svg className="i" viewBox="0 0 24 24" aria-hidden="true"><path d={ICONS[n]} /></svg>;
export const Spinner = () => <span className="spin" role="status" aria-label="Loading" />;

export function Banner({ kind, children }: { kind: 'w' | 'i' | 'e' | 's'; children: ReactNode }) {
  return <div className={'banner b-' + kind} role={kind === 'e' ? 'alert' : undefined}>{children}</div>;
}
export function Field({ label, error, ...p }: { label: string; error?: string } & InputHTMLAttributes<HTMLInputElement>) {
  return <div><label>{label}</label><input aria-invalid={!!error} {...p} />{error && <div className="err">{error}</div>}</div>;
}
export function Switch({ label, hint, checked, onChange, disabled }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return <div className="sw"><div><div>{label}</div>{hint && <div className="mut">{hint}</div>}</div><input type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} /></div>;
}
export function Modal({ title, children, onClose }: { title: string; children: ReactNode; onClose: () => void }) {
  return <div className="modal" onClick={onClose}><div role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}><h1>{title}</h1><div style={{ margin: '10px 0 16px' }}>{children}</div></div></div>;
}
export function Button({ loading, children, ...p }: { loading?: boolean; children: ReactNode } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...p} disabled={loading || p.disabled}>{loading && <Spinner />}{children}</button>;
}
