import { NavLink, Outlet } from 'react-router-dom';
import { Icon } from './ui';

const TABS: [string, string, string][] = [['/', 'Home', 'home'], ['/assistant', 'Assistant', 'mic'], ['/calls', 'Calls', 'phone'], ['/contacts', 'Contacts', 'users'], ['/settings', 'Settings', 'gear']];

export default function Layout() {
  return (
    <>
      <Outlet />
      <nav>{TABS.map(([to, label, icon]) => <NavLink key={to} to={to} end={to === '/'}><Icon n={icon} />{label}</NavLink>)}</nav>
    </>
  );
}
