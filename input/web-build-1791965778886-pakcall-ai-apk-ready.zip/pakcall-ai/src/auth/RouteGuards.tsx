import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { Spinner } from '../components/ui';

/** Only authenticated users may see child routes. */
export function ProtectedRoute() {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="center"><Spinner /></div>;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return <Outlet />;
}

/** Login / signup pages redirect away if already signed in. */
export function PublicOnlyRoute() {
  const { user, loading } = useAuth();
  if (loading) return <div className="center"><Spinner /></div>;
  if (user) return <Navigate to="/" replace />;
  return <Outlet />;
}
