import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import {
  EmailAuthProvider, createUserWithEmailAndPassword, deleteUser, onAuthStateChanged,
  reauthenticateWithCredential, sendEmailVerification, sendPasswordResetEmail,
  signInWithEmailAndPassword, signOut, updateProfile, type User,
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import { api, apiConfigured } from '../lib/api';

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  signUp(name: string, email: string, password: string): Promise<void>;
  signIn(email: string, password: string): Promise<void>;
  resetPassword(email: string): Promise<void>;
  resendVerification(): Promise<void>;
  logout(): Promise<void>;
  deleteAccount(password: string): Promise<void>;
}

const Ctx = createContext<AuthContextValue | null>(null);

function need() {
  if (!auth) throw new Error('Firebase is not configured.');
  return auth;
}

/**
 * Passwords are never stored by this app. They are sent over HTTPS directly to
 * Firebase Authentication, which stores only a salted, hashed credential.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [, bump] = useState(0);

  useEffect(() => {
    if (!auth) { setLoading(false); return; }
    return onAuthStateChanged(auth, (u) => { setUser(u); setLoading(false); });
  }, []);

  const value: AuthContextValue = {
    user, loading,
    async signUp(name, email, password) {
      const cred = await createUserWithEmailAndPassword(need(), email.trim(), password);
      await updateProfile(cred.user, { displayName: name.trim() });
      await sendEmailVerification(cred.user).catch(() => {});
      setUser(cred.user); bump((n) => n + 1);
    },
    async signIn(email, password) { await signInWithEmailAndPassword(need(), email.trim(), password); },
    async resetPassword(email) { await sendPasswordResetEmail(need(), email.trim()); },
    async resendVerification() {
      const u = need().currentUser; if (!u) throw new Error('Not signed in.');
      await sendEmailVerification(u);
    },
    async logout() { await signOut(need()); },
    async deleteAccount(password) {
      const u = need().currentUser; if (!u || !u.email) throw new Error('Not signed in.');
      await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, password));
      const uid = u.uid;
      if (apiConfigured) await api.deleteAccount();
      await deleteUser(u);
      try { Object.keys(localStorage).filter((k) => k.startsWith(`pc:${uid}:`)).forEach((k) => localStorage.removeItem(k)); } catch { /* ignore */ }
    },
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthContextValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>');
  return v;
}
