import { useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useCalls, useCloud } from '../lib/cloud';
import type { Call } from '../types';
import { Banner, Icon, Modal, Spinner } from '../components/ui';

export default function Calls() {
  const { user } = useAuth();
  const { calls, loading, error, cloud } = useCalls();
  const [sel, setSel] = useState<Call | null>(null);
  const { value: spam, set: setSpam } = useCloud<string[]>('spam', [], user!.uid);
  const dur = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  return (
    <div className="scr">
      <h1>Call history</h1>
      {!cloud && <Banner kind="w">Backend not connected. Calls handled by your AI phone line will appear here once the server and Twilio are set up (see README).</Banner>}
      {error && <Banner kind="e">{error}</Banner>}
      {loading && <div className="center" style={{ padding: 30 }}><Spinner /></div>}
      {!loading && !calls.length && !error && <p className="mut">No calls yet.</p>}
      {calls.map((c) => (
        <div className="card row" key={c.id} onClick={() => setSel(c)} style={{ cursor: 'pointer' }}>
          <div className="av">↙</div>
          <div className="grow"><div>{c.number || c.name} {spam.includes(c.id) && <span className="tag r">Reported spam</span>}</div><div className="mut">{new Date(c.startedAt).toLocaleString()}</div></div>
          <span className="mut">{dur(c.durationSec)}</span>
        </div>
      ))}
      {sel && (
        <Modal title={sel.number || sel.name} onClose={() => setSel(null)}>
          <p className="mut">{new Date(sel.startedAt).toLocaleString()} · {dur(sel.durationSec)}</p>
          <h2>Summary</h2><p>{sel.summary || 'Summary pending…'}</p>
          <h2>Transcript</h2>
          {sel.transcript.length ? sel.transcript.map((t, i) => <p key={i} className="mut" dir="auto" style={{ marginBottom: 6 }}>{t}</p>) : <p className="mut">No transcript.</p>}
          <div style={{ height: 14 }} />
          <button className="btn d" onClick={() => { if (!spam.includes(sel.id)) setSpam([...spam, sel.id]); setSel(null); }}><Icon n="ban" /> Report as spam</button>
          <p className="mut" style={{ marginTop: 8 }}>Marks this call in your account. It does not report to any carrier or authority.</p>
        </Modal>
      )}
    </div>
  );
}
