import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import { api, apiConfigured } from '../lib/api';
import { useCloud } from '../lib/cloud';
import { abortListening, listenOnce, speakText, stopSpeaking, voiceSupported } from '../lib/voice';
import { DEFAULT_SETTINGS, LANGS, type Settings } from '../types';
import { Banner, Icon, Modal, Spinner } from '../components/ui';

type Msg = { who: 'you' | 'ai' | 'sys'; t: string };

export default function Assistant() {
  const { user } = useAuth();
  const { value: s, set: setS, loading } = useCloud<Settings>('settings', DEFAULT_SETTINGS, user!.uid);
  const [log, setLog] = useState<Msg[]>([]);
  const [live, setLive] = useState('');
  const [active, setActive] = useState(false);
  const [phase, setPhase] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [ask, setAsk] = useState(false);
  const activeRef = useRef(false);
  const logRef = useRef<Msg[]>([]);
  const sRef = useRef(s);
  sRef.current = s;
  const noVoiceShown = useRef(false);

  const push = (m: Msg) => { logRef.current = [...logRef.current, m]; setLog(logRef.current); };

  async function handleFinal(text: string) {
    push({ who: 'you', t: text });
    setPhase('thinking');
    try {
      const history = logRef.current.filter((m) => m.who !== 'sys').slice(-12).map((m) => ({ role: m.who === 'you' ? ('user' as const) : ('assistant' as const), content: m.t }));
      const cur = sRef.current;
      const answer = await api.chat({ messages: history, lang: cur.lang, aiName: cur.aiName, instructions: cur.instructions });
      push({ who: 'ai', t: answer });
      setPhase('speaking');
      const spoken = await speakText(answer, cur.lang);
      if (!spoken && !noVoiceShown.current) {
        noVoiceShown.current = true;
        push({ who: 'sys', t: 'No voice for this language is installed on your device, so replies are shown as text only. Install an Urdu voice in Android text-to-speech settings.' });
      }
    } catch (e) {
      push({ who: 'sys', t: (e as Error).message });
    }
  }

  async function loop() {
    let empties = 0;
    while (activeRef.current) {
      setPhase('listening');
      let text = '';
      try { text = await listenOnce(sRef.current.lang, setLive); }
      catch (e) { push({ who: 'sys', t: (e as Error).message }); break; }
      setLive('');
      if (!activeRef.current) break;
      if (!text.trim()) {
        if (++empties >= 5) { push({ who: 'sys', t: 'I could not hear anything, so I stopped listening.' }); break; }
        await new Promise((r) => setTimeout(r, 300));
        continue;
      }
      empties = 0;
      await handleFinal(text.trim());
    }
    activeRef.current = false; setActive(false); setPhase('idle');
  }

  function begin() {
    if (!voiceSupported) { push({ who: 'sys', t: 'Speech recognition is not supported here or needs HTTPS. Try Chrome on Android or the Android app.' }); return; }
    activeRef.current = true; setActive(true); void loop();
  }
  function stop() { activeRef.current = false; void abortListening(); void stopSpeaking(); }
  const toggle = () => { if (active) stop(); else if (!s.recordConsent) setAsk(true); else begin(); };
  useEffect(() => () => { activeRef.current = false; void abortListening(); void stopSpeaking(); }, []);

  if (loading) return <div className="center"><Spinner /></div>;
  const label = { idle: 'Tap to start a voice conversation', listening: 'Listening… speak now', thinking: 'Thinking…', speaking: 'Speaking…' }[phase];
  return (
    <div className="scr">
      <h1>Voice assistant</h1>
      <Banner kind="i">🤖 You are talking with an AI assistant, not a human. Your speech is converted to text by your device’s speech service and sent to our server and an AI provider to generate replies.</Banner>
      {!apiConfigured && <Banner kind="w">Backend not connected: no AI reply can be generated. See README.</Banner>}
      <div className="chips">{LANGS.map((l) => <button key={l.id} className={'chip' + (s.lang === l.id ? ' on' : '')} disabled={active} onClick={() => setS({ ...s, lang: l.id })}>{l.label}</button>)}</div>
      <button className={'mic' + (active ? ' on' : '')} onClick={toggle} aria-label={active ? 'Stop conversation' : 'Start conversation'}><Icon n="mic" /></button>
      <p className="mut" style={{ textAlign: 'center' }}>{label}</p>
      <h2>Transcript</h2>
      <div className="card" style={{ minHeight: 120 }}>
        {!log.length && !live && <p className="mut">Nothing yet.</p>}
        {log.map((m, i) => <div key={i} className={'msg ' + m.who} dir="auto">{m.who === 'ai' && <b>AI: </b>}{m.t}</div>)}
        {live && <div className="msg you" style={{ opacity: 0.6 }} dir="auto">{live}</div>}
      </div>
      {!!log.length && !active && <button className="btn g s" onClick={() => { logRef.current = []; setLog([]); }}>Clear transcript</button>}
      {ask && (
        <Modal title="Consent" onClose={() => setAsk(false)}>
          <p className="mut">To talk with the AI, your spoken words are transcribed and the text is sent to our server and an AI provider to write replies. Transcripts shown here are not saved after you leave this screen. Do you agree?</p>
          <div style={{ height: 14 }} />
          <button className="btn" onClick={() => { setS({ ...s, recordConsent: true }); setAsk(false); begin(); }}>I agree</button>
          <div style={{ height: 8 }} />
          <button className="btn g" onClick={() => setAsk(false)}>Cancel</button>
        </Modal>
      )}
    </div>
  );
}
