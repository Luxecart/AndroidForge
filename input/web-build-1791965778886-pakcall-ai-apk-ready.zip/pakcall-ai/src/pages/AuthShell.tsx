import type { ReactNode } from 'react';
import { Icon } from '../components/ui';

export default function AuthShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="scr">
      <div style={{ textAlign: 'center', margin: '28px 0 22px' }}>
        <div className="av lg" style={{ margin: '0 auto 12px' }}><Icon n="phone" /></div>
        <h1>PakCall AI</h1>
        <p className="mut">Your AI calling assistant for Urdu, Punjabi & English</p>
      </div>
      <div className="card"><h2 style={{ marginTop: 0 }}>{title}</h2>{children}</div>
    </div>
  );
}
