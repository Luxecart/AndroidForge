import { useState, type ChangeEvent, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { authErrorMessage } from '../auth/authErrors';
import { validateEmail, validateName, validatePassword } from '../lib/validation';
import { Banner, Button, Field } from '../components/ui';
import AuthShell from './AuthShell';

export default function SignUp() {
  const { signUp } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', pw: '', pw2: '' });
  const [errs, setErrs] = useState<Record<string, string | undefined>>({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const up = (k: keyof typeof f) => (e: ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function submit(e: FormEvent) {
    e.preventDefault();
    const er = {
      name: validateName(f.name), email: validateEmail(f.email), pw: validatePassword(f.pw),
      pw2: f.pw2 === f.pw ? undefined : 'Passwords do not match',
    };
    setErrs(er); setMsg('');
    if (Object.values(er).some(Boolean)) return;
    setBusy(true);
    try { await signUp(f.name, f.email, f.pw); nav('/', { replace: true }); }
    catch (x) { setMsg(authErrorMessage(x)); setBusy(false); }
  }
  return (
    <AuthShell title="Create account">
      <form onSubmit={submit} noValidate>
        {msg && <Banner kind="e">{msg}</Banner>}
        <Field label="Full name" value={f.name} onChange={up('name')} error={errs.name} autoComplete="name" />
        <Field label="Email" type="email" value={f.email} onChange={up('email')} error={errs.email} autoComplete="email" inputMode="email" />
        <Field label="Password" type="password" value={f.pw} onChange={up('pw')} error={errs.pw} autoComplete="new-password" />
        <Field label="Confirm password" type="password" value={f.pw2} onChange={up('pw2')} error={errs.pw2} autoComplete="new-password" />
        <p className="mut" style={{ marginTop: 10 }}>We’ll email you a link to verify your address.</p>
        <div style={{ height: 14 }} />
        <Button className="btn" loading={busy}>{busy ? 'Creating account…' : 'Sign up'}</Button>
        <div style={{ marginTop: 14, fontSize: 13 }}><Link to="/login">Already have an account? Log in</Link></div>
      </form>
    </AuthShell>
  );
}
