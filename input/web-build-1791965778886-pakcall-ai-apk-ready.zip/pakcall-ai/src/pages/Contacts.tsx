import { useState, type FormEvent } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useCloud } from '../lib/cloud';
import { PK_PHONE_RE } from '../lib/validation';
import type { Contact } from '../types';
import { Field, Icon, Spinner } from '../components/ui';

export default function Contacts() {
  const { user } = useAuth();
  const { value: list, set: setList, loading } = useCloud<Contact[]>('contacts', [], user!.uid);
  const [n, setN] = useState('');
  const [p, setP] = useState('');
  const [er, setEr] = useState<{ n?: string; p?: string }>({});

  function add(e: FormEvent) {
    e.preventDefault();
    const x = {
      n: n.trim().length < 2 ? 'Enter a name' : undefined,
      p: PK_PHONE_RE.test(p.trim()) ? undefined : 'Use a Pakistani mobile e.g. 0300 1234567 or +92 300 1234567',
    };
    setEr(x);
    if (x.n || x.p) return;
    setList([...list, { id: Date.now(), name: n.trim(), phone: p.trim() }]);
    setN(''); setP('');
  }
  if (loading) return <div className="center"><Spinner /></div>;
  return (
    <div className="scr">
      <h1>Contacts</h1>
      <form className="card" onSubmit={add} noValidate>
        <Field label="Name" value={n} onChange={(e) => setN(e.target.value)} error={er.n} />
        <Field label="Phone" value={p} onChange={(e) => setP(e.target.value)} error={er.p} inputMode="tel" />
        <div style={{ height: 14 }} />
        <button className="btn"><Icon n="plus" /> Add contact</button>
      </form>
      {!list.length && <p className="mut">No contacts yet.</p>}
      {list.map((c) => (
        <div className="card row" key={c.id}>
          <div className="av">{c.name[0].toUpperCase()}</div>
          <div className="grow"><div>{c.name}</div><div className="mut">{c.phone}</div></div>
          <button className="btn g s" aria-label={`Delete ${c.name}`} onClick={() => setList(list.filter((x) => x.id !== c.id))}><Icon n="trash" /></button>
        </div>
      ))}
    </div>
  );
}
