import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useCalls, useCloud } from '../lib/cloud';
import { DEFAULT_SETTINGS, type Settings } from '../types';
import { Icon } from '../components/ui';

export default function Home() {
  const { user } = useAuth();
  const nav = useNavigate();
  const { value: s } = useCloud<Settings>('settings', DEFAULT_SETTINGS, user!.uid);
  const { calls, cloud } = useCalls();
  const linked = !!s.phoneNumber;
  const quick: [string, string, string][] = [['mic', 'Talk to AI', '/assistant'], ['phone', 'Call history', '/calls'], ['users', 'Contacts', '/contacts'], ['shield', 'Screening', '/settings']];
  return (
    <div className="scr">
      <p className="mut">Assalam o Alaikum,</p>
      <h1>{user!.displayName || user!.email}</h1>
      <div className="card" style={{ marginTop: 14 }}>
        <div className="row sp">
          <div><div className="mut">AI assistant</div><div style={{ fontSize: 18, fontWeight: 600 }}>{s.aiName}</div></div>
          <span className="tag"><span className="st" style={{ background: linked ? 'var(--ok)' : 'var(--warn)' }} />{linked ? 'Phone line linked' : 'No phone line'}</span>
        </div>
        <p className="mut" style={{ marginTop: 10 }}>{cloud ? (linked ? `Calls to ${s.phoneNumber} are answered by your AI.` : 'Voice chat is ready. Link a Twilio number in Settings to answer phone calls.') : 'Backend not connected: voice replies and calls are off. See README.'}</p>
      </div>
      <h2>Quick access</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {quick.map(([i, l, to]) => (
          <button key={l} className="card" onClick={() => nav(to)} style={{ color: 'var(--ac2)', cursor: 'pointer', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 8, margin: 0 }}>
            <Icon n={i} /><span style={{ color: 'var(--tx)', fontSize: 14 }}>{l}</span>
          </button>
        ))}
      </div>
      <h2>Recent calls</h2>
      {!calls.length && <p className="mut">No calls yet.</p>}
      {calls.slice(0, 3).map((c) => <div className="card row" key={c.id} onClick={() => nav('/calls')}><div className="av">{(c.number || '?')[1] || '?'}</div><div className="grow"><div>{c.number || c.name}</div><div className="mut">{c.summary || 'Summary pending…'}</div></div></div>)}
    </div>
  );
}
