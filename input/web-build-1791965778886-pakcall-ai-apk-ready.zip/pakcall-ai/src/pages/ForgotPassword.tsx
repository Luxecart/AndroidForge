import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { authErrorMessage } from '../auth/authErrors';
import { validateEmail } from '../lib/validation';
import { Banner, Button, Field } from '../components/ui';
import AuthShell from './AuthShell';

export default function ForgotPassword() {
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [err, setErr] = useState<string>();
  const [msg, setMsg] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const er = validateEmail(email); setErr(er); setMsg('');
    if (er) return;
    setBusy(true);
    try { await resetPassword(email); setSent(true); }
    catch (x) {
      const code = (x as { code?: string }).code;
      // Don't reveal whether an account exists.
      if (code === 'auth/user-not-found') setSent(true); else setMsg(authErrorMessage(x));
    }
    setBusy(false);
  }
  return (
    <AuthShell title="Reset password">
      {sent ? <Banner kind="s">If an account exists for {email.trim()}, a reset link is on its way. Check your inbox and spam folder.</Banner> : (
        <form onSubmit={submit} noValidate>
          {msg && <Banner kind="e">{msg}</Banner>}
          <Field label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={err} autoComplete="email" inputMode="email" />
          <div style={{ height: 16 }} />
          <Button className="btn" loading={busy}>{busy ? 'Sending…' : 'Send reset link'}</Button>
        </form>
      )}
      <div style={{ marginTop: 14, fontSize: 13 }}><Link to="/login">Back to log in</Link></div>
    </AuthShell>
  );
}
