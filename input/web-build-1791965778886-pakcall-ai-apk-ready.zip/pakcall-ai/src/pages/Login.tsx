import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { authErrorMessage } from '../auth/authErrors';
import { validateEmail } from '../lib/validation';
import { Banner, Button, Field } from '../components/ui';
import AuthShell from './AuthShell';

export default function Login() {
  const { signIn } = useAuth();
  const nav = useNavigate();
  const from = (useLocation().state as { from?: string } | null)?.from ?? '/';
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [errs, setErrs] = useState<{ email?: string; pw?: string }>({});
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const er = { email: validateEmail(email), pw: pw ? undefined : 'Enter your password' };
    setErrs(er); setMsg('');
    if (er.email || er.pw) return;
    setBusy(true);
    try { await signIn(email, pw); nav(from, { replace: true }); }
    catch (x) { setMsg(authErrorMessage(x)); setBusy(false); }
  }
  return (
    <AuthShell title="Welcome back">
      <form onSubmit={submit} noValidate>
        {msg && <Banner kind="e">{msg}</Banner>}
        <Field label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errs.email} autoComplete="email" inputMode="email" />
        <Field label="Password" type="password" value={pw} onChange={(e) => setPw(e.target.value)} error={errs.pw} autoComplete="current-password" />
        <div style={{ height: 16 }} />
        <Button className="btn" loading={busy}>{busy ? 'Logging in…' : 'Log in'}</Button>
        <div className="row sp" style={{ marginTop: 14, fontSize: 13 }}>
          <Link to="/signup">Create account</Link><Link to="/forgot">Forgot password?</Link>
        </div>
      </form>
    </AuthShell>
  );
}
