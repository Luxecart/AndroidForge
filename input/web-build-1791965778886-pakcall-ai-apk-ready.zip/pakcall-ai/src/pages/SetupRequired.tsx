import { missingConfig } from '../lib/firebase';
import { Banner } from '../components/ui';

export default function SetupRequired() {
  return (
    <div className="scr">
      <h1>Firebase setup required</h1>
      <p className="mut">PakCall AI needs Firebase Authentication credentials before anyone can sign in. No fake login is provided.</p>
      <div style={{ height: 14 }} />
      <Banner kind="w">Missing or placeholder values:<br />{missingConfig.map((m) => <div key={m}><code>{m}</code></div>)}</Banner>
      <div className="card">
        <ol>
          <li>Open <b>console.firebase.google.com</b> and create a project.</li>
          <li><b>Build → Authentication → Get started → Sign-in method</b>, then enable <b>Email/Password</b>.</li>
          <li><b>Project settings → Your apps → Web (&lt;/&gt;)</b>, register an app, and copy the config.</li>
          <li>Copy <code>.env.example</code> to <code>.env.local</code> and paste the values.</li>
          <li><b>Authentication → Settings → Authorized domains</b>: add your hosting domain.</li>
          <li>Restart <code>npm run dev</code>.</li>
        </ol>
        <p className="mut">Full guide: README.md</p>
      </div>
    </div>
  );
}
