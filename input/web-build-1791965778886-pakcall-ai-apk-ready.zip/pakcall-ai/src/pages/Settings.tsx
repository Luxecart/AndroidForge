import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { authErrorMessage } from '../auth/authErrors';
import { useCloud } from '../lib/cloud';
import { api, apiConfigured } from '../lib/api';
import { DEFAULT_SETTINGS, LANGS, type Lang, type Settings } from '../types';
import { Banner, Button, Field, Modal, Spinner, Switch } from '../components/ui';

export default function SettingsPage() {
  const { user, logout, resendVerification, deleteAccount } = useAuth();
  const nav = useNavigate();
  const u = user!;
  const { value: s, set: setS, loading, error: saveErr } = useCloud<Settings>('settings', DEFAULT_SETTINGS, u.uid);
  const [num, setNum] = useState('');
  const [numMsg, setNumMsg] = useState<{ kind: 's' | 'e'; text: string } | null>(null);
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setS({ ...s, [k]: v });
  const [info, setInfo] = useState<{ kind: 's' | 'e'; text: string } | null>(null);
  const [busy, setBusy] = useState<'out' | 'verify' | 'del' | null>(null);
  const [del, setDel] = useState(false);
  const [pw, setPw] = useState('');
  const [delErr, setDelErr] = useState('');

  async function doLogout() { setBusy('out'); try { await logout(); nav('/login', { replace: true }); } catch (x) { setInfo({ kind: 'e', text: authErrorMessage(x) }); setBusy(null); } }
  async function doVerify() {
    setBusy('verify'); setInfo(null);
    try { await resendVerification(); setInfo({ kind: 's', text: 'Verification email sent. Check your inbox.' }); }
    catch (x) { setInfo({ kind: 'e', text: authErrorMessage(x) }); }
    setBusy(null);
  }
  async function doDelete(e: FormEvent) {
    e.preventDefault();
    if (!pw) { setDelErr('Enter your password to confirm'); return; }
    setBusy('del'); setDelErr('');
    try { await deleteAccount(pw); nav('/login', { replace: true }); }
    catch (x) { setDelErr(authErrorMessage(x)); setBusy(null); }
  }
  async function linkNumber(e: FormEvent) {
    e.preventDefault();
    if (!/^\+\d{8,15}$/.test(num.trim())) { setNumMsg({ kind: 'e', text: 'Use international format, e.g. +12025550123' }); return; }
    setBusy('verify'); setNumMsg(null);
    try { await api.linkNumber(num.trim()); set('phoneNumber', num.trim()); setNumMsg({ kind: 's', text: 'Number linked.' }); setNum(''); }
    catch (x) { setNumMsg({ kind: 'e', text: (x as Error).message }); }
    setBusy(null);
  }
  if (loading) return <div className="center"><Spinner /></div>;
  const created = u.metadata.creationTime ? new Date(u.metadata.creationTime).toLocaleDateString() : '—';

  return (
    <div className="scr">
      <h1>Settings</h1>
      <div className="card">
        <div className="row"><div className="av lg">{(u.displayName || u.email || '?')[0].toUpperCase()}</div>
          <div className="grow"><div style={{ fontSize: 18, fontWeight: 600 }}>{u.displayName || 'No name set'}</div><div className="mut">{u.email}</div></div></div>
        <div className="row sp" style={{ marginTop: 12 }}>
          <span className={'tag ' + (u.emailVerified ? 'ok' : 'r')}>{u.emailVerified ? 'Email verified' : 'Email not verified'}</span>
          <span className="mut">Member since {created}</span>
        </div>
        {!u.emailVerified && <div style={{ marginTop: 10 }}><Button className="btn g s" loading={busy === 'verify'} onClick={doVerify}>Resend verification email</Button></div>}
      </div>
      {info && <Banner kind={info.kind}>{info.text}</Banner>}

      <h2>Assistant</h2>
      <div className="card">
        <Field label="Assistant name" value={s.aiName} maxLength={30} onChange={(e) => set('aiName', e.target.value)} />
        <label>Language</label>
        <select value={s.lang} onChange={(e) => set('lang', e.target.value as Lang)}>{LANGS.map((l) => <option key={l.id} value={l.id}>{l.label}</option>)}</select>
        <label>Instructions</label>
        <textarea rows={4} value={s.instructions} onChange={(e) => set('instructions', e.target.value)} />
      </div>

      {saveErr && <Banner kind="e">Could not save settings: {saveErr}</Banner>}
      <h2>Phone line</h2>
      <div className="card">
        {!apiConfigured ? <p className="mut">Backend not connected, so phone calls are unavailable. See README.</p> : (
          <form onSubmit={linkNumber} noValidate>
            <p className="mut">Linked number: <b>{s.phoneNumber || 'none'}</b></p>
            <p className="mut" style={{ marginTop: 6 }}>Enter the Twilio number you own. Incoming calls to it will be answered by your AI, which announces it is an AI and that a transcript is saved.</p>
            {numMsg && <div style={{ marginTop: 10 }}><Banner kind={numMsg.kind}>{numMsg.text}</Banner></div>}
            <Field label="Twilio number" value={num} onChange={(e) => setNum(e.target.value)} inputMode="tel" placeholder="+12025550123" />
            <div style={{ height: 12 }} /><Button className="btn g" loading={busy === 'verify'}>Link number</Button>
          </form>
        )}
      </div>

      <h2>Call screening</h2>
      <div className="card">
        <label style={{ marginTop: 0 }}>Screen calls from</label>
        <select value={s.screening} onChange={(e) => set('screening', e.target.value as Settings['screening'])}>
          <option value="off">Nobody (off)</option><option value="unknown">Unknown numbers</option><option value="spam">Reported spam only</option>
        </select>
        <p className="mut" style={{ marginTop: 8 }}>Saved as a preference. The phone server does not enforce screening yet; every call to your linked number is answered.</p>
      </div>

      <h2>Privacy</h2>
      <div className="card">
        <Switch label="AI disclosure" hint="Always on. The assistant must say it is an AI." checked disabled onChange={() => {}} />
        <Switch label="Consent to transcription" hint="Required before voice chat starts" checked={s.recordConsent} onChange={(v) => set('recordConsent', v)} />
        <Switch label="Share anonymous usage data" checked={s.analytics} onChange={(v) => set('analytics', v)} />
        <p className="mut">Recording a phone call may need consent from every participant under applicable law. Get legal advice before launch.</p>
      </div>

      <h2>Account</h2>
      <Button className="btn g" loading={busy === 'out'} onClick={doLogout}>Log out</Button>
      <div style={{ height: 8 }} />
      <button className="btn d" onClick={() => setDel(true)}>Delete account</button>

      {del && (
        <Modal title="Delete account?" onClose={() => busy !== 'del' && setDel(false)}>
          <form onSubmit={doDelete} noValidate>
            <p className="mut">This permanently deletes your Firebase account and local data on this device. Enter your password to confirm.</p>
            {delErr && <div style={{ marginTop: 10 }}><Banner kind="e">{delErr}</Banner></div>}
            <Field label="Password" type="password" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
            <div style={{ height: 14 }} />
            <Button className="btn d" loading={busy === 'del'}>Delete permanently</Button>
            <div style={{ height: 8 }} />
            <button type="button" className="btn g" onClick={() => setDel(false)}>Cancel</button>
          </form>
        </Modal>
      )}
    </div>
  );
}
