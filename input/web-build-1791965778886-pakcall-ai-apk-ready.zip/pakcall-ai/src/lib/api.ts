import { auth } from './firebase';
import type { Call, Lang } from '../types';

const BASE = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '');
/** True when VITE_API_URL points at the PakCall server. */
export const apiConfigured = !!BASE;

async function call<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (!BASE) throw new Error('Backend not configured');
  const token = await auth?.currentUser?.getIdToken();
  if (!token) throw new Error('Not signed in');
  const res = await fetch(BASE + path, {
    ...init,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, ...(init.headers || {}) },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((body as { error?: string }).error || `Request failed (${res.status})`);
  return body as T;
}

export const api = {
  chat: (p: { messages: { role: 'user' | 'assistant'; content: string }[]; lang: Lang; aiName: string; instructions: string }) =>
    call<{ reply: string }>('/api/chat', { method: 'POST', body: JSON.stringify(p) }).then((r) => r.reply),
  getStore: <T,>(key: string) => call<{ data: T | null }>(`/api/store/${key}`).then((r) => r.data),
  putStore: (key: string, data: unknown) => call<{ ok: true }>(`/api/store/${key}`, { method: 'PUT', body: JSON.stringify({ data }) }),
  calls: () => call<{ calls: Call[] }>('/api/calls').then((r) => r.calls),
  linkNumber: (number: string) => call<{ ok: true }>('/api/number', { method: 'POST', body: JSON.stringify({ number }) }),
  deleteAccount: () => call<{ ok: true }>('/api/account', { method: 'DELETE' }),
};
