export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const PK_PHONE_RE = /^(\+92|0)3\d{2}[\s-]?\d{7}$/;

export function validateEmail(v: string): string | undefined {
  return EMAIL_RE.test(v.trim()) ? undefined : 'Enter a valid email address';
}
export function validatePassword(v: string): string | undefined {
  if (v.length < 8) return 'Use at least 8 characters';
  if (!/[A-Za-z]/.test(v) || !/\d/.test(v)) return 'Include at least one letter and one number';
  return undefined;
}
export function validateName(v: string): string | undefined {
  return v.trim().length >= 2 ? undefined : 'Enter your full name';
}
