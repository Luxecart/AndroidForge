import { useEffect, useRef, useState } from 'react';
import { api, apiConfigured } from './api';
import { useLocal } from './storage';
import type { Call } from '../types';

/**
 * Per-user data. Stored in Firestore via the backend when VITE_API_URL is set,
 * otherwise in this device's localStorage (and `cloud` is false).
 */
export function useCloud<T>(key: 'settings' | 'contacts' | 'spam', initial: T, uid: string) {
  const [local, setLocal] = useLocal<T>(`pc:${uid}:${key}`, initial);
  const [remote, setRemote] = useState<T>(initial);
  const [loading, setLoading] = useState(apiConfigured);
  const [error, setError] = useState('');
  const timer = useRef<number>();

  useEffect(() => {
    if (!apiConfigured) return;
    let dead = false;
    api.getStore<T>(key)
      .then((d) => {
        if (dead || d === null) return;
        const plain = typeof d === 'object' && !Array.isArray(d) && typeof initial === 'object';
        setRemote(plain ? ({ ...initial, ...d } as T) : d);
      })
      .catch((e: Error) => !dead && setError(e.message))
      .finally(() => !dead && setLoading(false));
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, uid]);

  const set = (v: T) => {
    if (!apiConfigured) { setLocal(v); return; }
    setRemote(v); setError('');
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => { api.putStore(key, v).catch((e: Error) => setError(e.message)); }, 500);
  };
  return { value: apiConfigured ? remote : local, set, loading, error, cloud: apiConfigured };
}

export function useCalls() {
  const [calls, setCalls] = useState<Call[]>([]);
  const [loading, setLoading] = useState(apiConfigured);
  const [error, setError] = useState('');
  useEffect(() => {
    if (!apiConfigured) return;
    api.calls().then(setCalls).catch((e: Error) => setError(e.message)).finally(() => setLoading(false));
  }, []);
  return { calls, loading, error, cloud: apiConfigured };
}
