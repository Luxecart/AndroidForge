import { Capacitor } from '@capacitor/core';
import { SpeechRecognition as NativeSR } from '@capacitor-community/speech-recognition';
import { TextToSpeech } from '@capacitor-community/text-to-speech';

/** Same API in the browser (Web Speech) and inside the Android app (Capacitor plugins). */
const native = Capacitor.isNativePlatform();
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const WebSR: any = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let webRec: any = null;

export const voiceSupported = native || !!WebSR;

/** Listen for one utterance. Resolves with the final text ('' if nothing heard or aborted). */
export async function listenOnce(lang: string, onInterim: (t: string) => void): Promise<string> {
  if (native) {
    const perm = await NativeSR.requestPermissions();
    if (perm.speechRecognition !== 'granted') throw new Error('Microphone permission was denied. Allow it in Android settings.');
    return new Promise<string>((resolve, reject) => {
      let last = '';
      const subs: { remove: () => Promise<void> }[] = [];
      const done = (fn: () => void) => { subs.forEach((s) => void s.remove()); fn(); };
      void (async () => {
        subs.push(await NativeSR.addListener('partialResults', (d) => { last = d.matches?.[0] ?? last; onInterim(last); }));
        subs.push(await NativeSR.addListener('listeningState', (d) => { if (d.status === 'stopped') done(() => resolve(last)); }));
        try { await NativeSR.start({ language: lang, partialResults: true, popup: false, maxResults: 1 }); }
        catch (e) { done(() => reject(e instanceof Error ? e : new Error('Speech recognition failed'))); }
      })();
    });
  }
  if (!WebSR) throw new Error('Speech recognition is not supported here or needs HTTPS. Try Chrome on Android.');
  return new Promise<string>((resolve, reject) => {
    const r = new WebSR();
    r.lang = lang; r.interimResults = true; r.continuous = false;
    let finalText = '';
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    r.onresult = (e: any) => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript as string;
        if (e.results[i].isFinal) finalText += t; else interim += t;
      }
      onInterim(interim);
    };
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    r.onerror = (e: any) => { if (e.error !== 'no-speech' && e.error !== 'aborted') reject(new Error('Microphone error: ' + e.error)); };
    r.onend = () => resolve(finalText);
    webRec = r;
    try { r.start(); } catch { resolve(''); }
  });
}

export async function abortListening(): Promise<void> {
  if (native) { try { await NativeSR.stop(); } catch { /* not running */ } }
  else webRec?.abort?.();
}

/** Speak text. Returns false if no voice exists for the language (caller should show text only). */
export async function speakText(text: string, lang: string): Promise<boolean> {
  if (native) {
    try {
      const { supported } = await TextToSpeech.isLanguageSupported({ lang });
      if (!supported) return false;
      await TextToSpeech.speak({ text, lang, rate: 1.0, pitch: 1.0, volume: 1.0 });
      return true;
    } catch { return false; }
  }
  const synth = window.speechSynthesis;
  if (!synth) return false;
  const voice = synth.getVoices().find((v) => v.lang.toLowerCase().startsWith(lang.split('-')[0].toLowerCase()));
  if (!voice) return false;
  return new Promise<boolean>((resolve) => {
    const u = new SpeechSynthesisUtterance(text);
    u.voice = voice; u.lang = voice.lang;
    u.onend = () => resolve(true); u.onerror = () => resolve(true);
    synth.speak(u);
  });
}

export async function stopSpeaking(): Promise<void> {
  if (native) { try { await TextToSpeech.stop(); } catch { /* idle */ } }
  else window.speechSynthesis?.cancel();
}
