import { getApps, initializeApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  appId: import.meta.env.VITE_FIREBASE_APP_ID as string | undefined,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
};

const REQUIRED = [
  ['apiKey', 'VITE_FIREBASE_API_KEY'],
  ['authDomain', 'VITE_FIREBASE_AUTH_DOMAIN'],
  ['projectId', 'VITE_FIREBASE_PROJECT_ID'],
  ['appId', 'VITE_FIREBASE_APP_ID'],
] as const;

/** Names of required env vars that are empty or still placeholders. */
export const missingConfig: string[] = REQUIRED.filter(([k]) => {
  const v = config[k];
  return !v || v.startsWith('your-');
}).map(([, env]) => env);

export const isFirebaseConfigured = missingConfig.length === 0;

/** null when credentials are missing: the app then shows setup instructions, never a fake login. */
export const auth: Auth | null = isFirebaseConfigured
  ? getAuth(getApps()[0] ?? initializeApp(config))
  : null;
