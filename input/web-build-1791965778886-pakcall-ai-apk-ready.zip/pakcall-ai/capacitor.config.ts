import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'pk.pakcall.ai',
  appName: 'PakCall AI',
  webDir: 'dist',
  backgroundColor: '#0a1128',
};
export default config;
