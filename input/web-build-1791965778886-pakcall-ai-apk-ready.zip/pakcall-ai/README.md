# PakCall AI

Web app (React + TypeScript + Vite) + backend (`server/`, Node + Express + TypeScript).

Features: Firebase email/password auth, protected dashboard, Urdu/Punjabi/English voice chat with AI replies,
cloud-saved settings/contacts/spam reports, call history with AI summaries, and an optional
Twilio phone line where an AI answers calls (announcing it is an AI).

> **Not tested end-to-end.** This code was written without network access or a live Firebase/Anthropic/Twilio account.
> Follow the steps, expect to fix small issues, and test every step. See "Known limits" below.

## Architecture
```
Phone (browser/PWA) --Firebase ID token--> Server (Cloud Run) --> Anthropic API (AI replies)
                                                |--> Firestore (settings, contacts, calls)
Caller --> Twilio number --webhook--> Server /twilio/* (speech in, AI reply, speech out)
```
Secrets (Anthropic key, Twilio token, Firebase Admin) live ONLY on the server.

## 1. Firebase (auth + database)
1. console.firebase.google.com -> create project.
2. Authentication -> Sign-in method -> enable Email/Password.
3. Firestore Database -> Create database (production mode). Deploy `firestore.rules` (denies all client access;
   only the server, using the Admin SDK, reads/writes): `firebase deploy --only firestore:rules`.
4. Project settings -> Your apps -> Web -> copy config into `.env.local` (see `.env.example`).
5. Project settings -> Service accounts -> Generate new private key (for local server runs only).
6. Authentication -> Settings -> Authorized domains: add your deployed web domain.

## 2. Anthropic API key
console.anthropic.com -> API keys -> create key. Put it in `server/.env` as `ANTHROPIC_API_KEY`. Set a spend limit.

## 3. Run locally
```bash
# terminal 1: server
cd server && cp .env.example .env     # fill ANTHROPIC_API_KEY and FIREBASE_SERVICE_ACCOUNT_JSON (JSON on one line)
npm install && npm run dev            # http://localhost:8080/health

# terminal 2: web app
cp .env.example .env.local            # fill Firebase values; VITE_API_URL=http://localhost:8080
npm install && npm run dev
```
Register, verify your email (the server requires a verified email for AI use; set `REQUIRE_VERIFIED_EMAIL=false` to relax),
open Assistant, tap the mic.

## 4. Deploy
- **Server (Cloud Run):** `cd server && gcloud run deploy pakcall-api --source . --region <region> --allow-unauthenticated`
  and set env vars (`ANTHROPIC_API_KEY`, `ALLOWED_ORIGINS=https://your-web-domain`, `PUBLIC_URL=https://<cloud-run-url>`,
  `TWILIO_AUTH_TOKEN`). On Cloud Run leave `FIREBASE_SERVICE_ACCOUNT_JSON` empty and give the service account the
  "Cloud Datastore User" role. Add a Dockerfile or use buildpacks (`npm run build` then `npm start`).
- **Web:** set `VITE_API_URL` to the server URL, `npm run build`, `firebase deploy --only hosting` (public dir `dist`, SPA rewrite on).

## 5. Phone calls via Twilio (optional, paid)
1. Create a Twilio account and buy a voice-capable number. Check which countries/number types are available; a
   Pakistani (+92) number may not be offered, in which case callers reach your Twilio number via forwarding.
2. Number config -> Voice: "A call comes in" -> Webhook `POST https://<server>/twilio/voice`;
   "Call status changes" -> `POST https://<server>/twilio/status`.
3. Put the Twilio Auth Token in `TWILIO_AUTH_TOKEN` and the server URL in `PUBLIC_URL` (needed to validate Twilio's signature).
4. In the app: Settings -> Phone line -> enter the Twilio number (+E.164) -> Link number.
5. Call the Twilio number from another phone. You should hear the AI disclosure, then talk to it. The call and a summary appear in Calls.
6. To cover your own SIM: set conditional call forwarding (busy / no answer / unreachable) to the Twilio number using
   your carrier's feature (often `**61*<number>#` style GSM codes; confirm with your carrier). Forwarding is a carrier
   feature; the app cannot do it for you, and carrier charges may apply.

## Known limits (be honest with users)
- Twilio `<Say>` voice support for Urdu is configured via `TWILIO_VOICE_UR`; **verify the voice name exists in Twilio's current docs**.
  Pakistani Punjabi (Shahmukhi) has no mainstream TTS/STT; Punjabi mode uses Urdu speech on phone calls.
- Browser voice replies need an Urdu/Punjabi text-to-speech voice installed on the phone; otherwise replies show as text.
- Android cannot let a normal app answer SIM calls directly. This design uses forwarding to Twilio.
- Call screening setting is saved but not enforced by the server yet.
- Spam "reports" are flags in your own account, not reports to any carrier or authority.
- Audio is not stored; transcripts and summaries are stored in Firestore. Callers are told this at the start of each call.
- Legal: recording/transcribing calls and AI-disclosure rules vary. Get Pakistani legal advice, write a privacy policy,
  and review Anthropic/Twilio/Google data-processing terms before public launch.
- No automated tests are included yet.

## Security notes
- Passwords are handled only by Firebase Auth (hashed server-side by Google). Never store them yourself.
- Every `/api` request verifies the Firebase ID token; Twilio webhooks verify Twilio's signature.
- Per-user rate limits on AI chat; `REQUIRE_VERIFIED_EMAIL` limits abuse. Input lengths are validated with zod.
- Restrict the Firebase browser API key by HTTP referrer in Google Cloud Console.

## 6. Android APK (Capacitor)
The web app is wrapped as a native Android app. Voice uses native Android speech recognition and text-to-speech
plugins (`src/lib/voice.ts`), because the browser Web Speech API is unreliable inside an Android WebView.

> Not built or tested here (no Android SDK). The first run may need fixes. Plugin version numbers in `package.json`
> should be checked against the Capacitor 6 compatibility notes of each plugin.

### Option A: build in the cloud with GitHub (no Android Studio)
1. Create a GitHub repository and push this project to the `main` branch.
2. Repo -> Settings -> Secrets and variables -> Actions -> New repository secret. Add:
   `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_APP_ID`,
   `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_STORAGE_BUCKET`, and `VITE_API_URL`
   (**public https URL of your deployed server**; `localhost` will not work on a phone).
3. On the server set `ALLOWED_ORIGINS` to include `https://localhost` (the origin of the Android app) as well as your web domain,
   e.g. `https://your-web-domain,https://localhost`. Redeploy the server.
4. Repo -> Actions -> "Build Android APK" -> Run workflow. When it finishes (about 5-10 minutes), open the run and
   download the artifact `pakcall-ai-debug-apk` (a zip containing `app-debug.apk`).
5. Send `app-debug.apk` to your phone, open it, and allow "Install unknown apps" for that source when asked.

### Option B: build on your computer
Install Node 20, JDK 17 and Android Studio, create `.env.local`, then:
```bash
npm install && npm run build
npx cap add android
# add to android/app/src/main/AndroidManifest.xml (before <application>):
#   <uses-permission android:name="android.permission.RECORD_AUDIO" />
#   <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
# and before </manifest>:
#   <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>
npx cap sync android
npx cap open android      # Android Studio -> Build -> Build APK(s)
```

### Notes
- This is a **debug** APK (debug-signed): fine for your own testing, **not** for Google Play. For Play Store you need a
  release keystore, a signed AAB, a privacy policy, and a Data Safety form.
- Speech recognition on Android uses Google's speech service on the device; Urdu support depends on the phone and may need
  the Urdu language pack downloaded. Punjabi (Pakistan) recognition may be poor or unavailable.
- Voice replies need an installed text-to-speech voice for the language; otherwise replies show as text only.
