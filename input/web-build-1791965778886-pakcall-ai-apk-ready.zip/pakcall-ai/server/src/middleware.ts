import type { NextFunction, Request, Response } from 'express';
import { adminAuth } from './lib/firebase';
import { config } from './config';

declare module 'express-serve-static-core' {
  interface Request { uid?: string }
}

/** Verifies the Firebase ID token sent by the web app. */
export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const d = await adminAuth.verifyIdToken(token);
    if (config.requireVerifiedEmail && !d.email_verified) return res.status(403).json({ error: 'Please verify your email first.' });
    req.uid = d.uid;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}
