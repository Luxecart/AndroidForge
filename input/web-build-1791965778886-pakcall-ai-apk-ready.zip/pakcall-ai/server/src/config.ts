import 'dotenv/config';

function required(k: string): string {
  const v = process.env[k];
  if (!v) throw new Error(`Missing required environment variable ${k}. See server/.env.example`);
  return v;
}

export const config = {
  port: Number(process.env.PORT || 8080),
  allowedOrigins: (process.env.ALLOWED_ORIGINS || 'http://localhost:5173').split(',').map((s) => s.trim()),
  anthropicKey: required('ANTHROPIC_API_KEY'),
  model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
  requireVerifiedEmail: process.env.REQUIRE_VERIFIED_EMAIL !== 'false',
  serviceAccountJson: process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '',
  twilioToken: process.env.TWILIO_AUTH_TOKEN || '',
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/$/, ''),
  voiceEn: process.env.TWILIO_VOICE_EN || 'Polly.Joanna',
  voiceUr: process.env.TWILIO_VOICE_UR || 'Google.ur-IN-Standard-A',
};
