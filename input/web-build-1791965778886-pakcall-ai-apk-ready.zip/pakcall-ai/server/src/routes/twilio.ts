import { Router, type NextFunction, type Request, type Response } from 'express';
import twilio from 'twilio';
import { config } from '../config';
import { adminAuth, db } from '../lib/firebase';
import { buildSystem, reply, summarize, type Lang } from '../lib/ai';

/**
 * Phone-call handling via Twilio Programmable Voice.
 * NOT TESTED against a live Twilio account. Verify end-to-end before relying on it.
 * Callers call (or forward to) your Twilio number; this server answers, discloses the AI,
 * listens (speech-to-text), replies with Claude, speaks (text-to-speech), and saves a transcript.
 */
const r = Router();
const MAX_TURNS = 8;
const STT: Record<Lang, string> = { 'en-US': 'en-US', 'ur-PK': 'ur-PK', 'pa-IN': 'ur-PK' }; // Pakistani Punjabi: use Urdu STT/TTS (verify)

const DISCLOSURE: Record<'en' | 'ur', (n: string, o: string) => string> = {
  en: (n, o) => `Hello. This is ${n}, an A I assistant answering for ${o}. This call is handled by artificial intelligence and a written transcript will be saved. If you do not agree, please hang up now. How can I help you?`,
  ur: (n, o) => `السلام علیکم۔ میں ${n} ہوں، ${o} کی طرف سے کال سنبھالنے والا اے آئی اسسٹنٹ۔ یہ کال مصنوعی ذہانت سنبھال رہی ہے اور گفتگو کی تحریری نقل محفوظ کی جائے گی۔ اگر آپ متفق نہیں تو براہ کرم کال بند کر دیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟`,
};

function guard(req: Request, res: Response, next: NextFunction) {
  const sig = req.header('X-Twilio-Signature') || '';
  if (!config.twilioToken || !config.publicUrl || !twilio.validateRequest(config.twilioToken, sig, config.publicUrl + req.originalUrl, req.body)) {
    return res.status(403).send('Forbidden');
  }
  next();
}
const xml = (res: Response, vr: twilio.twiml.VoiceResponse) => res.type('text/xml').send(vr.toString());
const voiceFor = (l: Lang) => (l === 'en-US' ? config.voiceEn : config.voiceUr);

function say(vr: twilio.twiml.VoiceResponse, lang: Lang, text: string) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  vr.say({ voice: voiceFor(lang), language: lang === 'en-US' ? 'en-US' : 'ur-IN' } as any, text);
}
function listen(vr: twilio.twiml.VoiceResponse, lang: Lang) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  vr.gather({ input: ['speech'], language: STT[lang], speechTimeout: 'auto', action: '/twilio/turn', method: 'POST' } as any);
}

r.post('/voice', guard, async (req, res) => {
  const { To, From, CallSid } = req.body as Record<string, string>;
  const vr = new twilio.twiml.VoiceResponse();
  const num = await db.doc(`numbers/${To}`).get();
  if (!num.exists) { vr.say('This number is not configured.'); vr.hangup(); return xml(res, vr); }
  const uid = num.data()!.uid as string;
  const [settingsSnap, owner] = await Promise.all([db.doc(`users/${uid}/store/settings`).get(), adminAuth.getUser(uid)]);
  const s = (settingsSnap.data()?.data || {}) as { aiName?: string; lang?: Lang; instructions?: string };
  const lang: Lang = s.lang || 'ur-PK';
  const aiName = s.aiName || 'PakCall Assistant';
  const ownerName = owner.displayName || 'the account owner';
  await db.doc(`users/${uid}/calls/${CallSid}`).set({
    from: From, to: To, startedAt: new Date().toISOString(), status: 'in-progress', messages: [], turns: 0, empty: 0, lang, aiName, instructions: s.instructions || '', ownerName,
  });
  say(vr, lang, (lang === 'en-US' ? DISCLOSURE.en : DISCLOSURE.ur)(aiName, ownerName));
  listen(vr, lang);
  xml(res, vr);
});

r.post('/turn', guard, async (req, res) => {
  const { To, CallSid, SpeechResult } = req.body as Record<string, string>;
  const vr = new twilio.twiml.VoiceResponse();
  const num = await db.doc(`numbers/${To}`).get();
  if (!num.exists) { vr.hangup(); return xml(res, vr); }
  const ref = db.doc(`users/${num.data()!.uid}/calls/${CallSid}`);
  const snap = await ref.get();
  if (!snap.exists) { vr.hangup(); return xml(res, vr); }
  const c = snap.data()!;
  const lang = c.lang as Lang;
  const text = (SpeechResult || '').trim().slice(0, 500);

  if (!text) {
    if (c.empty >= 1) { say(vr, lang, lang === 'en-US' ? 'I could not hear you. Goodbye.' : 'مجھے آپ کی آواز سنائی نہیں دی۔ اللہ حافظ۔'); vr.hangup(); return xml(res, vr); }
    await ref.update({ empty: c.empty + 1 });
    say(vr, lang, lang === 'en-US' ? 'Sorry, I did not catch that. Please say it again.' : 'معذرت، میں سن نہیں سکا۔ براہ کرم دوبارہ کہیں۔');
    listen(vr, lang);
    return xml(res, vr);
  }

  const messages = [...(c.messages as { role: string; text: string }[]), { role: 'caller', text }];
  try {
    const history = messages.map((m) => ({ role: m.role === 'caller' ? ('user' as const) : ('assistant' as const), content: m.text }));
    const system = buildSystem({ aiName: c.aiName, lang, instructions: c.instructions, channel: 'phone', ownerName: c.ownerName });
    const answer = await reply(system, history);
    messages.push({ role: 'assistant', text: answer });
    const turns = c.turns + 1;
    await ref.update({ messages, turns });
    say(vr, lang, answer);
    if (turns >= MAX_TURNS) { say(vr, lang, lang === 'en-US' ? 'I have noted your message. Goodbye.' : 'میں نے آپ کا پیغام نوٹ کر لیا ہے۔ اللہ حافظ۔'); vr.hangup(); }
    else listen(vr, lang);
  } catch (e) {
    console.error('turn failed', (e as Error).message);
    say(vr, lang, lang === 'en-US' ? 'Sorry, something went wrong. Please call again later.' : 'معذرت، کچھ مسئلہ ہو گیا ہے۔ براہ کرم بعد میں کال کریں۔');
    vr.hangup();
  }
  xml(res, vr);
});

// Configure this URL as the number's "Call status changes" webhook in Twilio.
r.post('/status', guard, async (req, res) => {
  const { To, CallSid, CallStatus, CallDuration } = req.body as Record<string, string>;
  res.sendStatus(204);
  if (!['completed', 'busy', 'no-answer', 'failed', 'canceled'].includes(CallStatus)) return;
  const num = await db.doc(`numbers/${To}`).get();
  if (!num.exists) return;
  const ref = db.doc(`users/${num.data()!.uid}/calls/${CallSid}`);
  const snap = await ref.get();
  if (!snap.exists) return;
  const msgs = (snap.data()!.messages || []) as { role: string; text: string }[];
  let summary = msgs.length ? '' : 'No conversation.';
  if (msgs.length) { try { summary = await summarize(msgs.map((m) => `${m.role}: ${m.text}`)); } catch { summary = 'Summary unavailable.'; } }
  await ref.update({ status: CallStatus, durationSec: Number(CallDuration || 0), summary });
});

export default r;
