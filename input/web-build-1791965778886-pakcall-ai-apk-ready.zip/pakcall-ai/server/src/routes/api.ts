import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { db } from '../lib/firebase';
import { buildSystem, reply } from '../lib/ai';

const r = Router();

const chatLimiter = rateLimit({ windowMs: 60_000, limit: 20, keyGenerator: (req) => req.uid || req.ip || 'x', standardHeaders: true, legacyHeaders: false });

const ChatBody = z.object({
  messages: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().min(1).max(1000) })).min(1).max(20),
  lang: z.enum(['ur-PK', 'pa-IN', 'en-US']),
  aiName: z.string().max(30).default('PakCall Assistant'),
  instructions: z.string().max(800).default(''),
});

r.post('/chat', chatLimiter, async (req, res) => {
  const p = ChatBody.safeParse(req.body);
  if (!p.success || p.data.messages[p.data.messages.length - 1].role !== 'user') return res.status(400).json({ error: 'Invalid request' });
  try {
    const system = buildSystem({ ...p.data, channel: 'app' });
    res.json({ reply: await reply(system, p.data.messages) });
  } catch (e) {
    console.error('chat failed', (e as Error).message);
    res.status(502).json({ error: 'The AI service is unavailable. Try again.' });
  }
});

const KEYS = ['settings', 'contacts', 'spam'] as const;
const keyOk = (k: string): k is (typeof KEYS)[number] => (KEYS as readonly string[]).includes(k);
const storeDoc = (uid: string, key: string) => db.doc(`users/${uid}/store/${key}`);

r.get('/store/:key', async (req, res) => {
  if (!keyOk(req.params.key)) return res.status(404).json({ error: 'Unknown key' });
  const s = await storeDoc(req.uid!, req.params.key).get();
  res.json({ data: s.exists ? s.data()!.data : null });
});

r.put('/store/:key', async (req, res) => {
  if (!keyOk(req.params.key)) return res.status(404).json({ error: 'Unknown key' });
  const data = req.body?.data;
  if (data === undefined || JSON.stringify(data).length > 100_000) return res.status(400).json({ error: 'Invalid data' });
  await storeDoc(req.uid!, req.params.key).set({ data, updatedAt: new Date().toISOString() });
  res.json({ ok: true });
});

r.get('/calls', async (req, res) => {
  const snap = await db.collection(`users/${req.uid}/calls`).orderBy('startedAt', 'desc').limit(50).get();
  res.json({
    calls: snap.docs.map((d) => {
      const c = d.data();
      return {
        id: d.id, name: 'Unknown', number: c.from || '', dir: 'in', startedAt: c.startedAt,
        durationSec: c.durationSec || 0, summary: c.summary || '',
        transcript: (c.messages || []).map((m: { role: string; text: string }) => `${m.role === 'caller' ? 'Caller' : 'Assistant'}: ${m.text}`),
      };
    }),
  });
});

// Link a Twilio number you own to this account so incoming calls route to your assistant.
r.post('/number', async (req, res) => {
  const p = z.object({ number: z.string().regex(/^\+\d{8,15}$/) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Use international format, e.g. +12025550123' });
  const ref = db.doc(`numbers/${p.data.number}`);
  const ok = await db.runTransaction(async (t) => {
    const s = await t.get(ref);
    if (s.exists && s.data()!.uid !== req.uid) return false;
    t.set(ref, { uid: req.uid });
    return true;
  });
  if (!ok) return res.status(409).json({ error: 'That number is already linked to another account.' });
  res.json({ ok: true });
});

r.delete('/account', async (req, res) => {
  const uid = req.uid!;
  await db.recursiveDelete(db.doc(`users/${uid}`));
  const nums = await db.collection('numbers').where('uid', '==', uid).get();
  await Promise.all(nums.docs.map((d) => d.ref.delete()));
  res.json({ ok: true });
});

export default r;
