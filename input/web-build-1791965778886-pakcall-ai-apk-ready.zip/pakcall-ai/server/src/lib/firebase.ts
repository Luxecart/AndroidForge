import { applicationDefault, cert, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { config } from '../config';

if (!getApps().length) {
  initializeApp({
    credential: config.serviceAccountJson ? cert(JSON.parse(config.serviceAccountJson)) : applicationDefault(),
  });
}
export const adminAuth = getAuth();
export const db = getFirestore();
