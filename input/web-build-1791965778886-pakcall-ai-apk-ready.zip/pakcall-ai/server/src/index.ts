import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import { requireAuth } from './middleware';
import api from './routes/api';
import twilioRoutes from './routes/twilio';

const app = express();
app.set('trust proxy', 1);
app.use(helmet());

app.get('/health', (_req, res) => res.json({ ok: true }));

// Twilio webhooks: form-encoded, authenticated by Twilio signature.
app.use('/twilio', express.urlencoded({ extended: false }), twilioRoutes);

// Web app API: JSON, authenticated by Firebase ID token.
app.use('/api',
  cors({ origin: config.allowedOrigins }),
  rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }),
  express.json({ limit: '200kb' }),
  requireAuth,
  api);

app.listen(config.port, () => console.log(`PakCall server listening on :${config.port}`));
