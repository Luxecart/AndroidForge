# AI Call Assistant for Vivo Smartphones (Android 15)

A professional Android application built with **Kotlin**, **Jetpack Compose (Material3)**, **Android Telecom APIs**, and **Google Gemini Real-Time Voice Intelligence**.

---

## 1. Architectural Architecture & Telecom Reality

### Android Telecom Architecture
```
                                 [ Incoming Cellular / SIM Call ]
                                                │
                                                ▼
                                   [ Android Telecom Subsystem ]
                                                │
                     ┌──────────────────────────┴──────────────────────────┐
                     ▼                                                     ▼
    [ AssistantCallScreeningService ]                            [ Emergency Detector ]
    - Evaluates caller before ringing                            - PhoneNumberUtils.isEmergencyNumber
    - Pre-ring spam disallow                                     - Emergency callback property check
    - VIP pass-through                                           - BYPASSES AI IMMEDIATELY
                     │
                     ▼
         [ AssistantInCallService ] (RoleManager.ROLE_DIALER)
         - Receives onCallAdded() callback
         - Evaluates user response mode (Busy / Sleep / Custom)
         - Runs configurable auto-answer delay coroutine
         - Calls call.answer(VideoProfile.STATE_AUDIO_ONLY)
         - Routes audio via CallAudioState.ROUTE_SPEAKER
                     │
                     ▼
             [ CallAgentEngine ]
             - Bi-directional dialog manager (Urdu & English)
             - Android SpeechRecognizer / Audio Record loop
             - Secure backend communication with Gemini Flash & Live API
             - Android TextToSpeech / Gemini TTS playback
             - Real-time transcription in ActiveCallScreen
                     │
                     ▼
        [ Call Summarization & Storage ]
        - Generates structured summary, sentiment, urgency rating
        - Stores in-app encrypted DataStore / Room cache
        - Notifies user via foreground summary channel
```

### Critical Android Audio & Telecom Restrictions (Technical Reality)
1. **Audio Capture Isolation on Cellular SIM Calls**:
   - Starting with Android 9 (Pie) and strictly enforced in Android 14 and 15, Android security architecture restricts third-party non-system apps from tapping the direct hardware up-link and down-link audio streams of cellular SIM calls (`MediaRecorder.AudioSource.VOICE_CALL` or `VOICE_DOWNLINK` throws a SecurityException unless granted signature/system permissions).
   - **Legitimate Implementation Implemented Here**:
     - The app requests and holds the **Default Phone App** role (`RoleManager.ROLE_DIALER`), which allows legitimate call state handling and `call.answer()` / `call.disconnect()`.
     - Audio routing is switched to `CallAudioState.ROUTE_SPEAKER` (or a paired Bluetooth SCO / virtual loopback headset), allowing the microphone (`AudioRecord`) to capture caller audio and the speaker (`AudioTrack` / `TextToSpeech`) to deliver the AI response.
     - For VoIP calls (SIP, WebRTC, WhatsApp/Telegram integration), Android provides direct bidirectional PCM streams without cellular baseband hardware isolation.
2. **Emergency Call Safety Guarantee**:
   - The application checks `PhoneNumberUtils.isEmergencyNumber()` and `call.details.hasProperty(Call.Details.PROPERTY_EMERGENCY_CALLBACK_MODE)` before applying any AI rules. Emergency calls are NEVER delayed, blocked, or intercepted by the AI voice assistant.

---

## 2. Capabilities Breakdown

| Feature | Status | Requirement |
|---|---|---|
| InCallService Call Lifecycle | **Confirmed & Implemented** | Default Phone App Role (`ROLE_DIALER`) |
| CallScreeningService Pre-Ring Filter | **Confirmed & Implemented** | `ROLE_CALL_SCREENING` |
| Configurable Auto-Answer Delay | **Confirmed & Implemented** | Coroutines + `call.answer()` |
| Gemini Voice Intelligence (Urdu & English) | **Confirmed & Implemented** | Secure Backend + Internet |
| Emergency Call Safety Bypass | **Confirmed & Implemented** | Local Telecom check |
| On-Device Privacy & History Wipe | **Confirmed & Implemented** | DataStore / Local storage |
| Cellular SIM Direct In-Band Audio Injection | **Hardware/OEM Dependent** | Requires Speaker routing, Bluetooth SCO, or Carrier Call Screening API |

---

## 3. Vivo FuntouchOS 15 & OriginOS 5 Optimization Guide

Vivo devices aggressively terminate background processes to conserve battery. To ensure the assistant stays active:
1. **Allow Unrestricted Battery**: Go to *Settings -> Battery -> Background power consumption management -> AI Call Assistant -> Allow high background power consumption*.
2. **Autostart Authorization**: Open *Vivo iManager -> Permission Management -> Autostart -> Enable AI Call Assistant*.
3. **Lock in Multitasking**: Open the Recent Apps tray, tap the options icon on the AI Call Assistant card, and select **Lock**.

---

## 4. Build & Testing Instructions

### Requirements
- Android Studio Ladybug (2024.2+) or Meerkat
- JDK 17 or JDK 21
- Android SDK 35 (Android 15)

### Steps to Build
1. Open Android Studio -> **Open an Existing Project** -> Select the `android/` directory.
2. Allow Gradle sync to complete using the provided `libs.versions.toml` version catalog.
3. Connect a Vivo smartphone running Android 15 (with Developer Options and USB Debugging enabled) or start an Android 15 Emulator.
4. Run `./gradlew test` to execute all unit tests in `CallRulesEngineTest.kt`.
5. Run `./gradlew assembleDebug` or click **Run 'app'** in Android Studio.
6. On first launch, tap **Set as Default Phone App** to authorize `InCallService`.
7. Tap **Test Incoming Call Simulation** on the dashboard to test the real-time call screening, auto-answer timer, and conversational voice dialog!
