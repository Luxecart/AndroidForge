package com.aicallassistant

import com.aicallassistant.data.model.ContactRule
import com.aicallassistant.data.model.ContactRuleType
import org.junit.Assert.*
import org.junit.Test

class CallRulesEngineTest {

    @Test
    fun testEmergencyNumberSafety_neverIntercepted() {
        val emergencyNumbers = listOf("112", "911", "15", "999", "1122")
        for (number in emergencyNumbers) {
            val isEmergency = isSimulatedEmergency(number)
            assertTrue("Emergency number $number must always be marked as emergency!", isEmergency)
        }

        val normalNumber = "+923001234567"
        assertFalse("Normal caller must not be treated as emergency", isSimulatedEmergency(normalNumber))
    }

    @Test
    fun testVipContactBypass_directRing() {
        val rules = listOf(
            ContactRule("1", "Mom", "+923001234567", ContactRuleType.VIP_BYPASS_AI),
            ContactRule("2", "Spam", "+923009999999", ContactRuleType.BLOCK_CALLER)
        )

        val caller = "+923001234567"
        val matchedRule = rules.find { it.phoneNumber == caller }

        assertNotNull(matchedRule)
        assertEquals(ContactRuleType.VIP_BYPASS_AI, matchedRule?.ruleType)
    }

    @Test
    fun testBlockedContact_rejection() {
        val rules = listOf(
            ContactRule("1", "Mom", "+923001234567", ContactRuleType.VIP_BYPASS_AI),
            ContactRule("2", "Spam", "+923009999999", ContactRuleType.BLOCK_CALLER)
        )

        val spamCaller = "+923009999999"
        val isBlocked = rules.any { it.phoneNumber == spamCaller && it.ruleType == ContactRuleType.BLOCK_CALLER }

        assertTrue("Spam number must be blocked", isBlocked)
    }

    @Test
    fun testUrduLanguageDetectionHeuristic() {
        val urduUtterance = "السلام علیکم، کیا حال ہے؟"
        val romanUrduUtterance = "Salam, kya haal hai? Main Ali bol raha hoon."
        val englishUtterance = "Hello, I am calling regarding our project meeting."

        assertTrue("Should detect Urdu script", detectsUrdu(urduUtterance))
        assertTrue("Should detect Roman Urdu keywords", detectsUrdu(romanUrduUtterance))
        assertFalse("Should not detect Urdu in English sentence", detectsUrdu(englishUtterance))
    }

    private fun isSimulatedEmergency(number: String): Boolean {
        val emergencyList = setOf("112", "911", "15", "999", "1122", "110", "119")
        return emergencyList.contains(number.trim())
    }

    private fun detectsUrdu(text: String): Boolean {
        // Arabic/Urdu unicode block range: 0600 - 06FF
        val hasUrduChars = text.any { it.code in 0x0600..0x06FF }
        if (hasUrduChars) return true

        val lower = text.lowercase()
        val romanUrduKeywords = listOf("salam", "kya", "hoon", "bol", "aap", "kaun", "theek", "shukriya")
        return romanUrduKeywords.any { lower.contains(it) }
    }
}
