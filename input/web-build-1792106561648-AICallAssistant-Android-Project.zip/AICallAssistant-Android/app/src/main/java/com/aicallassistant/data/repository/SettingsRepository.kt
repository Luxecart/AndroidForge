package com.aicallassistant.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.aicallassistant.data.model.AssistantSettings
import com.aicallassistant.data.model.ContactRule
import com.aicallassistant.data.model.ContactRuleType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking

private val Context.dataStore by preferencesDataStore(name = "assistant_settings")

class SettingsRepository private constructor(private val context: Context) {

    companion object {
        @Volatile
        private var instance: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
        }

        private val KEY_ENABLED = booleanPreferencesKey("assistant_enabled")
        private val KEY_MODE = stringPreferencesKey("call_mode")
        private val KEY_DELAY = intPreferencesKey("auto_answer_delay")
        private val KEY_NAME = stringPreferencesKey("assistant_name")
        private val KEY_OWNER = stringPreferencesKey("owner_name")
        private val KEY_LANG = stringPreferencesKey("language_preference")
        private val KEY_GREETING_EN = stringPreferencesKey("greeting_en")
        private val KEY_GREETING_UR = stringPreferencesKey("greeting_ur")
        private val KEY_ALLOWED_TOPICS = stringPreferencesKey("allowed_topics")
        private val KEY_FORBIDDEN_TOPICS = stringPreferencesKey("forbidden_topics")
        private val KEY_URGENT_RULES = stringPreferencesKey("urgent_rules")
        private val KEY_PERSONALITY = stringPreferencesKey("personality")
    }

    private val inMemoryContactRules = MutableStateFlow<List<ContactRule>>(
        listOf(
            ContactRule("1", "Family / Mom", "+923001234567", ContactRuleType.VIP_BYPASS_AI, "Immediate direct ring"),
            ContactRule("2", "Delivery Courier", "+923219876543", ContactRuleType.AI_STANDARD_HANDLE, "Collect package drop instructions"),
            ContactRule("3", "Known Spam Telemarketer", "+923450000000", ContactRuleType.BLOCK_CALLER, "Auto-rejected")
        )
    )

    val settingsFlow: Flow<AssistantSettings> = context.dataStore.data.map { pref ->
        AssistantSettings(
            isAssistantEnabled = pref[KEY_ENABLED] ?: true,
            mode = pref[KEY_MODE] ?: "BUSY",
            autoAnswerDelaySeconds = pref[KEY_DELAY] ?: 2,
            assistantName = pref[KEY_NAME] ?: "Aura",
            ownerName = pref[KEY_OWNER] ?: "Muhammad Jahangir",
            languagePreference = pref[KEY_LANG] ?: "ur",
            greetingEn = pref[KEY_GREETING_EN] ?: "Hello! I am the AI Call Assistant for Muhammad Jahangir. He is currently occupied. Please state how I may help you?",
            greetingUr = pref[KEY_GREETING_UR] ?: "السلام علیکم! میں محمد جہانگیر کا اے آئی کال اسسٹنٹ ہوں۔ وہ اس وقت مصروف ہیں۔ فرمائیے آپ کا کیا کام ہے؟",
            allowedTopics = pref[KEY_ALLOWED_TOPICS] ?: "Taking messages, scheduling appointments, urgent callback requests, general polite inquiries",
            forbiddenTopics = pref[KEY_FORBIDDEN_TOPICS] ?: "Bank account numbers, OTPs, financial details, passwords, exact home GPS address, private travel itinerary",
            urgentRules = pref[KEY_URGENT_RULES] ?: "If medical or danger emergency, advise immediate call to emergency services (112 / 15 / 911).",
            personality = pref[KEY_PERSONALITY] ?: "Polite, helpful, concise, reassuring, and articulate"
        )
    }

    fun getSettingsSnapshot(): AssistantSettings {
        return runBlocking { settingsFlow.first() }
    }

    suspend fun updateSettings(settings: AssistantSettings) {
        context.dataStore.edit { pref ->
            pref[KEY_ENABLED] = settings.isAssistantEnabled
            pref[KEY_MODE] = settings.mode
            pref[KEY_DELAY] = settings.autoAnswerDelaySeconds
            pref[KEY_NAME] = settings.assistantName
            pref[KEY_OWNER] = settings.ownerName
            pref[KEY_LANG] = settings.languagePreference
            pref[KEY_GREETING_EN] = settings.greetingEn
            pref[KEY_GREETING_UR] = settings.greetingUr
            pref[KEY_ALLOWED_TOPICS] = settings.allowedTopics
            pref[KEY_FORBIDDEN_TOPICS] = settings.forbiddenTopics
            pref[KEY_URGENT_RULES] = settings.urgentRules
            pref[KEY_PERSONALITY] = settings.personality
        }
    }

    suspend fun setAssistantEnabled(enabled: Boolean) {
        context.dataStore.edit { pref ->
            pref[KEY_ENABLED] = enabled
        }
    }

    suspend fun setMode(mode: String) {
        context.dataStore.edit { pref ->
            pref[KEY_MODE] = mode
        }
    }

    fun getContactRules(): Flow<List<ContactRule>> = inMemoryContactRules

    fun addContactRule(rule: ContactRule) {
        inMemoryContactRules.value = inMemoryContactRules.value + rule
    }

    fun removeContactRule(ruleId: String) {
        inMemoryContactRules.value = inMemoryContactRules.value.filter { it.id != ruleId }
    }

    fun isNumberBlocked(phoneNumber: String): Boolean {
        val normalized = phoneNumber.filter { it.isDigit() }
        return inMemoryContactRules.value.any { rule ->
            rule.ruleType == ContactRuleType.BLOCK_CALLER &&
                    rule.phoneNumber.filter { it.isDigit() }.endsWith(normalized.takeLast(7))
        }
    }

    fun isNumberVip(phoneNumber: String): Boolean {
        val normalized = phoneNumber.filter { it.isDigit() }
        return inMemoryContactRules.value.any { rule ->
            rule.ruleType == ContactRuleType.VIP_BYPASS_AI &&
                    rule.phoneNumber.filter { it.isDigit() }.endsWith(normalized.takeLast(7))
        }
    }
}
