package com.aicallassistant

import android.Manifest
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aicallassistant.ai.CallAgentEngine
import com.aicallassistant.data.repository.CallHistoryRepository
import com.aicallassistant.data.repository.SettingsRepository
import com.aicallassistant.telecom.CallAssistantStatus
import com.aicallassistant.telecom.CallStateManager
import com.aicallassistant.ui.call.ActiveCallScreen
import com.aicallassistant.ui.contacts.ContactRulesScreen
import com.aicallassistant.ui.dashboard.DashboardScreen
import com.aicallassistant.ui.history.CallHistoryScreen
import com.aicallassistant.ui.instructions.CustomInstructionsScreen
import com.aicallassistant.ui.settings.SettingsScreen
import com.aicallassistant.ui.setup.PermissionWizardScreen
import com.aicallassistant.ui.setup.VivoSetupGuideScreen
import com.aicallassistant.ui.theme.AICallAssistantTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val requestRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Trigger recomposition by updating role check
    }

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AICallAssistantTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    val settingsRepo = remember { SettingsRepository.getInstance(applicationContext) }
                    val historyRepo = remember { CallHistoryRepository.getInstance(applicationContext) }

                    val settings by settingsRepo.settingsFlow.collectAsState(initial = settingsRepo.getSettingsSnapshot())
                    val recentCalls by historyRepo.getCallHistory().collectAsState(initial = emptyList())
                    val contactRules by settingsRepo.getContactRules().collectAsState(initial = emptyList())
                    val activeCallState by CallStateManager.uiState.collectAsState()

                    val isDefaultDialer = isAppDefaultDialer()
                    val isVivoOptimized = isVivoOptimized()

                    val hasRecordAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    val hasPhonePermissions = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
                            ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
                    val hasContactsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
                    val hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                    } else true

                    val isAllPermissionsGranted = isDefaultDialer && hasRecordAudio && hasPhonePermissions && hasNotificationPermission

                    // Auto navigate to in-call screen when ringing or active
                    LaunchedEffect(activeCallState.status) {
                        if (activeCallState.status == CallAssistantStatus.RINGING ||
                            activeCallState.status == CallAssistantStatus.AUTO_ANSWERING_PENDING ||
                            activeCallState.status == CallAssistantStatus.ACTIVE_AI_HANDLING
                        ) {
                            navController.navigate("active_call") {
                                launchSingleTop = true
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = if (isAllPermissionsGranted) "dashboard" else "permissions"
                    ) {
                        composable("dashboard") {
                            DashboardScreen(
                                settings = settings,
                                recentCalls = recentCalls,
                                isDefaultDialer = isDefaultDialer,
                                isVivoOptimized = isVivoOptimized,
                                onToggleAssistant = { enabled ->
                                    lifecycleScope.launch { settingsRepo.setAssistantEnabled(enabled) }
                                },
                                onSelectMode = { mode ->
                                    lifecycleScope.launch { settingsRepo.setMode(mode) }
                                },
                                onNavigateToCallTest = {
                                    startSimulatedIncomingCall()
                                },
                                onNavigateToInstructions = { navController.navigate("instructions") },
                                onNavigateToContacts = { navController.navigate("contacts") },
                                onNavigateToVivoGuide = { navController.navigate("vivo_guide") },
                                onNavigateToHistory = { navController.navigate("history") },
                                onNavigateToSettings = { navController.navigate("settings") },
                                onNavigateToPermissions = { navController.navigate("permissions") }
                            )
                        }

                        composable("active_call") {
                            ActiveCallScreen(
                                state = activeCallState,
                                onTakeOver = {
                                    CallStateManager.updateStatus(CallAssistantStatus.USER_MANUAL_TAKEOVER)
                                },
                                onToggleSpeaker = {
                                    CallStateManager.updateAudioRoute(
                                        if (activeCallState.isSpeakerOn) 1 else 8
                                    )
                                },
                                onToggleMute = {
                                    // toggle mute state
                                },
                                onEndCall = {
                                    CallStateManager.getCall()?.disconnect()
                                    CallStateManager.updateStatus(CallAssistantStatus.DISCONNECTED)
                                    CallAgentEngine.stopVoiceSession()
                                    lifecycleScope.launch {
                                        CallAgentEngine.saveCompletedCallSummary(applicationContext)
                                        delay(1000)
                                        CallStateManager.reset()
                                        navController.popBackStack()
                                    }
                                },
                                onSendSimulatedSpeech = { text ->
                                    CallAgentEngine.processCallerSpeech(applicationContext, text)
                                }
                            )
                        }

                        composable("instructions") {
                            CustomInstructionsScreen(
                                currentSettings = settings,
                                onSave = { updated ->
                                    lifecycleScope.launch { settingsRepo.updateSettings(updated) }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("contacts") {
                            ContactRulesScreen(
                                contactRules = contactRules,
                                onAddRule = { rule -> settingsRepo.addContactRule(rule) },
                                onDeleteRule = { ruleId -> settingsRepo.removeContactRule(ruleId) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("history") {
                            CallHistoryScreen(
                                callLogs = recentCalls,
                                onDeleteCall = { id -> historyRepo.deleteCallLog(id) },
                                onClearAll = { historyRepo.clearAllHistory() },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("settings") {
                            SettingsScreen(
                                settings = settings,
                                isDefaultDialer = isDefaultDialer,
                                onRequestDefaultDialerRole = { requestDefaultDialerRole() },
                                onNavigateToVivoGuide = { navController.navigate("vivo_guide") },
                                onUpdateSettings = { updated ->
                                    lifecycleScope.launch { settingsRepo.updateSettings(updated) }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("vivo_guide") {
                            VivoSetupGuideScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable("permissions") {
                            PermissionWizardScreen(
                                isDefaultDialer = isDefaultDialer,
                                hasRecordAudio = hasRecordAudio,
                                hasPhonePermissions = hasPhonePermissions,
                                hasContactsPermission = hasContactsPermission,
                                hasNotificationPermission = hasNotificationPermission,
                                isVivoOptimized = isVivoOptimized,
                                onRequestAllPermissions = { requestAllPermissions() },
                                onRequestDefaultDialer = { requestDefaultDialerRole() },
                                onRequestAudio = {
                                    requestPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                                },
                                onRequestPhoneState = {
                                    requestPermissionsLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.READ_PHONE_STATE,
                                            Manifest.permission.ANSWER_PHONE_CALLS,
                                            Manifest.permission.CALL_PHONE,
                                            Manifest.permission.READ_CALL_LOG
                                        )
                                    )
                                },
                                onRequestContacts = {
                                    requestPermissionsLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
                                },
                                onRequestNotifications = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        requestPermissionsLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                                    }
                                },
                                onRequestVivoOptimization = { requestVivoOptimization() },
                                onFinish = { navController.navigate("dashboard") }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun isAppDefaultDialer(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as? RoleManager
            roleManager?.isRoleHeld(RoleManager.ROLE_DIALER) ?: false
        } else {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            telecomManager?.defaultDialerPackage == packageName
        }
    }

    private fun isVivoOptimized(): Boolean {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        return powerManager?.isIgnoringBatteryOptimizations(packageName) ?: false
    }

    private fun requestAllPermissions() {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())

        if (!isAppDefaultDialer()) {
            requestDefaultDialerRole()
        }
    }

    private fun requestVivoOptimization() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        } catch (_: Exception) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                startActivity(intent)
            } catch (_: Exception) {}
        }
    }

    private fun requestDefaultDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
                requestRoleLauncher.launch(intent)
            }
        } else {
            val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
            }
            startActivity(intent)
        }
    }

    private fun startSimulatedIncomingCall() {
        CallStateManager.reset()
        CallStateManager.setCallerInfo("+92 300 4819203", "Muhammad Asad (Simulated Call)")
        CallStateManager.updateStatus(CallAssistantStatus.RINGING)

        lifecycleScope.launch {
            val settings = SettingsRepository.getInstance(applicationContext).getSettingsSnapshot()
            val delaySeconds = settings.autoAnswerDelaySeconds

            CallStateManager.updateStatus(CallAssistantStatus.AUTO_ANSWERING_PENDING)
            for (i in delaySeconds downTo 1) {
                CallStateManager.updateCountdown(i)
                delay(1000)
            }

            // Auto answer transition
            CallStateManager.updateStatus(CallAssistantStatus.ACTIVE_AI_HANDLING)
            val greeting = if (settings.languagePreference == "ur") settings.greetingUr else settings.greetingEn
            CallStateManager.addTranscript("AI Assistant", greeting, isUrdu = settings.languagePreference == "ur")

            // Simulate call duration counter
            var sec = 0
            while (CallStateManager.uiState.value.status == CallAssistantStatus.ACTIVE_AI_HANDLING) {
                CallStateManager.setDuration(sec++)
                delay(1000)
            }
        }
    }
}
