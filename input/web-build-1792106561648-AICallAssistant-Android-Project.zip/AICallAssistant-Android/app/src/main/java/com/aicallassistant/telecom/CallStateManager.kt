package com.aicallassistant.telecom

import android.telecom.Call
import android.telecom.CallAudioState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class CallAssistantStatus {
    IDLE,
    RINGING,
    AUTO_ANSWERING_PENDING,
    ACTIVE_AI_HANDLING,
    USER_MANUAL_TAKEOVER,
    DISCONNECTED
}

data class ActiveCallUiState(
    val status: CallAssistantStatus = CallAssistantStatus.IDLE,
    val callerNumber: String = "",
    val callerName: String? = null,
    val callDurationSeconds: Int = 0,
    val isAutoAnswerActive: Boolean = false,
    val remainingAutoAnswerCountdown: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = false,
    val currentAudioRoute: Int = CallAudioState.ROUTE_EARPIECE,
    val conversationTranscript: List<TranscriptEntry> = emptyList(),
    val latestAgentThought: String? = null,
    val isEmergencyDetected: Boolean = false
)

data class TranscriptEntry(
    val sender: String, // "Caller" or "AI Assistant"
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isUrdu: Boolean = false
)

object CallStateManager {
    private val _uiState = MutableStateFlow(ActiveCallUiState())
    val uiState: StateFlow<ActiveCallUiState> = _uiState.asStateFlow()

    private var currentActiveCall: Call? = null

    fun setCall(call: Call?) {
        currentActiveCall = call
    }

    fun getCall(): Call? = currentActiveCall

    fun updateStatus(status: CallAssistantStatus) {
        _uiState.update { it.copy(status = status) }
    }

    fun setCallerInfo(number: String, name: String?) {
        _uiState.update { it.copy(callerNumber = number, callerName = name) }
    }

    fun updateCountdown(remainingSec: Int) {
        _uiState.update { it.copy(remainingAutoAnswerCountdown = remainingSec) }
    }

    fun setDuration(seconds: Int) {
        _uiState.update { it.copy(callDurationSeconds = seconds) }
    }

    fun updateAudioRoute(route: Int) {
        _uiState.update {
            it.copy(
                currentAudioRoute = route,
                isSpeakerOn = (route and CallAudioState.ROUTE_SPEAKER) != 0
            )
        }
    }

    fun addTranscript(sender: String, message: String, isUrdu: Boolean = false) {
        _uiState.update {
            val list = it.conversationTranscript + TranscriptEntry(sender, message, isUrdu = isUrdu)
            it.copy(conversationTranscript = list)
        }
    }

    fun setEmergency(isEmergency: Boolean) {
        _uiState.update { it.copy(isEmergencyDetected = isEmergency) }
    }

    fun reset() {
        currentActiveCall = null
        _uiState.value = ActiveCallUiState()
    }
}
