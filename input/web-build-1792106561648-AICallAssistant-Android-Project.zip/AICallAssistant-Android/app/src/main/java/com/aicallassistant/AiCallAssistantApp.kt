package com.aicallassistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class AiCallAssistantApp : Application() {

    companion object {
        const val CHANNEL_CALL_SERVICE = "ai_call_service_channel"
        const val CHANNEL_CALL_SUMMARY = "ai_call_summary_channel"
        lateinit var instance: AiCallAssistantApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val serviceChannel = NotificationChannel(
                CHANNEL_CALL_SERVICE,
                getString(R.string.channel_call_service),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.channel_call_service_desc)
                setShowBadge(true)
            }

            val summaryChannel = NotificationChannel(
                CHANNEL_CALL_SUMMARY,
                getString(R.string.channel_call_summary),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.channel_call_summary_desc)
            }

            notificationManager.createNotificationChannel(serviceChannel)
            notificationManager.createNotificationChannel(summaryChannel)
        }
    }
}
