package com.aicallassistant.ai

import com.aicallassistant.ai.models.CallSummary
import com.aicallassistant.ai.models.ConversationMessage
import com.aicallassistant.ai.models.ConverseRequest
import com.aicallassistant.ai.models.ConverseResponse
import com.aicallassistant.ai.models.SummarizeRequest
import kotlinx.coroutines.flow.StateFlow

sealed interface VoiceServiceState {
    object Idle : VoiceServiceState
    object Connecting : VoiceServiceState
    object Ready : VoiceServiceState
    object Streaming : VoiceServiceState
    data class Error(val message: String, val canRetry: Boolean) : VoiceServiceState
}

/**
 * Android AI Voice Service interface.
 * Decouples telephony call handling from the underlying speech and intelligence backend.
 * Protects Google Gemini API credentials by routing strictly through secure server proxies.
 */
interface AiVoiceService {
    val state: StateFlow<VoiceServiceState>

    /**
     * Sends caller speech turn to the AI backend and returns conversational response
     */
    suspend fun processTurn(request: ConverseRequest): Result<ConverseResponse>

    /**
     * Synthesizes text into audio data (Urdu or English)
     */
    suspend fun synthesizeAudio(text: String, language: String): Result<ByteArray>

    /**
     * Generates structured post-call summary and urgency analysis
     */
    suspend fun summarizeCall(request: SummarizeRequest): Result<CallSummary>

    /**
     * Terminates any active audio streams or WebSocket connections
     */
    fun release()
}
