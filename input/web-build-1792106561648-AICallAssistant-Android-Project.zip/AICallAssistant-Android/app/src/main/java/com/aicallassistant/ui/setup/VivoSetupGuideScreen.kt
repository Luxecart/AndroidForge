package com.aicallassistant.ui.setup

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.ui.theme.*

@Composable
fun VivoSetupGuideScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val powerManager = remember { context.getSystemService(Context.POWER_SERVICE) as PowerManager }
    val isIgnoringBatteryOptimizations = remember {
        powerManager.isIgnoringBatteryOptimizations(context.packageName)
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text("Vivo Smartphone Optimization", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = VivoBlue.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = VivoBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Vivo FuntouchOS 15 & OriginOS 5", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = VivoBlue)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Vivo applies aggressive background process termination (via iManager). Follow these 4 critical steps to ensure AI Call Assistant is never killed when your screen is locked.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            item {
                VivoStepItem(
                    stepNumber = "1",
                    title = "Battery Optimization Whitelist",
                    description = "Request Android system exemption to allow continuous background Telecom listener execution.",
                    statusLabel = if (isIgnoringBatteryOptimizations) "Already Allowed" else "Action Required",
                    isComplete = isIgnoringBatteryOptimizations,
                    buttonText = "Allow Unrestricted Battery",
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                )
            }

            item {
                VivoStepItem(
                    stepNumber = "2",
                    title = "Vivo 'High Background Power Consumption'",
                    description = "Open Vivo Settings -> Battery -> Background power consumption management -> Find 'AI Call Assistant' -> Select 'Allow high background power consumption'.",
                    statusLabel = "Vivo OEM Setting",
                    isComplete = false,
                    buttonText = "Open Battery Settings",
                    onClick = {
                        try {
                            context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                        } catch (e: Exception) {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }
                )
            }

            item {
                VivoStepItem(
                    stepNumber = "3",
                    title = "Enable Autostart in iManager",
                    description = "Open Vivo iManager or Settings -> Applications -> Autostart / Permission Management -> Toggle 'AI Call Assistant' to ON.",
                    statusLabel = "iManager Autostart",
                    isComplete = false,
                    buttonText = "Open App Settings",
                    onClick = {
                        try {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            context.startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }
                )
            }

            item {
                VivoStepItem(
                    stepNumber = "4",
                    title = "Lock App in Recent Apps Tray",
                    description = "Swipe up and hold to open Recent Apps. Locate AI Call Assistant, tap the three dots or swipe down on the card, and tap the 'Lock' (padlock) icon so Vivo does not clear it when cleaning memory.",
                    statusLabel = "Memory Lock",
                    isComplete = true,
                    buttonText = null,
                    onClick = {}
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun VivoStepItem(
    stepNumber: String,
    title: String,
    description: String,
    statusLabel: String,
    isComplete: Boolean,
    buttonText: String?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(VivoBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(stepNumber, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isComplete) EmeraldGreen.copy(alpha = 0.2f) else AmberWarning.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        statusLabel,
                        color = if (isComplete) EmeraldGreen else AmberWarning,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(description, fontSize = 12.sp, color = TextSecondary, lineHeight = 18.sp)

            if (buttonText != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VivoBlue)
                ) {
                    Text(buttonText, fontSize = 12.sp)
                }
            }
        }
    }
}
