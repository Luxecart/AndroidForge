package com.aicallassistant.ui.call

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.telecom.ActiveCallUiState
import com.aicallassistant.telecom.CallAssistantStatus
import com.aicallassistant.ui.theme.*

@Composable
fun ActiveCallScreen(
    state: ActiveCallUiState,
    onTakeOver: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleMute: () -> Unit,
    onEndCall: () -> Unit,
    onSendSimulatedSpeech: (String) -> Unit
) {
    var simulatedInputText by remember { mutableStateOf("") }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Badge Header
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    when (state.status) {
                        CallAssistantStatus.RINGING -> AmberWarning.copy(alpha = 0.2f)
                        CallAssistantStatus.AUTO_ANSWERING_PENDING -> VivoBlue.copy(alpha = 0.2f)
                        CallAssistantStatus.ACTIVE_AI_HANDLING -> EmeraldGreen.copy(alpha = 0.2f)
                        CallAssistantStatus.USER_MANUAL_TAKEOVER -> PurpleGlow.copy(alpha = 0.2f)
                        else -> CardBorder
                    }
                )
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = when (state.status) {
                    CallAssistantStatus.RINGING -> "Incoming SIM Call • Ringing"
                    CallAssistantStatus.AUTO_ANSWERING_PENDING -> "Auto-answering in ${state.remainingAutoAnswerCountdown}s..."
                    CallAssistantStatus.ACTIVE_AI_HANDLING -> "AI Voice Agent Speaking • ${state.callDurationSeconds}s"
                    CallAssistantStatus.USER_MANUAL_TAKEOVER -> "Owner Manual Takeover Active"
                    CallAssistantStatus.DISCONNECTED -> "Call Ended"
                    else -> "Ready"
                },
                color = when (state.status) {
                    CallAssistantStatus.RINGING -> AmberWarning
                    CallAssistantStatus.AUTO_ANSWERING_PENDING -> VivoBlue
                    CallAssistantStatus.ACTIVE_AI_HANDLING -> EmeraldGreen
                    CallAssistantStatus.USER_MANUAL_TAKEOVER -> PurpleGlow
                    else -> TextSecondary
                },
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Caller Info
        Text(
            text = state.callerName ?: "Incoming Caller",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            text = state.callerNumber.ifEmpty { "+92 300 8421980" },
            fontSize = 15.sp,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // AI Agent Animated Orb
        Box(
            modifier = Modifier
                .size(100.dp)
                .scale(if (state.status == CallAssistantStatus.ACTIVE_AI_HANDLING) pulseScale else 1f)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(VivoBlue, AccentTeal, Color.Transparent)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (state.isEmergencyDetected) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = RoseDanger.copy(alpha = 0.2f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, RoseDanger)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = RoseDanger)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "URGENT / EMERGENCY KEYWORD DETECTED. Take over call immediately or verify emergency services.",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live Transcript Section
        Text(
            text = "Live Conversation Transcript",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(6.dp))

        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(16.dp)
        ) {
            if (state.conversationTranscript.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Listening for speech...", color = TextMuted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.conversationTranscript) { entry ->
                        TranscriptBubble(entry.sender, entry.message, entry.isUrdu)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Simulator Speech Input (Enables interactive testing of Urdu and English speech dialog)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = simulatedInputText,
                onValueChange = { simulatedInputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type caller speech (English/Urdu)...", fontSize = 12.sp, color = TextMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VivoBlue,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (simulatedInputText.isNotBlank()) {
                        onSendSimulatedSpeech(simulatedInputText)
                        simulatedInputText = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(VivoBlue)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Call Control Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speaker Button
            CallActionButton(
                icon = if (state.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                label = if (state.isSpeakerOn) "Speaker ON" else "Speaker",
                isActive = state.isSpeakerOn,
                onClick = onToggleSpeaker
            )

            // Take Over Button
            CallActionButton(
                icon = Icons.Default.Person,
                label = "Take Over",
                isActive = state.status == CallAssistantStatus.USER_MANUAL_TAKEOVER,
                onClick = onTakeOver
            )

            // Mute Button
            CallActionButton(
                icon = if (state.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                label = if (state.isMuted) "Muted" else "Mute",
                isActive = state.isMuted,
                onClick = onToggleMute
            )

            // Hang Up Button
            IconButton(
                onClick = onEndCall,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(RoseDanger)
            ) {
                Icon(Icons.Default.CallEnd, contentDescription = "End Call", tint = Color.White)
            }
        }
    }
}

@Composable
fun TranscriptBubble(sender: String, message: String, isUrdu: Boolean) {
    val isAssistant = sender == "AI Assistant"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isAssistant) Alignment.Start else Alignment.End
    ) {
        Text(
            text = sender,
            fontSize = 10.sp,
            color = if (isAssistant) AccentTeal else VivoBlue,
            fontWeight = FontWeight.Bold
        )
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (isAssistant) CardBorder else VivoBlue.copy(alpha = 0.3f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                text = message,
                fontSize = 13.sp,
                color = Color.White,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun CallActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (isActive) VivoBlue else CardBorder)
        ) {
            Icon(icon, contentDescription = label, tint = Color.White)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = TextSecondary)
    }
}
