package com.aicallassistant.ai

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.Call
import android.util.Log
import com.aicallassistant.ai.models.ConversationMessage
import com.aicallassistant.ai.models.ConverseRequest
import com.aicallassistant.ai.models.CustomInstructions
import com.aicallassistant.ai.models.SummarizeRequest
import com.aicallassistant.data.model.CallLogEntry
import com.aicallassistant.data.repository.CallHistoryRepository
import com.aicallassistant.data.repository.SettingsRepository
import com.aicallassistant.telecom.CallStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Stateful AI Voice dialog manager during active phone calls.
 * Manages full bidirectional conversational audio loop:
 * 1. Speaks introductory greeting in natural Pakistani Urdu male voice.
 * 2. Employs UtteranceProgressListener and SpeechRecognizer for turn-taking.
 * 3. Listens to caller's spoken voice and queries Gemini AI.
 * 4. Speaks intelligent Urdu reply back to the caller in real-time.
 * 5. Concludes call gracefully when goodbye is detected.
 */
object CallAgentEngine {

    private const val TAG = "CallAgentEngine"
    private val engineScope = CoroutineScope(Dispatchers.Main + Job())
    private val mainHandler = Handler(Looper.getMainLooper())

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var isSpeaking = false

    private val conversationHistory = mutableListOf<ConversationMessage>()
    private var activeCall: Call? = null
    private var onConcludeCallback: (() -> Unit)? = null
    private val voiceClient = GeminiVoiceClient()

    fun startVoiceSession(
        context: Context,
        call: Call,
        onConclude: () -> Unit
    ) {
        Log.i(TAG, "Starting AI Voice Agent Session for call: ${call.details?.handle}")
        activeCall = call
        onConcludeCallback = onConclude
        conversationHistory.clear()

        val settingsRepo = SettingsRepository.getInstance(context)
        val settings = settingsRepo.getSettingsSnapshot()

        initTts(context) {
            // Deliver introductory greeting
            engineScope.launch {
                delay(800) // Brief natural pause after pick-up
                val greeting = if (settings.languagePreference == "ur") {
                    settings.greetingUr
                } else {
                    settings.greetingEn
                }

                playSpeechResponse(context, greeting, isUrdu = settings.languagePreference == "ur")
                CallStateManager.addTranscript("AI Assistant", greeting, isUrdu = settings.languagePreference == "ur")
                conversationHistory.add(ConversationMessage("assistant", greeting))
            }
        }
    }

    /**
     * Initializes SpeechRecognizer on the main thread to listen to caller's voice
     */
    private fun startListeningToCaller(context: Context) {
        mainHandler.post {
            if (activeCall == null || isSpeaking) {
                Log.d(TAG, "Cannot start listening: call inactive or TTS is currently speaking")
                return@post
            }

            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                Log.w(TAG, "Speech recognition is not available on this device")
                return@post
            }

            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(object : RecognitionListener {
                            override fun onReadyForSpeech(params: Bundle?) {
                                isListening = true
                                Log.d(TAG, "SpeechRecognizer is listening to caller...")
                            }

                            override fun onBeginningOfSpeech() {
                                Log.d(TAG, "Caller started speaking...")
                            }

                            override fun onRmsChanged(rmsdB: Float) {}

                            override fun onBufferReceived(buffer: ByteArray?) {}

                            override fun onEndOfSpeech() {
                                isListening = false
                                Log.d(TAG, "Caller finished speaking turn")
                            }

                            override fun onError(error: Int) {
                                isListening = false
                                Log.w(TAG, "SpeechRecognizer error: $error")
                                // If timeout or no match, resume listening if call is still active
                                if (activeCall != null && !isSpeaking) {
                                    mainHandler.postDelayed({
                                        startListeningToCaller(context)
                                    }, 1200)
                                }
                            }

                            override fun onResults(results: Bundle?) {
                                isListening = false
                                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                val callerText = matches?.firstOrNull()?.trim() ?: ""
                                if (callerText.isNotBlank()) {
                                    Log.i(TAG, "Recognized caller utterance: $callerText")
                                    processCallerSpeech(context, callerText)
                                } else {
                                    // Empty utterance, resume listening
                                    if (activeCall != null && !isSpeaking) {
                                        mainHandler.postDelayed({
                                            startListeningToCaller(context)
                                        }, 800)
                                    }
                                }
                            }

                            override fun onPartialResults(partialResults: Bundle?) {}

                            override fun onEvent(eventType: Int, params: Bundle?) {}
                        })
                    }
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("ur-PK", "ur", "en-US"))
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                }

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error starting SpeechRecognizer", e)
            }
        }
    }

    private fun stopListeningToCaller() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                isListening = false
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping SpeechRecognizer", e)
            }
        }
    }

    /**
     * Process a recognized utterance from the caller
     */
    fun processCallerSpeech(context: Context, callerText: String) {
        if (callerText.isBlank()) return

        stopListeningToCaller()
        Log.d(TAG, "Processing caller speech: $callerText")
        CallStateManager.addTranscript("Caller", callerText)
        conversationHistory.add(ConversationMessage("user", callerText))

        engineScope.launch {
            val settingsRepo = SettingsRepository.getInstance(context)
            val settings = settingsRepo.getSettingsSnapshot()

            val request = ConverseRequest(
                callerText = callerText,
                history = conversationHistory.toList(),
                callerNumber = CallStateManager.uiState.value.callerNumber,
                callerName = CallStateManager.uiState.value.callerName,
                languagePreference = settings.languagePreference,
                customInstructions = CustomInstructions(
                    assistantName = settings.assistantName,
                    ownerName = settings.ownerName,
                    greetingEn = settings.greetingEn,
                    greetingUr = settings.greetingUr,
                    allowedTopics = settings.allowedTopics,
                    forbiddenTopics = settings.forbiddenTopics,
                    urgentRules = settings.urgentRules,
                    personality = settings.personality
                ),
                callMode = settings.mode
            )

            val response = voiceClient.converseWithAgent(request)

            val isUrdu = response.languageDetected == "ur"
            playSpeechResponse(context, response.replyText, isUrdu = isUrdu)
            CallStateManager.addTranscript("AI Assistant", response.replyText, isUrdu = isUrdu)
            conversationHistory.add(ConversationMessage("assistant", response.replyText))

            if (response.isEmergency) {
                Log.w(TAG, "Emergency detected in conversation turn!")
                CallStateManager.setEmergency(true)
            }

            if (response.suggestHangup) {
                delay(3000)
                onConcludeCallback?.invoke()
            }
        }
    }

    private fun playSpeechResponse(context: Context, text: String, isUrdu: Boolean) {
        stopListeningToCaller()
        isSpeaking = true

        textToSpeech?.let { tts ->
            val locale = if (isUrdu) Locale("ur", "PK") else Locale.US
            tts.language = locale
            tts.setPitch(0.92f) // Male natural timbre
            tts.setSpeechRate(0.95f) // Conversational pace

            // Configure male voice if available in engine
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val maleVoice = tts.voices?.firstOrNull { voice ->
                    (voice.locale.language == "ur" || voice.locale.language == "en") &&
                    voice.name.contains("male", ignoreCase = true)
                }
                if (maleVoice != null) {
                    tts.voice = maleVoice
                }
            }

            val utteranceId = "UTTERANCE_${System.currentTimeMillis()}"
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {
                    isSpeaking = true
                }

                override fun onDone(id: String?) {
                    isSpeaking = false
                    // Once assistant finishes speaking, listen to caller's response!
                    if (activeCall != null) {
                        startListeningToCaller(context)
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    isSpeaking = false
                    if (activeCall != null) {
                        startListeningToCaller(context)
                    }
                }
            })

            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    private fun initTts(context: Context, onReady: () -> Unit) {
        if (textToSpeech != null) {
            onReady()
            return
        }
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.setSpeechRate(0.95f)
                textToSpeech?.setPitch(0.92f)
                onReady()
            } else {
                Log.e(TAG, "Failed to initialize Android TextToSpeech engine")
            }
        }
    }

    fun stopVoiceSession() {
        stopListeningToCaller()
        speechRecognizer?.destroy()
        speechRecognizer = null

        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null

        isListening = false
        isSpeaking = false
        activeCall = null
        onConcludeCallback = null
    }

    suspend fun saveCompletedCallSummary(context: Context) {
        if (conversationHistory.isEmpty()) return

        val state = CallStateManager.uiState.value
        val summarizeRequest = SummarizeRequest(
            transcript = conversationHistory.toList(),
            callerNumber = state.callerNumber,
            callerName = state.callerName,
            durationSeconds = state.callDurationSeconds,
            timestamp = System.currentTimeMillis().toString()
        )

        val summary = voiceClient.generateCallSummary(summarizeRequest)

        val entry = CallLogEntry(
            id = System.currentTimeMillis().toString(),
            callerNumber = state.callerNumber,
            callerName = state.callerName ?: "Unknown",
            timestamp = System.currentTimeMillis(),
            durationSeconds = state.callDurationSeconds,
            summaryTitle = summary.title,
            summaryIntent = summary.callerIntent,
            urgency = summary.urgency,
            keyPoints = summary.keyPoints,
            callbackRequested = summary.callbackRequested,
            transcript = conversationHistory.toList()
        )

        CallHistoryRepository.getInstance(context).addCallLog(entry)
    }
}
