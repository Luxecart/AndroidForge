package com.aicallassistant.ui.instructions

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.data.model.AssistantSettings
import com.aicallassistant.ui.theme.*

@Composable
fun CustomInstructionsScreen(
    currentSettings: AssistantSettings,
    onSave: (AssistantSettings) -> Unit,
    onBack: () -> Unit
) {
    var assistantName by remember { mutableStateOf(currentSettings.assistantName) }
    var ownerName by remember { mutableStateOf(currentSettings.ownerName) }
    var languagePref by remember { mutableStateOf(currentSettings.languagePreference) }
    var greetingEn by remember { mutableStateOf(currentSettings.greetingEn) }
    var greetingUr by remember { mutableStateOf(currentSettings.greetingUr) }
    var allowedTopics by remember { mutableStateOf(currentSettings.allowedTopics) }
    var forbiddenTopics by remember { mutableStateOf(currentSettings.forbiddenTopics) }
    var urgentRules by remember { mutableStateOf(currentSettings.urgentRules) }
    var personality by remember { mutableStateOf(currentSettings.personality) }

    var hasSavedFeedback by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text(
                    text = "AI Custom Instructions",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                IconButton(onClick = {
                    onSave(
                        currentSettings.copy(
                            assistantName = assistantName,
                            ownerName = ownerName,
                            languagePreference = languagePref,
                            greetingEn = greetingEn,
                            greetingUr = greetingUr,
                            allowedTopics = allowedTopics,
                            forbiddenTopics = forbiddenTopics,
                            urgentRules = urgentRules,
                            personality = personality
                        )
                    )
                    hasSavedFeedback = true
                }) {
                    Icon(Icons.Default.Save, contentDescription = "Save", tint = VivoBlue)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Configure how your AI voice assistant identifies itself, manages caller questions, and enforces strict privacy boundaries.",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }

            if (hasSavedFeedback) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            "Instructions successfully saved to local encrypted preferences.",
                            color = EmeraldGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Assistant Persona & Ownership", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = assistantName,
                            onValueChange = { assistantName = it },
                            label = { Text("Assistant Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = ownerName,
                            onValueChange = { ownerName = it },
                            label = { Text("Your Name (Phone Owner)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Preferred Language:", fontSize = 13.sp, color = TextSecondary)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            LanguageChoiceChip("auto", "Auto (Detect)", languagePref == "auto") { languagePref = "auto" }
                            LanguageChoiceChip("en", "English", languagePref == "en") { languagePref = "en" }
                            LanguageChoiceChip("ur", "Urdu (اردو)", languagePref == "ur") { languagePref = "ur" }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Spoken Greeting Messages", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "The assistant introduces itself as an AI and never pretends to be human.",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = greetingEn,
                            onValueChange = { greetingEn = it },
                            label = { Text("English Greeting") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = greetingUr,
                            onValueChange = { greetingUr = it },
                            label = { Text("Urdu Greeting (اردو سلام و تعارف)") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = RoseDanger)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Strict Guardrails & Privacy", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = forbiddenTopics,
                            onValueChange = { forbiddenTopics = it },
                            label = { Text("Information AI Must NEVER Disclose") },
                            supportingText = { Text("e.g. Bank details, OTPs, home address, travel schedules", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = allowedTopics,
                            onValueChange = { allowedTopics = it },
                            label = { Text("Permitted Discussion Topics") },
                            supportingText = { Text("e.g. Taking messages, scheduling meetings, availability", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Emergency & Urgent Call Handling", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = urgentRules,
                            onValueChange = { urgentRules = it },
                            label = { Text("Urgent Protocol") },
                            supportingText = { Text("Mandatory rule: AI must never delay medical/police emergencies.", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = personality,
                            onValueChange = { personality = it },
                            label = { Text("Speaking Tone & Style") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun LanguageChoiceChip(id: String, label: String, isSelected: Boolean, onSelect: () -> Unit) {
    FilterChip(
        selected = isSelected,
        onClick = onSelect,
        label = { Text(label, fontSize = 12.sp) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = VivoBlue,
            selectedLabelColor = Color.White
        )
    )
}
