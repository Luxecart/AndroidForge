package com.aicallassistant.data.model

import com.aicallassistant.ai.models.ConversationMessage

data class CallLogEntry(
    val id: String,
    val callerNumber: String,
    val callerName: String,
    val timestamp: Long,
    val durationSeconds: Int,
    val summaryTitle: String,
    val summaryIntent: String,
    val urgency: String, // "LOW", "MEDIUM", "HIGH", "URGENT"
    val keyPoints: List<String>,
    val callbackRequested: Boolean,
    val transcript: List<ConversationMessage>
)

enum class ContactRuleType {
    VIP_BYPASS_AI,       // Always rings human directly, never auto-answered by AI
    AI_STANDARD_HANDLE,  // Normal AI assistant handling with greeting and message taking
    BLOCK_CALLER         // Call rejected pre-ring via CallScreeningService
}

data class ContactRule(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val ruleType: ContactRuleType,
    val customNotes: String = ""
)
