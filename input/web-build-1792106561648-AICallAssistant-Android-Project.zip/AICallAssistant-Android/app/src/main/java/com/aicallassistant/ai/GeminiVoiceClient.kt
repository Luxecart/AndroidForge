package com.aicallassistant.ai

import android.util.Log
import com.aicallassistant.BuildConfig
import com.aicallassistant.ai.models.ConverseRequest
import com.aicallassistant.ai.models.ConverseResponse
import com.aicallassistant.ai.models.SummarizeRequest
import com.aicallassistant.ai.models.CallSummary
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Secure HTTP client that communicates with the backend AI server.
 * Never stores or transmits Google GenAI API keys inside the APK client.
 * Includes automated fallback for network disconnection or latency timeouts.
 */
class GeminiVoiceClient(
    private val baseUrl: String = BuildConfig.AI_BACKEND_URL
) {
    companion object {
        private const val TAG = "GeminiVoiceClient"
        private val JSON = "application/json; charset=utf-8".toMediaType()
    }

    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    suspend fun converseWithAgent(request: ConverseRequest): ConverseResponse = withContext(Dispatchers.IO) {
        val jsonPayload = gson.toJson(request)
        val httpRequest = Request.Builder()
            .url("$baseUrl/api/gemini/converse")
            .post(jsonPayload.toRequestBody(JSON))
            .build()

        try {
            val response = client.newCall(httpRequest).execute()
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: ""
                return@withContext gson.fromJson(bodyString, ConverseResponse::class.java)
            } else {
                Log.w(TAG, "Backend returned error code ${response.code}, falling back to safe offline response")
                return@withContext getOfflineFallbackResponse(request)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network exception connecting to Gemini voice backend", e)
            return@withContext getOfflineFallbackResponse(request)
        }
    }

    suspend fun generateCallSummary(request: SummarizeRequest): CallSummary = withContext(Dispatchers.IO) {
        val jsonPayload = gson.toJson(request)
        val httpRequest = Request.Builder()
            .url("$baseUrl/api/gemini/summarize")
            .post(jsonPayload.toRequestBody(JSON))
            .build()

        try {
            val response = client.newCall(httpRequest).execute()
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: ""
                return@withContext gson.fromJson(bodyString, CallSummary::class.java)
            } else {
                return@withContext getOfflineFallbackSummary(request)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network exception generating call summary", e)
            return@withContext getOfflineFallbackSummary(request)
        }
    }

    private fun getOfflineFallbackResponse(request: ConverseRequest): ConverseResponse {
        val isUrdu = request.languagePreference == "ur" ||
                request.callerText.contains("kya", ignoreCase = true) ||
                request.callerText.contains("kaun", ignoreCase = true) ||
                request.callerText.contains("salam", ignoreCase = true)

        val reply = if (isUrdu) {
            "معذرت، نیٹ ورک میں دشواری کی وجہ سے رابطہ ممکن نہیں ہے۔ برائے مہربانی اپنا پیغام یا نمبر چھوڑ دیں، مالک آپ کو جلد کال بیک کریں گے۔"
        } else {
            "I apologize, but my connection is momentarily delayed. Please leave your name and contact details, and the phone owner will call you back shortly."
        }

        return ConverseResponse(
            replyText = reply,
            languageDetected = if (isUrdu) "ur" else "en",
            intentDetected = "network_fallback",
            isEmergency = false,
            suggestHangup = false,
            recordedNotes = "Fallback voicemail recorded due to backend timeout."
        )
    }

    private fun getOfflineFallbackSummary(request: SummarizeRequest): CallSummary {
        return CallSummary(
            title = "Completed Call with ${request.callerName ?: request.callerNumber}",
            callerIntent = "Message recorded via AI Assistant",
            urgency = "MEDIUM",
            sentiment = "neutral",
            keyPoints = listOf(
                "Call lasted ${request.durationSeconds} seconds.",
                "Review full in-device transcript for caller details."
            ),
            actionRequired = "Review transcript and return call if needed.",
            callbackRequested = true
        )
    }
}
