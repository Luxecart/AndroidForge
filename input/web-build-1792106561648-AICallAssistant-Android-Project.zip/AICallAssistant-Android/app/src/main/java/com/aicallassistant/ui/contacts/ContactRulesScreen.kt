package com.aicallassistant.ui.contacts

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.data.model.ContactRule
import com.aicallassistant.data.model.ContactRuleType
import com.aicallassistant.ui.theme.*

@Composable
fun ContactRulesScreen(
    contactRules: List<ContactRule>,
    onAddRule: (ContactRule) -> Unit,
    onDeleteRule: (String) -> Unit,
    onBack: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text("Contact Routing Rules", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                IconButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Rule", tint = VivoBlue)
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Configure rules for specific contacts: VIP callers can ring your phone directly, while blocked callers are silently rejected pre-ring via CallScreeningService.",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }

            items(contactRules) { rule ->
                ContactRuleCard(rule = rule, onDelete = { onDeleteRule(rule.id) })
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showAddDialog) {
        AddRuleDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { newRule ->
                onAddRule(newRule)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun ContactRuleCard(rule: ContactRule, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(rule.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                when (rule.ruleType) {
                                    ContactRuleType.VIP_BYPASS_AI -> EmeraldGreen.copy(alpha = 0.2f)
                                    ContactRuleType.AI_STANDARD_HANDLE -> VivoBlue.copy(alpha = 0.2f)
                                    ContactRuleType.BLOCK_CALLER -> RoseDanger.copy(alpha = 0.2f)
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = when (rule.ruleType) {
                                ContactRuleType.VIP_BYPASS_AI -> "VIP Direct Ring"
                                ContactRuleType.AI_STANDARD_HANDLE -> "AI Handle"
                                ContactRuleType.BLOCK_CALLER -> "Auto Reject"
                            },
                            color = when (rule.ruleType) {
                                ContactRuleType.VIP_BYPASS_AI -> EmeraldGreen
                                ContactRuleType.AI_STANDARD_HANDLE -> VivoBlue
                                ContactRuleType.BLOCK_CALLER -> RoseDanger
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(rule.phoneNumber, fontSize = 13.sp, color = TextSecondary)
                if (rule.customNotes.isNotBlank()) {
                    Text(rule.customNotes, fontSize = 11.sp, color = TextMuted)
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted)
            }
        }
    }
}

@Composable
fun AddRuleDialog(
    onDismiss: () -> Unit,
    onConfirm: (ContactRule) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ContactRuleType.VIP_BYPASS_AI) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Contact Rule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Contact Name") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    singleLine = true
                )
                Text("Rule Type:", fontSize = 12.sp, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedType == ContactRuleType.VIP_BYPASS_AI,
                        onClick = { selectedType = ContactRuleType.VIP_BYPASS_AI },
                        label = { Text("VIP", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedType == ContactRuleType.AI_STANDARD_HANDLE,
                        onClick = { selectedType = ContactRuleType.AI_STANDARD_HANDLE },
                        label = { Text("AI Assist", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedType == ContactRuleType.BLOCK_CALLER,
                        onClick = { selectedType = ContactRuleType.BLOCK_CALLER },
                        label = { Text("Block", fontSize = 11.sp) }
                    )
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (phone.isNotBlank()) {
                        onConfirm(
                            ContactRule(
                                id = System.currentTimeMillis().toString(),
                                name = name.ifBlank { "Contact" },
                                phoneNumber = phone,
                                ruleType = selectedType,
                                customNotes = notes
                            )
                        )
                    }
                }
            ) {
                Text("Add Rule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
