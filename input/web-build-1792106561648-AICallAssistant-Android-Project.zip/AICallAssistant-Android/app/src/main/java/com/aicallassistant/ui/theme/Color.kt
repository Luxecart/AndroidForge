package com.aicallassistant.ui.theme

import androidx.compose.ui.graphics.Color

val VivoBlue = Color(0xFF0057FF)
val DeepNavy = Color(0xFF0A0F1D)
val SurfaceDark = Color(0xFF131B2E)
val CardBorder = Color(0xFF1E293B)
val AccentTeal = Color(0xFF00D1B2)
val EmeraldGreen = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseDanger = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val PurpleGlow = Color(0xFF8B5CF6)
val Indigo600 = Color(0xFF4F46E5)
