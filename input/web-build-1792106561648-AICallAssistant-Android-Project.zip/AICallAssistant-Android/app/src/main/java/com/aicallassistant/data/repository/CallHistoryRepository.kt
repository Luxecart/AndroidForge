package com.aicallassistant.data.repository

import android.content.Context
import com.aicallassistant.ai.models.ConversationMessage
import com.aicallassistant.data.model.CallLogEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class CallHistoryRepository private constructor(context: Context) {

    companion object {
        @Volatile
        private var instance: CallHistoryRepository? = null

        fun getInstance(context: Context): CallHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: CallHistoryRepository(context.applicationContext).also { instance = it }
            }
        }
    }

    private val _callLogs = MutableStateFlow<List<CallLogEntry>>(
        listOf(
            CallLogEntry(
                id = "demo_1",
                callerNumber = "+92 301 8492019",
                callerName = "Hamza Ali (Client)",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45, // 45 mins ago
                durationSeconds = 64,
                summaryTitle = "Project milestone review rescheduled",
                summaryIntent = "Requested callback to confirm Thursday zoom call",
                urgency = "HIGH",
                keyPoints = listOf(
                    "Hamza reviewed the Q3 design deck.",
                    "Needs 15-minute confirmation call on Thursday morning.",
                    "Will email revised budget figures."
                ),
                callbackRequested = true,
                transcript = listOf(
                    ConversationMessage("assistant", "السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟"),
                    ConversationMessage("user", "Walaikum Assalam, mein Hamza bol raha hoon. Mujhay kal ki meeting reschedule karni thi."),
                    ConversationMessage("assistant", "جی حمزہ صاحب، میں نے نوٹ کر لیا ہے۔ کیا آپ جمعرات کی صبح مناسب سمجھیں گے یا کوئی مخصوص وقت ہے؟"),
                    ConversationMessage("user", "Haan Thursday 11 AM theek rahay ga. Please unko bol dain callback kar lain."),
                    ConversationMessage("assistant", "بہت شکریہ، میں نے ہائی پرائرٹی نوٹ کر لیا ہے اور مالک کو فوراً آگاہ کر دیا جائے گا۔ اللہ حافظ۔")
                )
            ),
            CallLogEntry(
                id = "demo_2",
                callerNumber = "+92 322 4118920",
                callerName = "DHL Express Courier",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 180, // 3 hours ago
                durationSeconds = 38,
                summaryTitle = "Package delivery confirmation at front desk",
                summaryIntent = "Delivered parcel to reception guard",
                urgency = "MEDIUM",
                keyPoints = listOf(
                    "Tracking parcel #PK98231 arrived.",
                    "Handed over to building security guard Aslam."
                ),
                callbackRequested = false,
                transcript = listOf(
                    ConversationMessage("assistant", "Hello! I am the AI Call Assistant for this phone. How may I help you?"),
                    ConversationMessage("user", "Hello, I am outside with your parcel delivery. Security guard is here."),
                    ConversationMessage("assistant", "Please hand the parcel to guard Aslam at the reception desk. Thank you."),
                    ConversationMessage("user", "Okay, done. Thank you."),
                    ConversationMessage("assistant", "Have a great day!")
                )
            )
        )
    )

    fun getCallHistory(): Flow<List<CallLogEntry>> = _callLogs.asStateFlow()

    fun addCallLog(entry: CallLogEntry) {
        _callLogs.value = listOf(entry) + _callLogs.value
    }

    fun deleteCallLog(id: String) {
        _callLogs.value = _callLogs.value.filter { it.id != id }
    }

    fun clearAllHistory() {
        _callLogs.value = emptyList()
    }
}
