package com.aicallassistant.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.data.model.AssistantSettings
import com.aicallassistant.ui.theme.*

@Composable
fun SettingsScreen(
    settings: AssistantSettings,
    isDefaultDialer: Boolean,
    onRequestDefaultDialerRole: () -> Unit,
    onNavigateToVivoGuide: () -> Unit,
    onUpdateSettings: (AssistantSettings) -> Unit,
    onBack: () -> Unit
) {
    var delaySec by remember { mutableStateOf(settings.autoAnswerDelaySeconds.toFloat()) }
    var requireConsent by remember { mutableStateOf(settings.requireCallerConsentForSummary) }
    var keepLocalOnly by remember { mutableStateOf(settings.keepRecordingsLocally) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text("Settings & Telecom Setup", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Android Telecom Role", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Android 15 requires AI Call Assistant to hold the Default Phone App role (RoleManager.ROLE_DIALER) to legitimately intercept and answer calls programmatically via InCallService.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onRequestDefaultDialerRole,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDefaultDialer) EmeraldGreen else VivoBlue
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isDefaultDialer) "Default Phone App (Active)" else "Set as Default Phone App")
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Auto-Answer Timing", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "Delay before AI voice assistant automatically picks up the incoming SIM call. Gives you time to answer manually if desired.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Answer Delay: ${delaySec.toInt()} seconds",
                            fontWeight = FontWeight.Bold,
                            color = VivoBlue,
                            fontSize = 14.sp
                        )
                        Slider(
                            value = delaySec,
                            onValueChange = {
                                delaySec = it
                                onUpdateSettings(settings.copy(autoAnswerDelaySeconds = it.toInt()))
                            },
                            valueRange = 1f..15f,
                            steps = 13
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Vivo OriginOS / FuntouchOS 15 Optimization", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Vivo smartphones apply aggressive background power killing. Tap below to follow the exact checklist to keep InCallService running reliably.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = onNavigateToVivoGuide,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Open Vivo Background Settings Checklist")
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Privacy & Security Controls", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Inform Caller of AI Identity", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Assistant will always introduce itself as an AI and never deceive the caller.", fontSize = 11.sp, color = TextMuted)
                            }
                            Switch(checked = true, onCheckedChange = null, enabled = false)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Store Transcripts On-Device Only", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Transcripts and summaries remain in private app sandbox.", fontSize = 11.sp, color = TextMuted)
                            }
                            Switch(
                                checked = keepLocalOnly,
                                onCheckedChange = {
                                    keepLocalOnly = it
                                    onUpdateSettings(settings.copy(keepRecordingsLocally = it))
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
