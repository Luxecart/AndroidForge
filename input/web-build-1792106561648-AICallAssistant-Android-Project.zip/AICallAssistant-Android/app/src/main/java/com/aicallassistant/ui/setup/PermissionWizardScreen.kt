package com.aicallassistant.ui.setup

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.ui.theme.*

@Composable
fun PermissionWizardScreen(
    isDefaultDialer: Boolean,
    hasRecordAudio: Boolean,
    hasPhonePermissions: Boolean,
    hasContactsPermission: Boolean,
    hasNotificationPermission: Boolean,
    isVivoOptimized: Boolean,
    onRequestAllPermissions: () -> Unit,
    onRequestDefaultDialer: () -> Unit,
    onRequestAudio: () -> Unit,
    onRequestPhoneState: () -> Unit,
    onRequestContacts: () -> Unit,
    onRequestNotifications: () -> Unit,
    onRequestVivoOptimization: () -> Unit,
    onFinish: () -> Unit
) {
    val totalRequired = 4
    val grantedCount = listOf(isDefaultDialer, hasRecordAudio, hasPhonePermissions, hasNotificationPermission).count { it }
    val isAllRequiredGranted = isDefaultDialer && hasRecordAudio && hasPhonePermissions && hasNotificationPermission

    Scaffold { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "فون کی تمام پرمیشنز الاؤ کریں",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Android 15 & Vivo Auto-Answer Authorization",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = VivoBlue
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "جب بھی کوئی کال کرے، AI اسسٹنٹ خود کال اٹینڈ کر کے اردو میں کالر سے بات کرے گا اور اس کا پیغام محفوظ کرے گا۔ اس کے لیے درج ذیل پرمیشنز ضروری ہیں۔",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }

            // PRIMARY ONE-TAP ALLOW ALL BUTTON
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, if (isAllRequiredGranted) EmeraldGreen else VivoBlue, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isAllRequiredGranted) EmeraldGreen.copy(alpha = 0.12f) else VivoBlue.copy(alpha = 0.12f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isAllRequiredGranted) "✓ تمام اہم پرمیشنز فعال ہیں" else "⚡ ایک کلک میں تمام پرمیشنز دیں",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = if (isAllRequiredGranted) EmeraldGreen else MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "$grantedCount / $totalRequired اہم پرمیشنز فعال ہو چکی ہیں",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                            LinearProgressIndicator(
                                progress = { grantedCount.toFloat() / totalRequired.toFloat() },
                                modifier = Modifier.width(70.dp).height(8.dp).clip(RoundedCornerShape(4.dp)),
                                color = if (isAllRequiredGranted) EmeraldGreen else VivoBlue,
                                trackColor = CardBorder
                            )
                        }

                        if (!isAllRequiredGranted) {
                            Button(
                                onClick = onRequestAllPermissions,
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = VivoBlue)
                            ) {
                                Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تمام پرمیشنز الاؤ کریں (Allow All Permissions)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "انفرادی پرمیشنز کی تفصیل:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // 1. DEFAULT PHONE APP
            item {
                PermissionStepCard(
                    title = "1. ڈیفالٹ فون ایپ (Default Phone App)",
                    description = "کال آنے پر خود جواب دینے (Auto-Answer) اور کال سنبھالنے کے لیے اسسٹنٹ کو بطور ڈیفالٹ فون ایپ منتخب کرنا لازمی ہے۔",
                    isGranted = isDefaultDialer,
                    icon = Icons.Default.PhoneInTalk,
                    actionText = "ڈیفالٹ فون ایپ سیٹ کریں",
                    onAction = onRequestDefaultDialer
                )
            }

            // 2. MICROPHONE & AUDIO
            item {
                PermissionStepCard(
                    title = "2. مائیکروفون اور آواز (Record Audio)",
                    description = "کالر کی بات سننے کے لیے مائیکروفون کی اجازت تاکہ Gemini AI کالر کے سوالات سن کر فوری جواب تیار کر سکے۔",
                    isGranted = hasRecordAudio,
                    icon = Icons.Default.Mic,
                    actionText = "مائیکروفون الاؤ کریں",
                    onAction = onRequestAudio
                )
            }

            // 3. PHONE STATE & ANSWER CALLS
            item {
                PermissionStepCard(
                    title = "3. کال اٹینڈ کرنے کی اجازت (Answer Calls)",
                    description = "فون کی گھنٹی بجنے پر کال کو خود بخود پک کرنے اور کال ڈسکنیکٹ کرنے کے لیے ٹیلی کام پرمیشنز۔",
                    isGranted = hasPhonePermissions,
                    icon = Icons.Default.Call,
                    actionText = "کال پرمیشنز الاؤ کریں",
                    onAction = onRequestPhoneState
                )
            }

            // 4. NOTIFICATIONS
            item {
                PermissionStepCard(
                    title = "4. اطلاعات اور الرٹس (Notifications)",
                    description = "کال ختم ہونے پر کال کا اردو خلاصہ اور اہم پیغام آپ کے نوٹیفکیشن بار میں دکھانے کے لیے۔",
                    isGranted = hasNotificationPermission,
                    icon = Icons.Default.Notifications,
                    actionText = "نوٹیفکیشن الاؤ کریں",
                    onAction = onRequestNotifications
                )
            }

            // 5. VIVO BATTERY OPTIMIZATION
            item {
                PermissionStepCard(
                    title = "5. ویوو بیٹری سیور سے استثنیٰ (Vivo Background)",
                    description = "ویوو Android 15 کے بیک گراؤنڈ مینیجر سے ایپ کو کل ہونے سے بچائیں تاکہ جب بھی کال آئے، AI ہمیشہ جاگتا رہے۔",
                    isGranted = isVivoOptimized,
                    icon = Icons.Default.BatteryChargingFull,
                    actionText = "بیک گراؤنڈ سیٹنگ کھولیں",
                    onAction = onRequestVivoOptimization
                )
            }

            // 6. CONTACTS (OPTIONAL)
            item {
                PermissionStepCard(
                    title = "6. کانٹیکٹس بک (VIP & Spam Filter)",
                    description = "آپ کے اہم گھر والوں (VIP) اور اسپام نمبرز کو الگ سے پہچاننے کے لیے (اختیاری)۔",
                    isGranted = hasContactsPermission,
                    icon = Icons.Default.Contacts,
                    actionText = "کانٹیکٹس الاؤ کریں",
                    onAction = onRequestContacts
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onFinish,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAllRequiredGranted) EmeraldGreen else VivoBlue
                    )
                ) {
                    Text(
                        text = if (isAllRequiredGranted) "ڈیش بورڈ پر جائیں (Ready to Use)" else "پھر بھی ڈیش بورڈ پر جائیں",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun PermissionStepCard(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: ImageVector,
    actionText: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isGranted) EmeraldGreen.copy(alpha = 0.5f) else CardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isGranted) EmeraldGreen.copy(alpha = 0.2f) else VivoBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            icon,
                            contentDescription = null,
                            tint = if (isGranted) EmeraldGreen else VivoBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isGranted) EmeraldGreen else TextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(description, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)

            if (!isGranted) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onAction,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = VivoBlue)
                ) {
                    Text(actionText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
