package com.aicallassistant.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.data.model.CallLogEntry
import com.aicallassistant.ui.theme.*

@Composable
fun CallHistoryScreen(
    callLogs: List<CallLogEntry>,
    onDeleteCall: (String) -> Unit,
    onClearAll: () -> Unit,
    onBack: () -> Unit
) {
    var expandedCallId by remember { mutableStateOf<String?>(null) }
    var showConfirmClear by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text("Call History & Summaries", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                if (callLogs.isNotEmpty()) {
                    IconButton(onClick = { showConfirmClear = true }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All", tint = RoseDanger)
                    }
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "AI summaries generated from incoming calls. You retain full ownership and can delete single logs or wipe all history at any time.",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }

            if (callLogs.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(48.dp), contentAlignment = Alignment.Center) {
                        Text("No call logs recorded.", color = TextMuted)
                    }
                }
            } else {
                items(callLogs) { entry ->
                    val isExpanded = expandedCallId == entry.id
                    HistoryEntryCard(
                        entry = entry,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedCallId = if (isExpanded) null else entry.id
                        },
                        onDelete = { onDeleteCall(entry.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Delete All History?") },
            text = { Text("This will permanently remove all call summaries and conversation transcripts stored on this device.") },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAll()
                        showConfirmClear = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RoseDanger)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun HistoryEntryCard(
    entry: CallLogEntry,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
            .clickable { onToggleExpand() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(entry.callerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("${entry.callerNumber} • ${entry.durationSeconds}s", fontSize = 12.sp, color = TextSecondary)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                when (entry.urgency) {
                                    "URGENT", "HIGH" -> RoseDanger.copy(alpha = 0.2f)
                                    "MEDIUM" -> AmberWarning.copy(alpha = 0.2f)
                                    else -> EmeraldGreen.copy(alpha = 0.2f)
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            entry.urgency,
                            color = when (entry.urgency) {
                                "URGENT", "HIGH" -> RoseDanger
                                "MEDIUM" -> AmberWarning
                                else -> EmeraldGreen
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(entry.summaryTitle, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(entry.summaryIntent, fontSize = 13.sp, color = TextSecondary)

            if (isExpanded) {
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = CardBorder)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Key Summary Points:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = VivoBlue)
                entry.keyPoints.forEach { point ->
                    Row(modifier = Modifier.padding(vertical = 2.dp)) {
                        Text("• ", color = VivoBlue, fontWeight = FontWeight.Bold)
                        Text(point, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }

                if (entry.transcript.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Full Transcript:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        entry.transcript.forEach { msg ->
                            Row {
                                Text(
                                    text = if (msg.role == "assistant") "AI: " else "Caller: ",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (msg.role == "assistant") AccentTeal else VivoBlue
                                )
                                Text(msg.text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }
    }
}
