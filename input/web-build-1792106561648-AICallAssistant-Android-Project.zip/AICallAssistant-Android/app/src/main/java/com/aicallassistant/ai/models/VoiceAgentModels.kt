package com.aicallassistant.ai.models

data class ConversationMessage(
    val role: String, // "user" (caller) or "assistant"
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class CustomInstructions(
    val assistantName: String = "Aura",
    val ownerName: String = "Phone Owner",
    val greetingEn: String = "Hello! I am the AI Call Assistant for this phone. The owner is currently unavailable. How may I assist you?",
    val greetingUr: String = "السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟",
    val allowedTopics: String = "Taking messages, scheduling appointments, urgent callbacks, general polite inquiries",
    val forbiddenTopics: String = "Bank account numbers, OTPs, financial details, passwords, exact home GPS address, private travel itinerary",
    val urgentRules: String = "If medical or danger emergency, advise immediate call to emergency services (112 / 15 / 911).",
    val personality: String = "Polite, helpful, concise, reassuring, and articulate"
)

data class ConverseRequest(
    val callerText: String,
    val history: List<ConversationMessage>,
    val callerNumber: String,
    val callerName: String?,
    val languagePreference: String, // "auto", "en", "ur"
    val customInstructions: CustomInstructions,
    val callMode: String // "BUSY", "SLEEP", "CUSTOM"
)

data class ConverseResponse(
    val replyText: String,
    val languageDetected: String, // "en", "ur", "mixed"
    val intentDetected: String,
    val isEmergency: Boolean,
    val suggestHangup: Boolean,
    val recordedNotes: String?
)

data class SummarizeRequest(
    val transcript: List<ConversationMessage>,
    val callerNumber: String,
    val callerName: String?,
    val durationSeconds: Int,
    val timestamp: String
)

data class CallSummary(
    val title: String,
    val callerIntent: String,
    val urgency: String, // "LOW", "MEDIUM", "HIGH", "URGENT"
    val sentiment: String,
    val keyPoints: List<String>,
    val actionRequired: String,
    val callbackRequested: Boolean,
    val callbackTimePreference: String? = null,
    val language: String? = null
)
