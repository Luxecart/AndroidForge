package com.aicallassistant.telecom

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import android.util.Log
import com.aicallassistant.data.repository.SettingsRepository
import kotlinx.coroutines.runBlocking

/**
 * Telecom CallScreeningService to screen incoming calls before ringing.
 * Blocks numbers configured by the user, verifies VIP routing,
 * and passes legitimate callers to InCallService.
 */
class AssistantCallScreeningService : CallScreeningService() {

    companion object {
        private const val TAG = "CallScreeningService"
    }

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart ?: ""
        Log.d(TAG, "Screening incoming call from: $number")

        val repository = SettingsRepository.getInstance(applicationContext)

        val isBlocked = runBlocking {
            repository.isNumberBlocked(number)
        }

        val responseBuilder = CallResponse.Builder()

        if (isBlocked) {
            Log.i(TAG, "Blocking call from blacklisted contact: $number")
            responseBuilder
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(true)
        } else {
            // Normal pass-through to InCallService
            responseBuilder
                .setDisallowCall(false)
                .setRejectCall(false)
                .setSkipCallLog(false)
                .setSkipNotification(false)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // In Android 10+, we can silence the ringer if the assistant is set to immediate screen
                val settings = repository.getSettingsSnapshot()
                if (settings.isAssistantEnabled && settings.autoAnswerDelaySeconds == 0) {
                    responseBuilder.setSilenceCall(true)
                }
            }
        }

        respondToCall(callDetails, responseBuilder.build())
    }
}
