package com.aicallassistant.data.model

data class AssistantSettings(
    val isAssistantEnabled: Boolean = true,
    val mode: String = "BUSY", // "SLEEP", "BUSY", "CUSTOM", "DIRECT_ONLY"
    val autoAnswerDelaySeconds: Int = 2,
    val assistantName: String = "Aura",
    val ownerName: String = "Muhammad Jahangir",
    val languagePreference: String = "ur", // "ur", "en", "auto"
    val greetingEn: String = "Hello! I am the AI Call Assistant for Muhammad Jahangir. He is currently occupied. Please state how I may help you?",
    val greetingUr: String = "السلام علیکم! میں محمد جہانگیر کا اے آئی کال اسسٹنٹ ہوں۔ وہ اس وقت مصروف ہیں۔ فرمائیے آپ کا کیا کام ہے؟",
    val allowedTopics: String = "Taking messages, scheduling appointments, urgent callback requests, general polite inquiries",
    val forbiddenTopics: String = "Bank account numbers, OTPs, financial details, passwords, exact home GPS address, private travel itinerary",
    val urgentRules: String = "If medical or danger emergency, advise immediate call to emergency services (112 / 15 / 911). For urgent business, note high priority callback.",
    val personality: String = "Polite, helpful, concise, reassuring, and articulate",
    val requireCallerConsentForSummary: Boolean = true,
    val keepRecordingsLocally: Boolean = true,
    val dataRetentionDays: Int = 30
)
