package com.aicallassistant.telecom

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.telephony.PhoneNumberUtils
import android.util.Log
import androidx.core.app.NotificationCompat
import com.aicallassistant.AiCallAssistantApp
import com.aicallassistant.MainActivity
import com.aicallassistant.R
import com.aicallassistant.ai.CallAgentEngine
import com.aicallassistant.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Legitimate Android Telecom InCallService implementation.
 * Holds role as Default Phone App (RoleManager.ROLE_DIALER) or companion.
 * Manages call lifecycle, safety guarantees, auto-answer timer, and AI voice handoff.
 */
class AssistantInCallService : InCallService() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var autoAnswerJob: Job? = null
    private var callDurationJob: Job? = null
    private var currentCall: Call? = null

    companion object {
        private const val TAG = "AssistantInCallService"
        private const val NOTIFICATION_ID = 2001
    }

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            super.onStateChanged(call, state)
            Log.d(TAG, "Call state changed to: $state")
            when (state) {
                Call.STATE_RINGING -> handleRingingState(call)
                Call.STATE_ACTIVE -> handleActiveState(call)
                Call.STATE_DISCONNECTED -> handleDisconnectedState(call)
            }
        }

        override fun onCallAudioStateChanged(call: Call, audioState: CallAudioState) {
            super.onCallAudioStateChanged(call, audioState)
            CallStateManager.updateAudioRoute(audioState.route)
        }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.d(TAG, "New call added: ${call.details?.handle}")
        currentCall = call
        CallStateManager.setCall(call)
        call.registerCallback(callCallback)

        val handle = call.details?.handle?.schemeSpecificPart ?: "Unknown"
        val callerName = call.details?.callerDisplayName
        CallStateManager.setCallerInfo(handle, callerName)

        // CRITICAL EMERGENCY CHECK: Never intercept or delay emergency calls!
        if (isEmergencyCall(call, handle)) {
            Log.w(TAG, "EMERGENCY CALL DETECTED: Bypassing AI Assistant completely.")
            CallStateManager.setEmergency(true)
            CallStateManager.updateStatus(CallAssistantStatus.USER_MANUAL_TAKEOVER)
            launchInCallUi(call, isEmergency = true)
            return
        }

        if (call.state == Call.STATE_RINGING) {
            handleRingingState(call)
        } else if (call.state == Call.STATE_ACTIVE) {
            handleActiveState(call)
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.d(TAG, "Call removed")
        call.unregisterCallback(callCallback)
        if (currentCall == call) {
            handleDisconnectedState(call)
        }
    }

    private fun handleRingingState(call: Call) {
        CallStateManager.updateStatus(CallAssistantStatus.RINGING)
        startForegroundCallNotification("Incoming Call", "AI Assistant is evaluating call rules...")

        serviceScope.launch {
            val settings = SettingsRepository.getInstance(applicationContext).getSettingsSnapshot()
            val contactBlocked = SettingsRepository.getInstance(applicationContext).isNumberBlocked(
                call.details?.handle?.schemeSpecificPart ?: ""
            )

            if (!settings.isAssistantEnabled || contactBlocked) {
                Log.d(TAG, "AI Assistant is OFF or contact is blocked from AI handling.")
                launchInCallUi(call, isEmergency = false)
                return@launch
            }

            // Check mode
            if (settings.mode == "DIRECT_ONLY") {
                launchInCallUi(call, isEmergency = false)
                return@launch
            }

            // Start auto-answer countdown
            val delaySec = settings.autoAnswerDelaySeconds
            CallStateManager.updateStatus(CallAssistantStatus.AUTO_ANSWERING_PENDING)

            autoAnswerJob?.cancel()
            autoAnswerJob = serviceScope.launch {
                for (i in delaySec downTo 1) {
                    CallStateManager.updateCountdown(i)
                    delay(1000)
                }

                if (call.state == Call.STATE_RINGING) {
                    Log.i(TAG, "Auto-answering call via Telecom API...")
                    try {
                        call.answer(VideoProfile.STATE_AUDIO_ONLY)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to answer call programmatically", e)
                    }
                }
            }
        }
    }

    private fun handleActiveState(call: Call) {
        autoAnswerJob?.cancel()
        CallStateManager.updateStatus(CallAssistantStatus.ACTIVE_AI_HANDLING)
        startForegroundCallNotification("Call In Progress", "AI Voice Assistant is managing this call")

        // Route to Speakerphone to enable voice capture/playback where supported
        try {
            setAudioRoute(CallAudioState.ROUTE_SPEAKER)
        } catch (e: Exception) {
            Log.e(TAG, "Error setting speakerphone audio route", e)
        }

        // Start call duration counter
        callDurationJob?.cancel()
        callDurationJob = serviceScope.launch {
            var seconds = 0
            while (call.state == Call.STATE_ACTIVE) {
                CallStateManager.setDuration(seconds++)
                delay(1000)
            }
        }

        // Launch AI Voice Agent conversational loop
        serviceScope.launch {
            CallAgentEngine.startVoiceSession(
                context = applicationContext,
                call = call,
                onConclude = {
                    Log.d(TAG, "AI Voice Session concluded. Disconnecting call.")
                    try {
                        call.disconnect()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error disconnecting call", e)
                    }
                }
            )
        }

        launchInCallUi(call, isEmergency = false)
    }

    private fun handleDisconnectedState(call: Call) {
        autoAnswerJob?.cancel()
        callDurationJob?.cancel()
        CallAgentEngine.stopVoiceSession()
        CallStateManager.updateStatus(CallAssistantStatus.DISCONNECTED)
        stopForeground(STOP_FOREGROUND_REMOVE)

        // Save call summary asynchronously
        serviceScope.launch {
            CallAgentEngine.saveCompletedCallSummary(applicationContext)
            delay(1500)
            CallStateManager.reset()
        }
    }

    private fun isEmergencyCall(call: Call, handle: String): Boolean {
        if (PhoneNumberUtils.isEmergencyNumber(handle)) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (call.details.hasProperty(Call.Details.PROPERTY_EMERGENCY_CALLBACK_MODE)) return true
        }
        return false
    }

    private fun launchInCallUi(call: Call, isEmergency: Boolean) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_IN_CALL_SCREEN", true)
            putExtra("EXTRA_IS_EMERGENCY", isEmergency)
        }
        startActivity(intent)
    }

    private fun startForegroundCallNotification(title: String, content: String) {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, AiCallAssistantApp.CHANNEL_CALL_SERVICE)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        autoAnswerJob?.cancel()
        callDurationJob?.cancel()
        currentCall = null
    }
}
