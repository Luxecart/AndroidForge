import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side GoogleGenAI initialization
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// API Routes
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
});

// Helper to execute Gemini generation with multi-model fallback (gemini-3.8-flash -> gemini-3.1-flash-lite)
async function executeGeminiWithFallback(options: {
  contents: any;
  config: any;
}) {
  try {
    return await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: options.contents,
      config: options.config,
    });
  } catch (primaryErr: any) {
    const isQuotaOrRateLimit =
      primaryErr?.status === 429 ||
      primaryErr?.message?.includes('429') ||
      primaryErr?.message?.includes('quota') ||
      primaryErr?.message?.includes('RESOURCE_EXHAUSTED');

    if (isQuotaOrRateLimit) {
      // Secondary fallback model with separate rate allocations
      return await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite',
        contents: options.contents,
        config: options.config,
      });
    }
    throw primaryErr;
  }
}

/**
 * Handle incoming conversational turn between Caller and AI Voice Assistant
 */
app.post('/api/gemini/converse', async (req, res) => {
  try {
    const {
      callerText,
      history = [],
      callerNumber = 'Unknown',
      callerName,
      languagePreference = 'auto', // 'auto', 'en', 'ur'
      customInstructions = {},
      callMode = 'BUSY', // 'SLEEP', 'BUSY', 'CUSTOM'
    } = req.body;

    const {
      assistantName = 'Hamza (AI Assistant)',
      ownerName = 'User',
      greetingEn = 'Hello! I am the AI Call Assistant for this phone. The owner is currently unavailable. How may I help you?',
      greetingUr = 'السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟',
      allowedTopics = 'General inquiries, meeting scheduling, leaving messages, urgent callback requests',
      forbiddenTopics = 'Financial information, bank details, exact current physical location, home address, passwords',
      urgentRules = 'If caller states there is a medical or life emergency, instruct them immediately to call emergency services (112 or local emergency line). For work urgency, note high priority callback.',
      personality = 'polite, professional, warm, concise, reassuring, articulate male phone assistant',
    } = customInstructions;

    const systemInstruction = `
You are "${assistantName}", an autonomous, intelligent male AI Phone Call Assistant managing incoming telephone calls on behalf of "${ownerName}".
Phone Owner Availability: Status is ${callMode} (cannot answer directly).
Caller Details: Number: ${callerNumber}, Contact Name: ${callerName || 'Unknown Caller'}.

VOICE & GENDER IDENTITY:
- You speak with a natural, clear, friendly male persona ("مردانہ آواز اور لہجہ").
- In Urdu, use natural masculine grammatical agreement when referring to yourself (مثلاً: "میں آپ کی بات نوٹ کر رہا ہوں", "میں مدد کر سکتا ہوں", "میں مالک کو آگاہ کر دوں گا").

LANGUAGE PROTOCOL (URDU BY DEFAULT & BILINGUAL):
1. Default to Urdu: Unless the caller speaks English, understand Urdu and respond in natural, polite Pakistani Urdu pronunciation and phrasing.
2. If caller speaks English or languagePreference is "en", converse in fluent, articulate English.
3. Roman Urdu / code-switching: Understand Roman Urdu ("aap kahan hain", "meeting ka waqt") seamlessly and answer in clean Urdu with spoken clarity.

AUTONOMOUS CALL MANAGEMENT PROTOCOL:
1. Transparency: Acknowledge yourself as the male AI assistant for "${ownerName}". Never pretend to be human.
2. Proactive Information Collection:
   - Guide the caller step-by-step: ask who is calling (if unknown), the specific reason/message, and whether a callback is requested.
   - If the caller shares their message, confirm you have noted it and ask if there are any specific time constraints or additional details.
3. Strict Privacy Guardrails:
   - NEVER disclose: ${forbiddenTopics}. Politely state you do not have permission to share that information.
   - Permitted topics: ${allowedTopics}.
4. Urgency & Emergency Protocol:
   - ${urgentRules}
   - If caller mentions an acute danger or life/health emergency (ambulance, hospital, fire, police), urge them immediately to call emergency dispatch (112 or local emergency line). Set isEmergency=true.
   - If caller has a high-priority work/family deadline, set isUrgent=true.
5. Call Cadence: Keep spoken turns concise (1 to 2 short sentences per turn).

You must return valid JSON matching the schema.
`;

    // Build sanitized alternating contents for Gemini multi-turn API
    const rawTurns: Array<{ role: 'user' | 'model'; text: string }> = [];

    // Normalize incoming history
    for (const msg of (history || [])) {
      const text = (msg.text || '').trim();
      if (!text) continue;
      const role = msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user';
      rawTurns.push({ role, text });
    }

    // Append current caller turn if not already present at the end
    const lastTurn = rawTurns[rawTurns.length - 1];
    if (!lastTurn || lastTurn.role !== 'user' || lastTurn.text !== callerText) {
      if (callerText && callerText.trim()) {
        rawTurns.push({ role: 'user', text: callerText.trim() });
      }
    }

    // Rule 1: Gemini requires that the first turn in contents MUST be 'user'
    if (rawTurns.length > 0 && rawTurns[0].role === 'model') {
      rawTurns.unshift({ role: 'user', text: '[Phone call connected. Caller is on the line.]' });
    }

    if (rawTurns.length === 0) {
      rawTurns.push({ role: 'user', text: callerText || 'Hello' });
    }

    // Rule 2: Gemini requires strictly alternating roles (user -> model -> user -> model)
    const alternatingTurns: Array<{ role: 'user' | 'model'; text: string }> = [];
    for (const turn of rawTurns) {
      if (alternatingTurns.length === 0) {
        alternatingTurns.push({ ...turn });
      } else {
        const prev = alternatingTurns[alternatingTurns.length - 1];
        if (prev.role === turn.role) {
          prev.text = `${prev.text}\n${turn.text}`;
        } else {
          alternatingTurns.push({ ...turn });
        }
      }
    }

    const contents = alternatingTurns.map((t) => ({
      role: t.role,
      parts: [{ text: t.text }],
    }));

    let parsed: any;
    try {
      const response = await executeGeminiWithFallback({
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              replyText: {
                type: Type.STRING,
                description: 'The exact spoken words the voice agent should speak to the caller.',
              },
              languageDetected: {
                type: Type.STRING,
                description: 'Either "en" (English) or "ur" (Urdu) or "mixed".',
              },
              intentDetected: {
                type: Type.STRING,
                description: 'Brief intent of the caller (e.g., leave_message, request_callback, urgent_inquiry, general_inquiry, spam, goodbye).',
              },
              isEmergency: {
                type: Type.BOOLEAN,
                description: 'True if caller mentions a severe emergency requiring immediate intervention.',
              },
              isUrgent: {
                type: Type.BOOLEAN,
                description: 'True if caller indicates a high-priority urgent callback is needed.',
              },
              suggestHangup: {
                type: Type.BOOLEAN,
                description: 'True if caller said goodbye or the conversation concluded naturally.',
              },
              recordedNotes: {
                type: Type.STRING,
                description: 'Any notable message or callback details gathered during this turn.',
              },
            },
            required: ['replyText', 'languageDetected', 'intentDetected', 'isEmergency', 'isUrgent', 'suggestHangup'],
          },
        },
      });

      parsed = JSON.parse(response.text || '{}');
    } catch {
      // Graceful on-device fallback if API quota or connection issue
      parsed = generateLocalConverseReply(
        callerText,
        languagePreference,
        customInstructions
      );
    }

    res.json(parsed);
  } catch {
    const localReply = generateLocalConverseReply(
      req.body?.callerText || '',
      req.body?.languagePreference || 'auto',
      req.body?.customInstructions || {}
    );
    res.json(localReply);
  }
});

/**
 * Generate comprehensive AI Call Summary and Structured Action Items
 */
app.post('/api/gemini/summarize', async (req, res) => {
  const { transcript, callerNumber, callerName, durationSeconds, timestamp } = req.body;

  try {
    const prompt = `
Analyze this completed phone call transcript handled by the AI Call Assistant.
Call Metadata:
- Caller: ${callerName || 'Unknown'} (${callerNumber || 'Unknown Number'})
- Duration: ${durationSeconds || 0} seconds
- Timestamp: ${timestamp || new Date().toISOString()}

Transcript:
${JSON.stringify(transcript, null, 2)}

Provide a comprehensive, executive summary and actionable items for the phone owner.
`;

    let parsed: any;
    try {
      const response = await executeGeminiWithFallback({
        contents: prompt,
        config: {
          systemInstruction: 'You are an intelligent executive assistant summarizing phone calls for a smartphone owner.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {
                type: Type.STRING,
                description: 'Short headline summary of the call (e.g., "Meeting rescheduling request from Dr. Tariq")',
              },
              callerIntent: {
                type: Type.STRING,
                description: 'Primary reason for the call.',
              },
              urgency: {
                type: Type.STRING,
                description: 'Urgency rating: "LOW", "MEDIUM", "HIGH", or "URGENT".',
              },
              sentiment: {
                type: Type.STRING,
                description: '"positive", "neutral", "frustrated", or "urgent".',
              },
              keyPoints: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Bullet points summarizing what was said.',
              },
              actionRequired: {
                type: Type.STRING,
                description: 'Recommended action for the owner.',
              },
              callbackRequested: {
                type: Type.BOOLEAN,
                description: 'Whether the caller asked to be called back.',
              },
              callbackTimePreference: {
                type: Type.STRING,
                description: 'Requested callback window, if any.',
              },
              language: {
                type: Type.STRING,
                description: '"English", "Urdu", or "Bilingual (English/Urdu)".',
              },
            },
            required: ['title', 'callerIntent', 'urgency', 'sentiment', 'keyPoints', 'actionRequired', 'callbackRequested'],
          },
        },
      });

      parsed = JSON.parse(response.text || '{}');
    } catch {
      // Catch quota errors and return high-fidelity structured summary generated directly from the transcript
      parsed = generateLocalSummary(transcript, callerName, callerNumber, durationSeconds);
    }

    res.json(parsed);
  } catch {
    const fallbackSummary = generateLocalSummary(transcript, callerName, callerNumber, durationSeconds);
    res.json(fallbackSummary);
  }
});

/**
 * Text-to-speech audio generation using Gemini 3.8 Flash Lite TTS / Live voice configuration.
 * Supported official Gemini voices: 'Puck' (Male, friendly/warm), 'Charon' (Male, calm/deep),
 * 'Fenrir' (Male, authoritative), 'Zephyr' (Male/Androgynous, soothing), 'Kore' (Female).
 * For natural Pakistani Urdu, 'Puck' provides clear, respectful, natural male tone.
 */
app.post('/api/gemini/tts', async (req, res) => {
  try {
    const { text, voice = 'Puck', language = 'ur' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required for TTS' });
    }

    // Supported Gemini prebuilt voices: 'Puck', 'Charon', 'Fenrir', 'Zephyr', 'Kore'
    // If user requested 'Adam', map to the closest natural male voice 'Puck' (or 'Charon')
    const supportedVoices = ['Puck', 'Charon', 'Fenrir', 'Zephyr', 'Kore'];
    let voiceName = 'Puck'; // Default male voice
    if (voice === 'Adam') {
      voiceName = 'Puck';
    } else if (supportedVoices.includes(voice)) {
      voiceName = voice;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text,
              speechMetadata: {
                style: language === 'ur'
                  ? 'Natural, clear, respectful Pakistani Urdu spoken in a friendly, polite male voice (اردو لہجہ، شائستہ اور واضح مردانہ آواز)'
                  : 'Natural, clear, articulate male phone assistant voice with friendly, professional intonation',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error('No audio data returned by model');
    }

    res.json({
      audioBase64: base64Audio,
      mimeType: 'audio/wav',
      voice: voiceName,
      isMaleVoice: ['Puck', 'Charon', 'Fenrir'].includes(voiceName),
    });
  } catch (error: any) {
    // Provide graceful fallback indicator so client can use Web Speech API fallback
    res.status(200).json({
      fallbackToClientSynthesis: true,
      voice: req.body?.voice === 'Adam' ? 'Puck' : (req.body?.voice || 'Puck'),
      error: error.message || 'TTS generation unavailable',
    });
  }
});

/**
 * Intelligent local conversation synthesizer when API quota/rate-limit is reached
 */
function generateLocalConverseReply(callerText: string, languagePreference: string, instructions: any) {
  const text = callerText || '';
  const lower = text.toLowerCase();

  const isUrdu = languagePreference === 'ur' ||
    /[\u0600-\u06FF]/.test(text) ||
    ['salam', 'kya', 'hoon', 'bol', 'aap', 'kaun', 'theek', 'shukriya', 'madad', 'rabta', 'bhai'].some(k => lower.includes(k));

  const isEmergency = ['emergency', 'hospital', 'ambulance', 'police', 'danger', 'accident', 'marna', 'zakhmi', 'fauri'].some(k => lower.includes(k));
  const isForbidden = ['bank', 'account', 'password', 'otp', 'credit card', 'paisa', 'address', 'ghar', 'location'].some(k => lower.includes(k));

  let replyText = '';
  let intent = 'general_inquiry';

  if (isEmergency) {
    intent = 'emergency';
    replyText = isUrdu
      ? 'اگر یہ کوئی ایمرجنسی یا طبی صورتحال ہے تو براہ کرم فوری 112 یا 15 پر رابطہ کریں۔ میں نے فون مالک کو ہائی الرٹ بھیج دیا ہے۔'
      : 'If this is a medical or life safety emergency, please call 911 or 112 immediately! I have flagged this as an urgent priority for the phone owner.';
  } else if (isForbidden) {
    intent = 'forbidden_request';
    replyText = isUrdu
      ? 'معذرت، مجھے سیکیورٹی اور پرائیویسی قوانین کے تحت ذاتی یا بینک اکاؤنٹ کی معلومات بتانے کی اجازت نہیں ہے۔ کیا میں کوئی پیغام نوٹ کروں؟'
      : 'I apologize, but I am strictly restricted from disclosing private financial details, passwords, or personal sensitive information. May I take a general message instead?';
  } else if (lower.includes('reschedule') || lower.includes('meeting') || lower.includes('mulaqat') || lower.includes('waqt')) {
    intent = 'reschedule_request';
    replyText = isUrdu
      ? 'جی میں نے میٹنگ کے وقت کی تبدیلی نوٹ کر لی ہے۔ مالک کو فوری آگاہ کر دیا جائے گا تاکہ وہ آپ سے رابطہ کر لیں۔'
      : 'I have noted your request to adjust the meeting time. The phone owner will be informed immediately to confirm.';
  } else if (lower.includes('salam') || lower.includes('hello') || lower.includes('hi') || lower.includes('aoa')) {
    intent = 'greeting';
    replyText = isUrdu
      ? (instructions?.greetingUr || 'وعلیکم السلام! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟')
      : (instructions?.greetingEn || 'Hello! I am the AI Call Assistant for this phone. The owner is currently unavailable. How may I assist you?');
  } else {
    intent = 'leave_message';
    replyText = isUrdu
      ? 'بہت شکریہ، میں نے آپ کی بات نوٹ کر لی ہے۔ مالک جیسے ہی دستیاب ہوں گے، آپ سے رابطہ کر لیں گے۔'
      : 'Thank you, I have documented your message. The phone owner will review this transcript and get back to you shortly.';
  }

  return {
    replyText,
    languageDetected: isUrdu ? 'ur' : 'en',
    intentDetected: intent,
    isEmergency,
    suggestHangup: false,
    recordedNotes: 'Processed via intelligent on-device fallback protocol.',
    isLocalFallback: true,
  };
}

/**
 * Intelligent local transcript analyzer when Gemini API quota/rate-limit is reached
 */
function generateLocalSummary(transcript: any[], callerName?: string, callerNumber?: string, durationSeconds?: number) {
  const turns = Array.isArray(transcript) ? transcript : [];
  const callerTurns = turns.filter((t: any) => t.role === 'user' || t.sender === 'Caller');
  const allCallerText = callerTurns.map((t: any) => t.text || t.message || '').join(' ');
  const lower = allCallerText.toLowerCase();

  const isUrdu = /[\u0600-\u06FF]/.test(allCallerText) ||
    ['salam', 'kya', 'hoon', 'bol', 'aap', 'kaun', 'theek', 'shukriya', 'zaruri', 'madad'].some(k => lower.includes(k));

  const isEmergency = ['emergency', 'hospital', 'ambulance', 'police', 'danger', 'accident', 'fauri'].some(k => lower.includes(k));
  const isUrgent = isEmergency || ['urgent', 'asap', 'important', 'zaruri', 'immediately', 'critical'].some(k => lower.includes(k));

  const isCallback = ['call back', 'callback', 'phone me', 'call me', 'dobara call', 'rabta'].some(k => lower.includes(k));

  const callerDisplayName = callerName && callerName !== 'Unknown' ? callerName : (callerNumber || 'Caller');

  const keyPoints: string[] = [];
  if (callerTurns.length > 0) {
    callerTurns.slice(0, 3).forEach((turn: any) => {
      const txt = (turn.text || turn.message || '').trim();
      if (txt) keyPoints.push(`Caller stated: "${txt.slice(0, 90)}${txt.length > 90 ? '...' : ''}"`);
    });
  } else {
    keyPoints.push(`Call completed with duration ${durationSeconds || 0} seconds.`);
  }

  let title = `Call with ${callerDisplayName}`;
  if (isEmergency) {
    title = `URGENT: Emergency alert from ${callerDisplayName}`;
  } else if (lower.includes('reschedule') || lower.includes('meeting')) {
    title = `Meeting / Schedule update from ${callerDisplayName}`;
  } else if (isCallback) {
    title = `Callback request from ${callerDisplayName}`;
  }

  return {
    title,
    callerIntent: isEmergency
      ? 'Report emergency / urgent matter'
      : (isCallback ? 'Requested phone callback from owner' : 'Left message / general inquiry'),
    urgency: isEmergency ? 'URGENT' : (isUrgent ? 'HIGH' : 'MEDIUM'),
    sentiment: isEmergency ? 'urgent' : (isUrgent ? 'frustrated' : 'neutral'),
    keyPoints: keyPoints.length > 0 ? keyPoints : ['Call recorded. Review in-app transcript.'],
    actionRequired: isEmergency
      ? 'Take immediate action or verify emergency contacts.'
      : (isCallback ? 'Return call to caller when available.' : 'Review call transcript notes.'),
    callbackRequested: isCallback || isUrgent,
    callbackTimePreference: isUrgent ? 'As soon as possible' : 'When available',
    language: isUrdu ? 'Urdu' : 'English',
    isLocalFallback: true,
  };
}

// Vite Middleware integration for Full-Stack development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });
}

startServer();
