package com.aicallassistant.data.model

data class AssistantSettings(
    val isAssistantEnabled: Boolean = true,
    val mode: String = "BUSY", // "SLEEP", "BUSY", "CUSTOM", "DIRECT_ONLY"
    val autoAnswerDelaySeconds: Int = 3,
    val assistantName: String = "Aura",
    val ownerName: String = "Phone Owner",
    val languagePreference: String = "auto", // "auto", "en", "ur"
    val greetingEn: String = "Hello! I am the AI Call Assistant for this phone. The owner is currently unavailable. How may I assist you?",
    val greetingUr: String = "السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟",
    val allowedTopics: String = "Taking messages, scheduling appointments, urgent callback requests, general polite inquiries",
    val forbiddenTopics: String = "Bank account numbers, OTPs, financial details, passwords, exact home GPS address, private travel itinerary",
    val urgentRules: String = "If medical or danger emergency, advise immediate call to emergency services (112 / 15 / 911). For urgent business, note high priority callback.",
    val personality: String = "Polite, helpful, concise, reassuring, and articulate",
    val requireCallerConsentForSummary: Boolean = true,
    val keepRecordingsLocally: Boolean = true,
    val dataRetentionDays: Int = 30
)
