import React, { useState } from 'react';
import {
  Volume2,
  Radio,
  Lock,
  Server,
  Layers,
  ArrowRight,
  ShieldCheck,
  Zap,
  Globe,
  Sliders,
  Play,
  CheckCircle2,
  Cpu,
  RefreshCw
} from 'lucide-react';
import { aiVoiceService } from '../services/AiVoiceService';

export default function VoiceServiceConsole() {
  const [selectedVoice, setSelectedVoice] = useState<'Puck' | 'Charon' | 'Fenrir' | 'Zephyr' | 'Kore'>('Puck');
  const [testLanguage, setTestLanguage] = useState<'en' | 'ur'>('ur');
  const [samplePhrase, setSamplePhrase] = useState('السلام علیکم! میں آپ کا اے آئی کال اسسٹنٹ ہوں۔ میں آپ کی کیا مدد کر سکتا ہوں؟');
  const [isAuditioning, setIsAuditioning] = useState(false);
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [isPinging, setIsPinging] = useState(false);

  const pingBackend = async () => {
    setIsPinging(true);
    const health = await aiVoiceService.checkHealth();
    setHealthStatus(health);
    setIsPinging(false);
  };

  const auditionVoice = async () => {
    setIsAuditioning(true);
    try {
      const res = await aiVoiceService.synthesizeSpeech(samplePhrase, testLanguage, selectedVoice);
      if (res.audioBase64) {
        const audio = new Audio(`data:audio/wav;base64,${res.audioBase64}`);
        audio.onended = () => setIsAuditioning(false);
        audio.onerror = () => setIsAuditioning(false);
        await audio.play();
      } else {
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          const u = new SpeechSynthesisUtterance(samplePhrase);
          u.lang = testLanguage === 'ur' ? 'ur-PK' : 'en-US';
          u.pitch = 0.9;
          u.onend = () => setIsAuditioning(false);
          window.speechSynthesis.speak(u);
        } else {
          setIsAuditioning(false);
        }
      }
    } catch {
      setIsAuditioning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Card */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <Radio className="w-5 h-5 text-teal-400" />
              <span>Real-Time AI Voice Service Architecture (Gemini Live & Flash TTS)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Modular voice streaming pipeline designed for Android Telecom integration and bidirectional audio packet handling.
            </p>
          </div>

          <button
            onClick={pingBackend}
            disabled={isPinging}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center space-x-1.5 transition-colors"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
            <span>Test Health Endpoint</span>
          </button>
        </div>

        {healthStatus && (
          <div className="mt-4 p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="text-white font-medium">Backend Health Check Passed</span>
            </div>
            <div className="flex items-center space-x-3 text-slate-400">
              <span>Latency: <strong className="text-teal-400">{healthStatus.latencyMs}ms</strong></span>
              <span>•</span>
              <span>Gemini Attached: <strong className="text-emerald-400">Verified</strong></span>
            </div>
          </div>
        )}
      </div>

      {/* Voice Audition & Persona Testing */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center space-x-2">
              <Volume2 className="w-4 h-4 text-blue-400" />
              <span>Voice Persona Auditioning</span>
            </h3>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-semibold border border-blue-500/30">
              Male Urdu Default (Puck)
            </span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300">Select AI Speech Persona</label>
            <div className="grid grid-cols-2 gap-2">
              {([
                { id: 'Puck', label: 'Puck (Male - Urdu Choice)', desc: 'Friendly, natural Pakistani Urdu cadence' },
                { id: 'Charon', label: 'Charon (Male)', desc: 'Calm, deep, executive male tone' },
                { id: 'Fenrir', label: 'Fenrir (Male)', desc: 'Authoritative, clear male tone' },
                { id: 'Zephyr', label: 'Zephyr (Neutral)', desc: 'Soothing & balanced delivery' },
                { id: 'Kore', label: 'Kore (Female)', desc: 'Articulate female persona' },
              ] as const).map((v) => (
                <button
                  key={v.id}
                  onClick={() => setSelectedVoice(v.id as any)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedVoice === v.id
                      ? 'bg-blue-600/20 border-blue-500 text-white'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <p className="font-bold text-xs">{v.label}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{v.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300">Audition Language</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setTestLanguage('en');
                  setSamplePhrase('Hello! I am your AI Call Assistant. How may I direct your call?');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border ${
                  testLanguage === 'en' ? 'bg-blue-600 text-white border-blue-500' : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                English Audition
              </button>
              <button
                onClick={() => {
                  setTestLanguage('ur');
                  setSamplePhrase('السلام علیکم! میں آپ کا اے آئی کال اسسٹنٹ ہوں۔ آپ کے لیے کیا پیغام ہے؟');
                }}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border ${
                  testLanguage === 'ur' ? 'bg-blue-600 text-white border-blue-500' : 'bg-slate-950 text-slate-400 border-slate-800'
                }`}
              >
                Urdu (اردو) Audition
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300">Audition Phrase</label>
            <textarea
              value={samplePhrase}
              onChange={(e) => setSamplePhrase(e.target.value)}
              rows={2}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white resize-none"
            />
          </div>

          <button
            onClick={auditionVoice}
            disabled={isAuditioning}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-teal-500 hover:from-blue-500 hover:to-teal-400 text-white text-xs font-bold flex items-center justify-center space-x-2 shadow-lg shadow-blue-500/20 transition-all disabled:opacity-50"
          >
            <Play className={`w-3.5 h-3.5 ${isAuditioning ? 'animate-pulse' : ''}`} />
            <span>{isAuditioning ? 'Playing Synthesized Speech...' : 'Play Voice Audition'}</span>
          </button>
        </div>

        {/* Security & Token Isolation Deep Dive */}
        <div className="lg:col-span-6 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center space-x-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>Zero-Credential Client Isolation Architecture</span>
          </h3>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-emerald-400">Security Rule #1</span>
              <p className="font-semibold text-white">No Gemini API Keys in APK or Browser</p>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Neither the Android APK nor the web client bundles raw Google API keys. All conversational turns route via <code className="text-teal-300 font-mono">/api/gemini/converse</code> through Express.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-blue-400">Audio Pipeline</span>
              <p className="font-semibold text-white">Real-Time Streaming Specs</p>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Mic Input: 16kHz PCM 16-bit mono. Output: 24kHz raw PCM / RIFF WAV streamed progressively via WebSocket / chunked HTTP for minimum voice latency.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] uppercase font-bold text-purple-400">Offline Resilience</span>
              <p className="font-semibold text-white">Safe Fallback Protocol</p>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                If cellular 4G/5G latency exceeds 4000ms or drops connection, the assistant falls back to a graceful local message taking prompt in Urdu and English.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
