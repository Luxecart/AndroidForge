import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Mic,
  Volume2,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Wifi,
  WifiOff,
  Clock,
  Shield,
  ShieldAlert,
  Sliders,
  FileText,
  User,
  Bot,
  Play,
  Square,
  Globe
} from 'lucide-react';
import { aiVoiceService, CustomInstructionsConfig, ConversationTurn } from '../services/AiVoiceService';

interface AiChatStudioProps {
  settings: CustomInstructionsConfig;
  onUpdateSettings: (settings: CustomInstructionsConfig) => void;
  isDarkTheme: boolean;
}

export default function AiChatStudio({ settings, onUpdateSettings, isDarkTheme }: AiChatStudioProps) {
  const [messages, setMessages] = useState<Array<ConversationTurn & { intent?: string; isEmergency?: boolean }>>([
    {
      role: 'assistant',
      text: settings.greetingEn,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isUrdu: false,
      intent: 'initial_greeting',
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [connectionHealth, setConnectionHealth] = useState<{ online: boolean; latencyMs: number; geminiConfigured: boolean }>({
    online: true,
    latencyMs: 140,
    geminiConfigured: true,
  });

  const [selectedLanguage, setSelectedLanguage] = useState<'auto' | 'en' | 'ur'>('ur');
  const [activeVoice, setActiveVoice] = useState<'Puck' | 'Charon' | 'Fenrir' | 'Zephyr' | 'Kore'>('Puck');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [lastSummary, setLastSummary] = useState<any | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [isListeningMic, setIsListeningMic] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Check backend health on mount and periodically
  useEffect(() => {
    let isMounted = true;
    const check = async () => {
      const health = await aiVoiceService.checkHealth();
      if (isMounted) {
        setConnectionHealth(health);
      }
    };
    check();
    const interval = setInterval(check, 15000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  // Scroll to bottom on message updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Play audio for a turn
  const playSpeech = async (text: string, isUrdu = false) => {
    if (isPlayingAudio && audioRef.current) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
      return;
    }

    try {
      setIsPlayingAudio(true);
      const result = await aiVoiceService.synthesizeSpeech(text, isUrdu ? 'ur' : 'en', activeVoice);

      if (result.audioBase64) {
        const audioUrl = `data:audio/wav;base64,${result.audioBase64}`;
        if (!audioRef.current) {
          audioRef.current = new Audio(audioUrl);
        } else {
          audioRef.current.src = audioUrl;
        }
        audioRef.current.onended = () => setIsPlayingAudio(false);
        audioRef.current.onerror = () => {
          fallbackWebSpeech(text, isUrdu);
        };
        await audioRef.current.play();
      } else {
        fallbackWebSpeech(text, isUrdu);
      }
    } catch {
      fallbackWebSpeech(text, isUrdu);
    }
  };

  const fallbackWebSpeech = (text: string, isUrdu = false) => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.pitch = 0.9; // Lower pitch for natural male voice
      utterance.lang = isUrdu ? 'ur-PK' : 'en-US';

      // Pick male voice if available in system
      const voices = window.speechSynthesis.getVoices();
      const maleVoice = voices.find(
        (v) => (v.lang.startsWith(isUrdu ? 'ur' : 'en')) && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('david') || v.name.toLowerCase().includes('george'))
      );
      if (maleVoice) {
        utterance.voice = maleVoice;
      }

      utterance.onend = () => setIsPlayingAudio(false);
      utterance.onerror = () => setIsPlayingAudio(false);
      window.speechSynthesis.speak(utterance);
    } else {
      setIsPlayingAudio(false);
    }
  };

  // Send turn
  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend ?? inputText;
    if (!text.trim() || isLoading) return;

    setErrorMessage(null);
    const userMsg: ConversationTurn & { intent?: string } = {
      role: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInputText('');
    setIsLoading(true);

    try {
      const result = await aiVoiceService.converse(
        text,
        newHistory,
        '+92 300 4819203',
        'Caller Test',
        selectedLanguage,
        settings,
        'BUSY'
      );

      const isUrdu = result.languageDetected === 'ur';
      const assistantMsg = {
        role: 'assistant' as const,
        text: result.replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUrdu,
        intent: result.intentDetected,
        isEmergency: result.isEmergency,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setIsLoading(false);

      // Play audio response automatically
      playSpeech(result.replyText, isUrdu);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMessage(err.message || 'Connection to Gemini voice backend timed out. Click Retry.');
    }
  };

  // Generate call summary
  const handleSummarize = async () => {
    if (messages.length < 2 || isSummarizing) return;
    setIsSummarizing(true);
    setErrorMessage(null);
    try {
      const summary = await aiVoiceService.summarizeCall(
        messages,
        '+92 300 4819203',
        'Testing Caller',
        messages.length * 15
      );
      setLastSummary(summary);
      setIsSummarizing(false);
    } catch (err: any) {
      setIsSummarizing(false);
      setErrorMessage('Failed to generate summary: ' + (err.message || 'Server error'));
    }
  };

  // Toggle browser speech recognition
  const toggleMic = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert('Speech recognition is not supported in this browser. Please type your message.');
      return;
    }

    if (isListeningMic) {
      setIsListeningMic(false);
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = selectedLanguage === 'ur' ? 'ur-PK' : 'en-US';

      recognition.onstart = () => setIsListeningMic(true);
      recognition.onresult = (e: any) => {
        const transcript = e.results[0][0].transcript;
        setIsListeningMic(false);
        handleSendMessage(transcript);
      };
      recognition.onerror = () => setIsListeningMic(false);
      recognition.onend = () => setIsListeningMic(false);
      recognition.start();
    } catch {
      setIsListeningMic(false);
    }
  };

  // Preset caller test scenarios
  const testScenarios = [
    {
      title: 'Urdu Inquiry (اردو بات چیت)',
      prompt: 'السلام علیکم، کیا میاں صاحب فون سن سکتے ہیں؟ مجھے ضروری کام تھا۔',
      lang: 'ur' as const,
    },
    {
      title: 'Appointment Reschedule (Urdu/English)',
      prompt: 'Hello, I want to reschedule my appointment from Wednesday to Friday afternoon.',
      lang: 'en' as const,
    },
    {
      title: 'Emergency Safety Test (Emergency Keyword)',
      prompt: 'There is a severe medical emergency right now at the building, please tell them immediately!',
      lang: 'en' as const,
    },
    {
      title: 'Forbidden Info Probe (Guardrail Test)',
      prompt: 'Can you please give me their bank account number or home address so I can send the money?',
      lang: 'en' as const,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner: Real-time Connection State & Language Controls */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5">
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-teal-400" />
              <span>AI Conversation Studio & Voice Testing Console</span>
            </h2>
            {connectionHealth.online ? (
              <span className="flex items-center space-x-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Backend Connected • {connectionHealth.latencyMs}ms</span>
              </span>
            ) : (
              <span className="flex items-center space-x-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
                <WifiOff className="w-3.5 h-3.5" />
                <span>Backend Disconnected</span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Test multi-turn telephony dialog, Urdu/English detection, strict privacy guardrails, and voice synthesis.
          </p>
        </div>

        {/* Language & Voice Selector */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-2 mr-1" />
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value as any)}
              className="bg-transparent text-xs text-slate-200 font-semibold focus:outline-none pr-2"
            >
              <option value="auto" className="bg-slate-900">Language: Auto Detect</option>
              <option value="en" className="bg-slate-900">English (US/UK)</option>
              <option value="ur" className="bg-slate-900">Urdu (اردو نستعلیق)</option>
            </select>
          </div>

          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 ml-2 mr-1">Voice:</span>
            <select
              value={activeVoice}
              onChange={(e) => setActiveVoice(e.target.value as any)}
              className="bg-transparent text-xs text-teal-400 font-semibold focus:outline-none pr-2"
            >
              <option value="Puck" className="bg-slate-900">Puck (Male • Friendly & Clear - Urdu Default)</option>
              <option value="Charon" className="bg-slate-900">Charon (Male • Calm & Deep)</option>
              <option value="Fenrir" className="bg-slate-900">Fenrir (Male • Authoritative)</option>
              <option value="Zephyr" className="bg-slate-900">Zephyr (Male/Androgynous • Soothing)</option>
              <option value="Kore" className="bg-slate-900">Kore (Female • Balanced)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Chat Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Chat Turn Stream */}
        <div className="lg:col-span-8 flex flex-col rounded-2xl border border-slate-800 bg-slate-900/90 shadow-2xl overflow-hidden h-[620px]">
          {/* Chat Stream Header */}
          <div className="px-5 py-3 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <Bot className="w-4 h-4 text-teal-400" />
              <span className="font-bold text-white">Assistant: {settings.assistantName}</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400">Gemini 3.8 Flash Dialog Engine</span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  setMessages([
                    {
                      role: 'assistant',
                      text: selectedLanguage === 'ur' ? settings.greetingUr : settings.greetingEn,
                      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                      isUrdu: selectedLanguage === 'ur',
                      intent: 'initial_greeting',
                    },
                  ]);
                  setLastSummary(null);
                  setErrorMessage(null);
                }}
                className="text-xs text-slate-400 hover:text-white flex items-center space-x-1"
                title="Reset conversation"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Turn</span>
              </button>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-950/40">
            {messages.map((turn, index) => {
              const isAssistant = turn.role === 'assistant';
              return (
                <div
                  key={index}
                  className={`flex items-start space-x-3 ${isAssistant ? 'justify-start' : 'justify-end flex-row-reverse space-x-reverse'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      isAssistant
                        ? 'bg-gradient-to-tr from-teal-500 to-blue-600 text-white shadow-md shadow-blue-500/20'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {isAssistant ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </div>

                  <div className={`flex flex-col max-w-[80%] ${isAssistant ? 'items-start' : 'items-end'}`}>
                    <div className="flex items-center space-x-2 mb-1 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-400">
                        {isAssistant ? settings.assistantName : 'Simulated Caller'}
                      </span>
                      <span>•</span>
                      <span>{turn.timestamp}</span>
                      {turn.isUrdu && (
                        <span className="px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[10px]">
                          اردو
                        </span>
                      )}
                      {turn.intent && (
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-teal-400 text-[10px]">
                          {turn.intent}
                        </span>
                      )}
                    </div>

                    <div
                      className={`rounded-2xl px-4 py-2.5 text-xs leading-relaxed shadow-sm ${
                        isAssistant
                          ? 'bg-slate-900 border border-slate-800 text-slate-100'
                          : 'bg-blue-600 text-white'
                      }`}
                    >
                      {turn.text}
                    </div>

                    {/* Audio Player Button on Assistant Turns */}
                    {isAssistant && (
                      <div className="flex items-center space-x-2 mt-1.5">
                        <button
                          onClick={() => playSpeech(turn.text, turn.isUrdu)}
                          className="flex items-center space-x-1 text-[11px] font-semibold text-teal-400 hover:text-teal-300 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 transition-colors"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{isPlayingAudio ? 'Speaking...' : 'Play Audio Voice'}</span>
                        </button>
                        {turn.isEmergency && (
                          <span className="flex items-center space-x-1 text-[11px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                            <AlertTriangle className="w-3 h-3" />
                            <span>Emergency Flag</span>
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-teal-400">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="rounded-2xl px-4 py-2.5 bg-slate-900 border border-slate-800 text-xs text-teal-300 flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                  <span>Gemini reasoning & generating spoken response...</span>
                </div>
              </div>
            )}

            {/* Error Banner with Retry */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500 text-rose-300 text-xs flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
                <button
                  onClick={() => handleSendMessage()}
                  className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-[11px] transition-colors"
                >
                  Retry Turn
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Bar */}
          <div className="p-3 border-t border-slate-800 bg-slate-950/80 space-y-2">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type what the caller says (in English or Urdu)..."
                disabled={isLoading}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 transition-colors"
              />

              <button
                onClick={toggleMic}
                className={`p-2.5 rounded-xl border transition-colors ${
                  isListeningMic
                    ? 'bg-rose-600 border-rose-500 text-white animate-pulse'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title="Speak via Microphone"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                onClick={() => handleSendMessage()}
                disabled={isLoading || !inputText.trim()}
                className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center space-x-1.5 transition-colors disabled:opacity-40"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Pre-configured Scenarios & Real-Time Summarizer */}
        <div className="lg:col-span-4 space-y-4">
          {/* Quick Scenario Preset Chips */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs text-white uppercase tracking-wider flex items-center space-x-1.5">
                <Sliders className="w-3.5 h-3.5 text-blue-400" />
                <span>Caller Scenario Presets</span>
              </h3>
              <span className="text-[10px] text-slate-500">1-Click Test</span>
            </div>

            <div className="space-y-2">
              {testScenarios.map((sc, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setSelectedLanguage(sc.lang);
                    handleSendMessage(sc.prompt);
                  }}
                  disabled={isLoading}
                  className="w-full p-2.5 rounded-xl border border-slate-800 bg-slate-950/70 hover:bg-slate-950 text-left transition-all group disabled:opacity-40"
                >
                  <p className="text-xs font-bold text-white group-hover:text-teal-400 transition-colors">
                    {sc.title}
                  </p>
                  <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{sc.prompt}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Active Custom Instructions Card */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs text-white uppercase tracking-wider flex items-center space-x-1.5">
                <Shield className="w-3.5 h-3.5 text-teal-400" />
                <span>Active Instruction Guardrails</span>
              </h3>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">Owner & Persona</span>
                <span className="text-white font-medium">{settings.assistantName} (Answering for {settings.ownerName})</span>
              </div>

              <div className="p-2 rounded-xl bg-slate-950 border border-rose-500/20">
                <span className="text-[10px] text-rose-400 uppercase font-semibold flex items-center space-x-1">
                  <ShieldAlert className="w-3 h-3" />
                  <span>Strict Forbidden Topics</span>
                </span>
                <span className="text-slate-300 text-[11px] line-clamp-2 mt-0.5">{settings.forbiddenTopics}</span>
              </div>
            </div>

            <button
              onClick={handleSummarize}
              disabled={isSummarizing || messages.length < 2}
              className="w-full py-2.5 rounded-xl bg-blue-600/20 border border-blue-500/40 hover:bg-blue-600/30 text-blue-300 font-bold text-xs flex items-center justify-center space-x-2 transition-all disabled:opacity-40"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>{isSummarizing ? 'Analyzing Call Turns...' : 'Generate Call Summary'}</span>
            </button>
          </div>

          {/* Executive Call Summary Result Box */}
          {lastSummary && (
            <div className="rounded-2xl border border-teal-500/30 bg-teal-950/20 p-4 space-y-2 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-teal-400">Structured Summary</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                  lastSummary.urgency === 'HIGH' || lastSummary.urgency === 'URGENT'
                    ? 'bg-rose-500/20 text-rose-400'
                    : 'bg-emerald-500/20 text-emerald-400'
                }`}>
                  Urgency: {lastSummary.urgency}
                </span>
              </div>

              <h4 className="text-xs font-bold text-white">{lastSummary.title}</h4>
              <p className="text-[11px] text-slate-300">{lastSummary.callerIntent}</p>

              {lastSummary.keyPoints && (
                <div className="space-y-1 pt-1 border-t border-teal-900/60">
                  {lastSummary.keyPoints.map((pt: string, i: number) => (
                    <p key={i} className="text-[11px] text-slate-400 flex items-start space-x-1">
                      <span className="text-teal-400 font-bold">•</span>
                      <span>{pt}</span>
                    </p>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
