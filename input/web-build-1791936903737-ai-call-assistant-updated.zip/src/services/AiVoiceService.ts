/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type VoiceSessionStatus = 'DISCONNECTED' | 'CONNECTING' | 'READY' | 'STREAMING' | 'ERROR';

export type SupportedLanguage = 'auto' | 'en' | 'ur';

export interface CustomInstructionsConfig {
  assistantName: string;
  ownerName: string;
  greetingEn: string;
  greetingUr: string;
  allowedTopics: string;
  forbiddenTopics: string;
  urgentRules: string;
  personality: string;
}

export interface ConversationTurn {
  role: 'assistant' | 'user';
  text: string;
  timestamp: string;
  isUrdu?: boolean;
}

export interface VoiceTurnResult {
  replyText: string;
  languageDetected: 'en' | 'ur' | 'mixed';
  intentDetected: string;
  isEmergency: boolean;
  isUrgent?: boolean;
  suggestHangup: boolean;
  recordedNotes?: string;
}

export interface AudioBufferResult {
  audioBase64?: string;
  mimeType: string;
  voice: string;
  fallbackToClientSynthesis?: boolean;
}

export interface CallSummaryResult {
  title: string;
  callerIntent: string;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  sentiment: 'positive' | 'neutral' | 'frustrated' | 'urgent';
  keyPoints: string[];
  actionRequired: string;
  callbackRequested: boolean;
  callbackTimePreference?: string;
  language?: string;
}

export interface VoiceServiceError {
  code: string;
  message: string;
  isRecoverable: boolean;
  timestamp: number;
}

/**
 * High-level AI Voice Service contract designed for low-latency phone assistant operations.
 * Separates client-side audio/text orchestration from server-side Gemini credential management.
 */
export interface IAiVoiceService {
  getStatus(): VoiceSessionStatus;
  checkHealth(): Promise<{ online: boolean; latencyMs: number; geminiConfigured: boolean }>;
  converse(
    callerText: string,
    history: ConversationTurn[],
    callerNumber: string,
    callerName: string,
    language: SupportedLanguage,
    instructions: CustomInstructionsConfig,
    callMode: string
  ): Promise<VoiceTurnResult>;
  synthesizeSpeech(text: string, language: SupportedLanguage, voiceName?: string): Promise<AudioBufferResult>;
  summarizeCall(
    transcript: ConversationTurn[],
    callerNumber: string,
    callerName: string,
    durationSeconds: number
  ): Promise<CallSummaryResult>;
}

/**
 * Concrete implementation communicating via secure backend proxy endpoints.
 * Never stores or exposes Google Gemini API keys in the client bundle.
 */
export class BackendAiVoiceService implements IAiVoiceService {
  private status: VoiceSessionStatus = 'READY';
  private errorListeners: Array<(err: VoiceServiceError) => void> = [];
  private stateListeners: Array<(status: VoiceSessionStatus) => void> = [];

  getStatus(): VoiceSessionStatus {
    return this.status;
  }

  onStateChange(cb: (status: VoiceSessionStatus) => void) {
    this.stateListeners.push(cb);
  }

  onError(cb: (err: VoiceServiceError) => void) {
    this.errorListeners.push(cb);
  }

  private setStatus(newStatus: VoiceSessionStatus) {
    this.status = newStatus;
    this.stateListeners.forEach((listener) => listener(newStatus));
  }

  private emitError(code: string, message: string, isRecoverable = true) {
    this.setStatus('ERROR');
    const err: VoiceServiceError = {
      code,
      message,
      isRecoverable,
      timestamp: Date.now(),
    };
    this.errorListeners.forEach((listener) => listener(err));
  }

  async checkHealth(): Promise<{ online: boolean; latencyMs: number; geminiConfigured: boolean }> {
    const startTime = performance.now();
    try {
      const response = await fetch('/api/health');
      const latencyMs = Math.round(performance.now() - startTime);
      if (!response.ok) {
        throw new Error(`Health check returned status ${response.status}`);
      }
      const data = await response.json();
      return {
        online: true,
        latencyMs,
        geminiConfigured: Boolean(data.geminiConfigured),
      };
    } catch (err: any) {
      return {
        online: false,
        latencyMs: -1,
        geminiConfigured: false,
      };
    }
  }

  async converse(
    callerText: string,
    history: ConversationTurn[],
    callerNumber: string,
    callerName: string,
    language: SupportedLanguage,
    instructions: CustomInstructionsConfig,
    callMode: string
  ): Promise<VoiceTurnResult> {
    this.setStatus('STREAMING');
    try {
      const response = await fetch('/api/gemini/converse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerText,
          history,
          callerNumber,
          callerName,
          languagePreference: language,
          customInstructions: instructions,
          callMode,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Server returned error HTTP ${response.status}`);
      }

      const result: VoiceTurnResult = await response.json();
      this.setStatus('READY');
      return result;
    } catch (err: any) {
      this.emitError('CONVERSE_FAILED', err.message || 'Failed to communicate with AI assistant');
      throw err;
    }
  }

  async synthesizeSpeech(text: string, language: SupportedLanguage, voiceName = 'Puck'): Promise<AudioBufferResult> {
    try {
      const response = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          language,
          voice: voiceName,
        }),
      });

      if (!response.ok) {
        return {
          mimeType: 'audio/wav',
          voice: voiceName,
          fallbackToClientSynthesis: true,
        };
      }

      return await response.json();
    } catch {
      return {
        mimeType: 'audio/wav',
        voice: voiceName,
        fallbackToClientSynthesis: true,
      };
    }
  }

  async summarizeCall(
    transcript: ConversationTurn[],
    callerNumber: string,
    callerName: string,
    durationSeconds: number
  ): Promise<CallSummaryResult> {
    try {
      const response = await fetch('/api/gemini/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript,
          callerNumber,
          callerName,
          durationSeconds,
          timestamp: new Date().toISOString(),
        }),
      });

      if (!response.ok) {
        return this.getLocalFallbackSummary(transcript, callerNumber, callerName, durationSeconds);
      }

      return await response.json();
    } catch (err: any) {
      console.warn('Network issue in summarizeCall, using local fallback summary:', err);
      return this.getLocalFallbackSummary(transcript, callerNumber, callerName, durationSeconds);
    }
  }

  private getLocalFallbackSummary(
    transcript: ConversationTurn[],
    callerNumber: string,
    callerName: string,
    durationSeconds: number
  ): CallSummaryResult {
    const callerTurns = transcript.filter((t) => t.role === 'user');
    const firstMessage = callerTurns[0]?.text || 'Call completed';
    return {
      title: `Call with ${callerName || callerNumber}`,
      callerIntent: firstMessage.length > 50 ? `${firstMessage.slice(0, 50)}...` : firstMessage,
      urgency: 'MEDIUM',
      sentiment: 'neutral',
      keyPoints: callerTurns.length > 0
        ? callerTurns.slice(0, 3).map((t) => `Caller: "${t.text.slice(0, 80)}"`)
        : [`Call lasted ${durationSeconds} seconds.`],
      actionRequired: 'Review in-app transcript and callback if needed.',
      callbackRequested: true,
      language: transcript.some((t) => t.isUrdu) ? 'Urdu' : 'English',
    };
  }
}

export const aiVoiceService = new BackendAiVoiceService();
