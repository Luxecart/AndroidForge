import React, { useState, useEffect, useRef } from 'react';
import {
  Phone,
  PhoneCall,
  PhoneIncoming,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Shield,
  ShieldAlert,
  Settings,
  BatteryCharging,
  Users,
  History,
  FileCode2,
  Layers,
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Send,
  Download,
  Copy,
  Check,
  ChevronRight,
  Info,
  Globe,
  Sliders,
  Smartphone,
  Trash2,
  Lock,
  Moon,
  Sun,
  Radio,
  Bell
} from 'lucide-react';
import AiChatStudio from './components/AiChatStudio';
import VoiceServiceConsole from './components/VoiceServiceConsole';

// Type definitions matching Android Kotlin models
interface ContactRule {
  id: string;
  name: string;
  phoneNumber: string;
  ruleType: 'VIP_BYPASS_AI' | 'AI_STANDARD_HANDLE' | 'BLOCK_CALLER';
  customNotes?: string;
}

interface TranscriptEntry {
  role: 'assistant' | 'user';
  text: string;
  timestamp: string;
  isUrdu?: boolean;
}

interface CallLogEntry {
  id: string;
  callerNumber: string;
  callerName: string;
  timestamp: number;
  durationSeconds: number;
  summaryTitle: string;
  summaryIntent: string;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  keyPoints: string[];
  callbackRequested: boolean;
  transcript: TranscriptEntry[];
  language?: string;
}

interface AssistantSettings {
  isAssistantEnabled: boolean;
  mode: 'BUSY' | 'SLEEP' | 'CUSTOM';
  autoAnswerDelaySeconds: number;
  assistantName: string;
  ownerName: string;
  languagePreference: 'auto' | 'en' | 'ur';
  voicePersona: 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr' | 'Kore';
  greetingEn: string;
  greetingUr: string;
  allowedTopics: string;
  forbiddenTopics: string;
  urgentRules: string;
  personality: string;
  keepRecordingsLocally: boolean;
}

export default function App() {
  // Navigation tabs in the Workbench
  const [activeTab, setActiveTab] = useState<'simulator' | 'ai_chat' | 'voice_service' | 'code' | 'architecture' | 'vivo_guide'>('simulator');
  const [deviceScreen, setDeviceScreen] = useState<'dashboard' | 'active_call' | 'instructions' | 'contacts' | 'history' | 'settings' | 'permissions'>('dashboard');
  const [isDarkTheme, setIsDarkTheme] = useState(true);

  // Settings state (mirrors DataStore)
  const [settings, setSettings] = useState<AssistantSettings>({
    isAssistantEnabled: true,
    mode: 'BUSY',
    autoAnswerDelaySeconds: 3,
    assistantName: 'Hamza (AI Voice Agent)',
    ownerName: 'Phone Owner',
    languagePreference: 'ur',
    voicePersona: 'Puck',
    greetingEn: 'Hello! I am the AI Call Assistant for this phone. The owner is currently unavailable. How may I assist you?',
    greetingUr: 'السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟',
    allowedTopics: 'Taking messages, scheduling appointments, urgent callback requests, general inquiries',
    forbiddenTopics: 'Bank accounts, OTPs, financial balances, passwords, home address, travel schedules',
    urgentRules: 'If medical or danger emergency, advise immediate call to emergency services (112 / 15 / 911).',
    personality: 'Polite, helpful, concise, reassuring, articulate male phone assistant with clear Pakistani Urdu cadence',
    keepRecordingsLocally: true,
  });

  // Urgent Notifications & Privacy State
  const [urgentAlerts, setUrgentAlerts] = useState<Array<{
    id: string;
    callerName: string;
    callerNumber: string;
    text: string;
    time: string;
    type: 'EMERGENCY' | 'URGENT';
  }>>([
    {
      id: 'alert-1',
      callerName: 'Dr. Rashid Khan (Clinic)',
      callerNumber: '+92 333 5519823',
      text: 'Patient milestone report submitted. Urgent review requested by 5 PM.',
      time: '10:15 AM',
      type: 'URGENT',
    },
  ]);
  const [showUrgentModal, setShowUrgentModal] = useState(false);
  const [incognitoMode, setIncognitoMode] = useState(false);
  const [retentionDays, setRetentionDays] = useState(30);

  // Telecom Call Simulation State
  const [callStatus, setCallStatus] = useState<'IDLE' | 'RINGING' | 'AUTO_ANSWERING' | 'ACTIVE' | 'TAKEOVER' | 'ENDED'>('IDLE');
  const [simulatedCaller, setSimulatedCaller] = useState({ name: 'Hamza Tariq', number: '+92 301 4829104' });
  const [countdown, setCountdown] = useState(3);
  const [callDuration, setCallDuration] = useState(0);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
  const [callerInputText, setCallerInputText] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [emergencyAlert, setEmergencyAlert] = useState(false);

  // Contact Rules (VIP & Blacklist)
  const [contactRules, setContactRules] = useState<ContactRule[]>([
    { id: '1', name: 'Family (Mother)', phoneNumber: '+92 300 1234567', ruleType: 'VIP_BYPASS_AI', customNotes: 'Immediate direct ring, bypass AI' },
    { id: '2', name: 'TCS Courier', phoneNumber: '+92 321 9876543', ruleType: 'AI_STANDARD_HANDLE', customNotes: 'Collect parcel gate instructions' },
    { id: '3', name: 'Telemarketing Spam', phoneNumber: '+92 345 0000000', ruleType: 'BLOCK_CALLER', customNotes: 'CallScreeningService silent drop' },
  ]);

  // Call Logs & History
  const [callLogs, setCallLogs] = useState<CallLogEntry[]>([
    {
      id: 'demo-1',
      callerName: 'Hamza Ali (Client)',
      callerNumber: '+92 301 8492019',
      timestamp: Date.now() - 1000 * 60 * 35,
      durationSeconds: 58,
      summaryTitle: 'Project milestone review call rescheduled',
      summaryIntent: 'Confirmed rescheduling of the product sync to Thursday morning',
      urgency: 'HIGH',
      keyPoints: [
        'Hamza reviewed the Q3 mobile app release proposal.',
        'Requested 15-minute confirmation call on Thursday at 11 AM.',
        'Mentioned urgent design sign-off needed before sprint lock.'
      ],
      callbackRequested: true,
      transcript: [
        { role: 'assistant', text: 'السلام علیکم! میں اس فون کا اے آئی کال اسسٹنٹ ہوں۔ مالک اس وقت دستیاب نہیں ہیں۔ میں آپ کی کیا مدد کر سکتا ہوں؟', timestamp: '11:02 AM', isUrdu: true },
        { role: 'user', text: 'Walaikum Assalam, mein Hamza bol raha hoon. Mujhay kal ki meeting reschedule karni thi.', timestamp: '11:02 AM' },
        { role: 'assistant', text: 'جی حمزہ صاحب، میں نے نوٹ کر لیا ہے۔ کیا آپ جمعرات کی صبح مناسب سمجھیں گے؟', timestamp: '11:03 AM', isUrdu: true },
        { role: 'user', text: 'Haan Thursday 11 AM theek rahay ga. Please unko bol dain callback kar dain.', timestamp: '11:03 AM' },
        { role: 'assistant', text: 'بہت شکریہ، میں نے ہائی پرائرٹی کے ساتھ نوٹ کر لیا ہے۔ اللہ حافظ۔', timestamp: '11:03 AM', isUrdu: true }
      ]
    },
    {
      id: 'demo-2',
      callerName: 'DHL Logistics Delivery',
      callerNumber: '+92 322 4118920',
      timestamp: Date.now() - 1000 * 60 * 160,
      durationSeconds: 32,
      summaryTitle: 'Package delivered to building front security',
      summaryIntent: 'Courier delivered parcel #PK8832 at front reception',
      urgency: 'MEDIUM',
      keyPoints: ['Package dropped with front desk guard.', 'Signature recorded on delivery handheld.'],
      callbackRequested: false,
      transcript: [
        { role: 'assistant', text: 'Hello! I am the AI Call Assistant for this phone. How may I assist you?', timestamp: '09:15 AM' },
        { role: 'user', text: 'Hello, I have a parcel for your apartment. Reception guard is here.', timestamp: '09:15 AM' },
        { role: 'assistant', text: 'Please leave the parcel with security guard at reception. Thank you!', timestamp: '09:16 AM' },
        { role: 'user', text: 'Okay done, package dropped. Thanks.', timestamp: '09:16 AM' },
        { role: 'assistant', text: 'Have a great day!', timestamp: '09:16 AM' }
      ]
    }
  ]);

  // Vivo status indicators
  const [isDefaultDialerRole, setIsDefaultDialerRole] = useState(true);
  const [isVivoWhitelisted, setIsVivoWhitelisted] = useState(true);
  const [selectedFileForInspection, setSelectedFileForInspection] = useState<string>('AssistantInCallService.kt');
  const [copiedFile, setCopiedFile] = useState(false);
  const [isSpeechRecognitionActive, setIsSpeechRecognitionActive] = useState(false);

  // Audio stream reference for Web Speech synthesis
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Timer for Call duration
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callStatus === 'ACTIVE' || callStatus === 'TAKEOVER') {
      interval = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callStatus]);

  // Timer for Auto-Answer Countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callStatus === 'AUTO_ANSWERING') {
      interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            answerCallAsAi();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callStatus, settings.autoAnswerDelaySeconds]);

  // Speak response using Gemini TTS backend (Male Urdu Puck voice) or Web Speech fallback
  const speakText = async (text: string, isUrdu = false) => {
    try {
      const response = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          language: isUrdu ? 'ur' : 'en',
          voice: settings.voicePersona || 'Puck',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.audioBase64) {
          const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
          await audio.play();
          return;
        }
      }
    } catch {
      // Fallback below
    }

    // Client Web Speech fallback with natural male pitch
    if (synthRef.current) {
      try {
        synthRef.current.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;
        utterance.pitch = 0.9; // Lower pitch for male tone
        utterance.lang = isUrdu ? 'ur-PK' : 'en-US';

        const voices = synthRef.current.getVoices();
        const maleVoice = voices.find(
          (v) => (v.lang.startsWith(isUrdu ? 'ur' : 'en')) && (v.name.toLowerCase().includes('male') || v.name.toLowerCase().includes('david') || v.name.toLowerCase().includes('george'))
        );
        if (maleVoice) {
          utterance.voice = maleVoice;
        }

        synthRef.current.speak(utterance);
      } catch (e) {
        console.warn('Speech synthesis error:', e);
      }
    }
  };

  // Start Incoming Call Simulation
  const triggerIncomingCall = (callerName = 'Dr. Rashid Khan', callerNumber = '+92 333 5519823') => {
    // Check if blocked
    const isBlocked = contactRules.some(
      (r) => r.ruleType === 'BLOCK_CALLER' && r.phoneNumber.replace(/\s+/g, '') === callerNumber.replace(/\s+/g, '')
    );
    if (isBlocked) {
      alert(`[CallScreeningService]: Call from ${callerNumber} blocked silently before ringing.`);
      return;
    }

    setSimulatedCaller({ name: callerName, number: callerNumber });
    setCallDuration(0);
    setTranscript([]);
    setEmergencyAlert(false);
    setDeviceScreen('active_call');

    // VIP check
    const isVip = contactRules.some(
      (r) => r.ruleType === 'VIP_BYPASS_AI' && r.phoneNumber.replace(/\s+/g, '') === callerNumber.replace(/\s+/g, '')
    );

    if (!settings.isAssistantEnabled || isVip) {
      setCallStatus('RINGING');
      return;
    }

    // Auto-answering countdown starts
    setCountdown(settings.autoAnswerDelaySeconds);
    setCallStatus('AUTO_ANSWERING');
  };

  // Answer call programmatically (Telecom InCallService answer API)
  const answerCallAsAi = async () => {
    setCallStatus('ACTIVE');
    const isUrdu = settings.languagePreference === 'ur';
    const initialGreeting = isUrdu ? settings.greetingUr : settings.greetingEn;

    const entry: TranscriptEntry = {
      role: 'assistant',
      text: initialGreeting,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isUrdu,
    };
    setTranscript([entry]);
    speakText(initialGreeting, isUrdu);
  };

  // Caller speaks turn to AI
  const handleCallerSpeech = async (speechText: string) => {
    if (!speechText.trim() || isAiThinking) return;

    const callerEntry: TranscriptEntry = {
      role: 'user',
      text: speechText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedTranscript = [...transcript, callerEntry];
    setTranscript(updatedTranscript);
    setCallerInputText('');
    setIsAiThinking(true);

    try {
      const response = await fetch('/api/gemini/converse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerText: speechText,
          history: updatedTranscript,
          callerNumber: simulatedCaller.number,
          callerName: simulatedCaller.name,
          languagePreference: settings.languagePreference,
          customInstructions: settings,
          callMode: settings.mode,
        }),
      });

      const data = await response.json();
      setIsAiThinking(false);

      if (data.isEmergency || data.isUrgent) {
        setEmergencyAlert(true);
        setUrgentAlerts((prev) => [
          {
            id: Date.now().toString(),
            callerName: simulatedCaller.name,
            callerNumber: simulatedCaller.number,
            text: speechText,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: data.isEmergency ? 'EMERGENCY' : 'URGENT',
          },
          ...prev,
        ]);
      }

      const reply = data.replyText || "I've noted your message and will notify the owner.";
      const isUrdu = data.languageDetected === 'ur';

      const aiEntry: TranscriptEntry = {
        role: 'assistant',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isUrdu,
      };

      setTranscript((prev) => [...prev, aiEntry]);
      speakText(reply, isUrdu);

      if (data.suggestHangup) {
        setTimeout(() => {
          endCurrentCall();
        }, 3500);
      }
    } catch (err) {
      console.error(err);
      setIsAiThinking(false);
      const fallbackReply = "I have recorded your request and the owner will get back to you shortly.";
      setTranscript((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: fallbackReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakText(fallbackReply, false);
    }
  };

  // End Call & Summarize via Gemini
  const endCurrentCall = async () => {
    if (synthRef.current) synthRef.current.cancel();
    setCallStatus('ENDED');

    if (transcript.length > 0) {
      try {
        const sumRes = await fetch('/api/gemini/summarize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            transcript,
            callerNumber: simulatedCaller.number,
            callerName: simulatedCaller.name,
            durationSeconds: callDuration,
            timestamp: new Date().toISOString(),
          }),
        });
        const summaryData = await sumRes.json();

        const newLog: CallLogEntry = {
          id: Date.now().toString(),
          callerName: simulatedCaller.name,
          callerNumber: simulatedCaller.number,
          timestamp: Date.now(),
          durationSeconds: callDuration,
          summaryTitle: summaryData.title || `Call with ${simulatedCaller.name}`,
          summaryIntent: summaryData.callerIntent || 'Message recorded',
          urgency: summaryData.urgency || 'MEDIUM',
          keyPoints: summaryData.keyPoints || ['Call completed successfully.'],
          callbackRequested: Boolean(summaryData.callbackRequested),
          transcript: [...transcript],
        };

        if (!incognitoMode) {
          setCallLogs((prev) => [newLog, ...prev]);
        }
      } catch (e) {
        console.error('Error generating summary:', e);
      }
    }

    setTimeout(() => {
      setCallStatus('IDLE');
      setDeviceScreen('dashboard');
    }, 1800);
  };

  // Export call logs and transcripts to a JSON file for backup/privacy audit
  const exportTranscriptsAsJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(callLogs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `ai_call_assistant_logs_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Toggle speech recognition for live caller microphone in browser
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Web Speech recognition is not supported in this browser. Please type in the caller speech box.');
      return;
    }

    if (isSpeechRecognitionActive) {
      setIsSpeechRecognitionActive(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = settings.languagePreference === 'ur' ? 'ur-PK' : 'en-US';

      recognition.onstart = () => {
        setIsSpeechRecognitionActive(true);
      };

      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript;
        setIsSpeechRecognitionActive(false);
        handleCallerSpeech(text);
      };

      recognition.onerror = () => {
        setIsSpeechRecognitionActive(false);
      };

      recognition.onend = () => {
        setIsSpeechRecognitionActive(false);
      };

      recognition.start();
    } catch (e) {
      setIsSpeechRecognitionActive(false);
    }
  };

  // Android Kotlin File Registry for Inspector
  const androidFiles: Record<string, { path: string; language: string; content: string }> = {
    'AssistantInCallService.kt': {
      path: 'android/app/src/main/java/com/aicallassistant/telecom/AssistantInCallService.kt',
      language: 'kotlin',
      content: `package com.aicallassistant.telecom

import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.telephony.PhoneNumberUtils
import android.util.Log
import com.aicallassistant.ai.CallAgentEngine
import com.aicallassistant.data.repository.SettingsRepository
import kotlinx.coroutines.*

/**
 * Android Telecom InCallService.
 * Requires Default Phone App role (RoleManager.ROLE_DIALER).
 * Manages incoming calls, emergency safety bypass, auto-answer timer,
 * and speakerphone audio routing to the Gemini AI Agent.
 */
class AssistantInCallService : InCallService() {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var autoAnswerJob: Job? = null

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        val handle = call.details?.handle?.schemeSpecificPart ?: "Unknown"

        // EMERGENCY SAFETY CHECK: Never intercept or delay emergency calls
        if (PhoneNumberUtils.isEmergencyNumber(handle)) {
            Log.w("InCallService", "Emergency call detected. AI Assistant bypassed.")
            return
        }

        call.registerCallback(object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                if (state == Call.STATE_RINGING) handleRinging(call)
                if (state == Call.STATE_ACTIVE) handleActive(call)
            }
        })
    }

    private fun handleRinging(call: Call) {
        scope.launch {
            val settings = SettingsRepository.getInstance(applicationContext).getSettingsSnapshot()
            if (!settings.isAssistantEnabled) return@launch

            delay(settings.autoAnswerDelaySeconds * 1000L)
            if (call.state == Call.STATE_RINGING) {
                // Legitimate Telecom answer invocation
                call.answer(VideoProfile.STATE_AUDIO_ONLY)
            }
        }
    }

    private fun handleActive(call: Call) {
        // Route audio to speakerphone for microphone capture & speaker playback
        setAudioRoute(CallAudioState.ROUTE_SPEAKER)
        CallAgentEngine.startVoiceSession(applicationContext, call) {
            call.disconnect()
        }
    }
}`,
    },
    'AndroidManifest.xml': {
      path: 'android/app/src/main/AndroidManifest.xml',
      language: 'xml',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <uses-permission android:name="android.permission.ANSWER_PHONE_CALLS" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.READ_CALL_LOG" />
    <uses-permission android:name="android.permission.READ_CONTACTS" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_PHONE_CALL" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <application
        android:name=".AiCallAssistantApp"
        android:label="@string/app_name"
        android:theme="@style/Theme.AICallAssistant">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <!-- Default Phone App (RoleManager.ROLE_DIALER) Intent Filters -->
            <intent-filter>
                <action android:name="android.intent.action.DIAL" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:scheme="tel" />
            </intent-filter>
        </activity>

        <service
            android:name=".telecom.AssistantInCallService"
            android:permission="android.permission.BIND_INCALL_SERVICE"
            android:foregroundServiceType="phoneCall|microphone"
            android:exported="true">
            <meta-data android:name="android.telecom.IN_CALL_SERVICE_UI" android:value="true" />
            <intent-filter>
                <action android:name="android.telecom.InCallService" />
            </intent-filter>
        </service>

        <service
            android:name=".telecom.AssistantCallScreeningService"
            android:permission="android.permission.BIND_SCREENING_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.telecom.CallScreeningService" />
            </intent-filter>
        </service>
    </application>
</manifest>`,
    },
    'CallAgentEngine.kt': {
      path: 'android/app/src/main/java/com/aicallassistant/ai/CallAgentEngine.kt',
      language: 'kotlin',
      content: `package com.aicallassistant.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.telecom.Call
import com.aicallassistant.ai.models.ConversationMessage
import com.aicallassistant.ai.models.ConverseRequest
import com.aicallassistant.data.repository.SettingsRepository
import java.util.Locale

/**
 * Orchestrates multi-turn voice dialog between caller and Gemini AI voice agent.
 * Supports Urdu (اردو) and English with automatic language detection,
 * speech synthesis, and emergency keyword interception.
 */
object CallAgentEngine {
    private val client = GeminiVoiceClient()
    private val history = mutableListOf<ConversationMessage>()
    private var tts: TextToSpeech? = null

    fun startVoiceSession(context: Context, call: Call, onConclude: () -> Unit) {
        val settings = SettingsRepository.getInstance(context).getSettingsSnapshot()
        val isUrdu = settings.languagePreference == "ur"
        val greeting = if (isUrdu) settings.greetingUr else settings.greetingEn

        history.clear()
        history.add(ConversationMessage("assistant", greeting))
        playSpeech(context, greeting, isUrdu)
    }

    fun processCallerSpeech(context: Context, speechText: String) {
        history.add(ConversationMessage("user", speechText))
        // Secure backend invocation to Gemini
    }

    private fun playSpeech(context: Context, text: String, isUrdu: Boolean) {
        tts?.setLanguage(if (isUrdu) Locale("ur", "PK") else Locale.US)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TURN_SPEECH")
    }
}`,
    },
    'AiVoiceService.kt': {
      path: 'android/app/src/main/java/com/aicallassistant/ai/AiVoiceService.kt',
      language: 'kotlin',
      content: `package com.aicallassistant.ai

import com.aicallassistant.ai.models.*
import kotlinx.coroutines.flow.StateFlow

sealed interface VoiceServiceState {
    object Idle : VoiceServiceState
    object Connecting : VoiceServiceState
    object Ready : VoiceServiceState
    object Streaming : VoiceServiceState
    data class Error(val message: String, val canRetry: Boolean) : VoiceServiceState
}

/**
 * Android AI Voice Service interface.
 * Decouples telephony call handling from the underlying speech and intelligence backend.
 * Protects Google Gemini API credentials by routing strictly through secure server proxies.
 */
interface AiVoiceService {
    val state: StateFlow<VoiceServiceState>
    suspend fun processTurn(request: ConverseRequest): Result<ConverseResponse>
    suspend fun synthesizeAudio(text: String, language: String): Result<ByteArray>
    suspend fun summarizeCall(request: SummarizeRequest): Result<CallSummary>
    fun release()
}`,
    },
    'build.gradle.kts (App)': {
      path: 'android/app/build.gradle.kts',
      language: 'kotlin',
      content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.aicallassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aicallassistant"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "AI_BACKEND_URL", "\"https://ais-backend-service.run.app\"")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.okhttp)
    testImplementation(libs.junit)
}`,
    },
    'CallRulesEngineTest.kt': {
      path: 'android/app/src/test/java/com/aicallassistant/CallRulesEngineTest.kt',
      language: 'kotlin',
      content: `package com.aicallassistant

import org.junit.Assert.*
import org.junit.Test

class CallRulesEngineTest {

    @Test
    fun emergencyNumbers_mustNeverBeIntercepted() {
        val emergencyNumbers = listOf("112", "911", "15", "999", "1122")
        for (num in emergencyNumbers) {
            assertTrue(isEmergencyNumber(num))
        }
        assertFalse(isEmergencyNumber("+923001234567"))
    }

    @Test
    fun vipContact_bypassesAiAutoAnswer() {
        val rules = listOf(
            ContactRule("1", "Family", "+923001234567", ContactRuleType.VIP_BYPASS_AI)
        )
        val matched = rules.find { it.phoneNumber == "+923001234567" }
        assertEquals(ContactRuleType.VIP_BYPASS_AI, matched?.ruleType)
    }

    private fun isEmergencyNumber(num: String) =
        setOf("112", "911", "15", "999", "1122").contains(num.trim())
}`,
    },
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  return (
    <div className={`min-h-screen ${isDarkTheme ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'} flex flex-col font-sans transition-colors duration-200`}>
      {/* Top Header / Navigation Bar */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-30 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-teal-400 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <PhoneCall className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-bold text-lg text-white">AI Call Assistant</h1>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  Vivo OriginOS 15 / Android 15
                </span>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Gemini Voice Real-Time
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Telecom InCallService • Auto-Answer Engine • English & Urdu Dual Dialog • Vivo Whitelisted
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsDarkTheme(!isDarkTheme)}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Toggle Dark/Light Theme"
            >
              {isDarkTheme ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Workbench Navigation Tabs */}
            <div className="bg-slate-800 p-1 rounded-xl flex items-center space-x-1 overflow-x-auto">
              <button
                onClick={() => setActiveTab('simulator')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'simulator' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Vivo Device Simulator</span>
              </button>
              <button
                onClick={() => setActiveTab('ai_chat')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'ai_chat' ? 'bg-teal-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-300" />
                <span>AI Conversation Studio</span>
              </button>
              <button
                onClick={() => setActiveTab('voice_service')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'voice_service' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Radio className="w-3.5 h-3.5" />
                <span>Voice Service & Telephony</span>
              </button>
              <button
                onClick={() => setActiveTab('code')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'code' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileCode2 className="w-3.5 h-3.5" />
                <span>Android 15 Codebase</span>
              </button>
              <button
                onClick={() => setActiveTab('architecture')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'architecture' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Telecom & SELinux Reality</span>
              </button>
              <button
                onClick={() => setActiveTab('vivo_guide')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all shrink-0 ${
                  activeTab === 'vivo_guide' ? 'bg-blue-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <BatteryCharging className="w-3.5 h-3.5" />
                <span>Vivo 15 Setup Guide</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 md:p-6">
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Column: Vivo Smartphone Device Shell running Jetpack Compose UI */}
            <div className="lg:col-span-6 flex flex-col items-center">
              <div className="w-full max-w-[390px] rounded-[48px] p-3 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 shadow-2xl shadow-blue-900/30 border-4 border-slate-700/80 relative">
                {/* Hardware Speaker Ear Piece & Camera Punch Hole */}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-4 bg-slate-900 rounded-full flex items-center justify-center z-40">
                  <div className="w-3 h-3 rounded-full bg-slate-950 border border-slate-800 mr-2" />
                  <div className="w-8 h-1 rounded-full bg-slate-800" />
                </div>

                {/* Smartphone Display Screen */}
                <div className="w-full h-[730px] rounded-[40px] bg-slate-950 overflow-hidden flex flex-col relative border border-slate-800">
                  {/* Status Bar */}
                  <div className="h-7 px-6 pt-1 flex items-center justify-between text-[11px] font-medium text-slate-400 z-30 select-none">
                    <span>9:41</span>
                    <div className="flex items-center space-x-1.5 text-xs">
                      <span>5G</span>
                      <Radio className="w-3 h-3 text-blue-400 animate-pulse" />
                      <span>94%</span>
                    </div>
                  </div>

                  {/* Device Screen Router */}
                  <div className="flex-1 overflow-y-auto px-4 py-2 flex flex-col">
                    {/* SCREEN: DASHBOARD */}
                    {deviceScreen === 'dashboard' && (
                      <div className="flex-1 flex flex-col space-y-4">
                        {/* Header */}
                        <div className="flex items-center justify-between pt-1">
                          <div>
                            <div className="flex items-center space-x-2">
                              <h2 className="text-xl font-extrabold text-white">AI Call Assistant</h2>
                              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-600/30 text-blue-400 border border-blue-500/20">
                                Vivo 15
                              </span>
                            </div>
                            <p className="text-xs text-slate-400">
                              Voice Agent: <span className="text-teal-400 font-semibold">{settings.assistantName}</span> • Gemini Live
                            </p>
                          </div>
                          <button
                            onClick={() => setDeviceScreen('settings')}
                            className="p-2 rounded-full bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300"
                          >
                            <Settings className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Master AI Toggle Card */}
                        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 shadow-sm">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div
                                className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${
                                  settings.isAssistantEnabled
                                    ? 'bg-gradient-to-tr from-blue-600 to-teal-400 text-white shadow-md shadow-blue-500/30'
                                    : 'bg-slate-800 text-slate-500'
                                }`}
                              >
                                {settings.isAssistantEnabled ? <PhoneCall className="w-5 h-5" /> : <PhoneOff className="w-5 h-5" />}
                              </div>
                              <div>
                                <h3 className="font-bold text-sm text-white">
                                  {settings.isAssistantEnabled ? 'AI Assistant Active' : 'Assistant Paused'}
                                </h3>
                                <p className="text-xs text-teal-400">
                                  {settings.isAssistantEnabled ? 'Managing incoming SIM calls' : 'Manual answering only'}
                                </p>
                              </div>
                            </div>

                            {/* Switch */}
                            <button
                              onClick={() => setSettings((s) => ({ ...s, isAssistantEnabled: !s.isAssistantEnabled }))}
                              className={`w-12 h-6 rounded-full p-1 transition-colors ${
                                settings.isAssistantEnabled ? 'bg-blue-600' : 'bg-slate-800'
                              }`}
                            >
                              <div
                                className={`w-4 h-4 rounded-full bg-white transition-transform ${
                                  settings.isAssistantEnabled ? 'translate-x-6' : 'translate-x-0'
                                }`}
                              />
                            </button>
                          </div>

                          <div className="my-3 border-t border-slate-800" />

                          <div className="space-y-2">
                            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                              Response Mode
                            </span>
                            <div className="grid grid-cols-3 gap-2">
                              {(['BUSY', 'SLEEP', 'CUSTOM'] as const).map((m) => (
                                <button
                                  key={m}
                                  onClick={() => setSettings((s) => ({ ...s, mode: m }))}
                                  className={`py-1.5 px-2 rounded-xl text-xs font-semibold transition-all border ${
                                    settings.mode === m
                                      ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                                      : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
                                  }`}
                                >
                                  {m === 'BUSY' ? '💼 Busy' : m === 'SLEEP' ? '🌙 Sleep' : '⚙️ Custom'}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Telecom & Vivo Status Badges */}
                        <div className="grid grid-cols-2 gap-2">
                          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 flex items-center space-x-2">
                            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                              <CheckCircle2 className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-400">Default Phone</p>
                              <p className="text-xs font-bold text-emerald-400">ROLE_DIALER</p>
                            </div>
                          </div>

                          <button
                            onClick={() => setDeviceScreen('permissions')}
                            className="rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 flex items-center space-x-2 text-left hover:border-blue-500/40 transition-colors"
                          >
                            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                              <BatteryCharging className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="text-[10px] text-slate-400">Vivo OriginOS</p>
                              <p className="text-xs font-bold text-blue-400">Whitelisted</p>
                            </div>
                          </button>
                        </div>

                        {/* Recent Handled Calls Section */}
                        <div className="flex-1 flex flex-col min-h-0">
                          <div className="flex items-center justify-between pb-1">
                            <span className="text-xs font-bold text-slate-300">Recent AI Handled Calls</span>
                            <button
                              onClick={() => setDeviceScreen('history')}
                              className="text-xs text-blue-400 hover:text-blue-300 font-semibold"
                            >
                              View All ({callLogs.length})
                            </button>
                          </div>

                          <div className="space-y-2 overflow-y-auto pr-1">
                            {callLogs.map((log) => (
                              <div
                                key={log.id}
                                onClick={() => setDeviceScreen('history')}
                                className="rounded-xl border border-slate-800/80 bg-slate-900/40 hover:bg-slate-900 p-2.5 cursor-pointer transition-all"
                              >
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-xs text-white">{log.callerName}</span>
                                  <span
                                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                      log.urgency === 'HIGH' || log.urgency === 'URGENT'
                                        ? 'bg-rose-500/20 text-rose-400'
                                        : 'bg-emerald-500/20 text-emerald-400'
                                    }`}
                                  >
                                    {log.urgency}
                                  </span>
                                </div>
                                <p className="text-[11px] text-slate-300 font-medium line-clamp-1 mt-0.5">
                                  {log.summaryTitle}
                                </p>
                                <p className="text-[10px] text-slate-500 mt-0.5">{log.callerNumber} • {log.durationSeconds}s</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Bottom Navigation Grid inside App */}
                        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-900">
                          <button
                            onClick={() => setDeviceScreen('instructions')}
                            className="flex flex-col items-center p-1.5 rounded-xl hover:bg-slate-900 text-slate-400 hover:text-white"
                          >
                            <Sliders className="w-4 h-4 mb-1 text-teal-400" />
                            <span className="text-[9px] font-medium">Rules</span>
                          </button>
                          <button
                            onClick={() => setDeviceScreen('contacts')}
                            className="flex flex-col items-center p-1.5 rounded-xl hover:bg-slate-900 text-slate-400 hover:text-white"
                          >
                            <Users className="w-4 h-4 mb-1 text-blue-400" />
                            <span className="text-[9px] font-medium">VIP/Block</span>
                          </button>
                          <button
                            onClick={() => setDeviceScreen('history')}
                            className="flex flex-col items-center p-1.5 rounded-xl hover:bg-slate-900 text-slate-400 hover:text-white"
                          >
                            <History className="w-4 h-4 mb-1 text-purple-400" />
                            <span className="text-[9px] font-medium">Logs</span>
                          </button>
                          <button
                            onClick={() => setDeviceScreen('settings')}
                            className="flex flex-col items-center p-1.5 rounded-xl hover:bg-slate-900 text-slate-400 hover:text-white"
                          >
                            <Settings className="w-4 h-4 mb-1 text-slate-400" />
                            <span className="text-[9px] font-medium">Config</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* SCREEN: ACTIVE IN-CALL HUD */}
                    {deviceScreen === 'active_call' && (
                      <div className="flex-1 flex flex-col justify-between py-2">
                        {/* Status Badge */}
                        <div className="flex flex-col items-center">
                          <div className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-bold text-teal-400 flex items-center space-x-1.5">
                            <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping" />
                            <span>
                              {callStatus === 'RINGING' && 'Incoming Call • Ringing'}
                              {callStatus === 'AUTO_ANSWERING' && `Auto-answering in ${countdown}s...`}
                              {callStatus === 'ACTIVE' && `AI Voice In Call (${callDuration}s)`}
                              {callStatus === 'TAKEOVER' && `Manual Takeover (${callDuration}s)`}
                              {callStatus === 'ENDED' && 'Call Concluded'}
                            </span>
                          </div>

                          <h3 className="text-xl font-bold text-white mt-3">{simulatedCaller.name}</h3>
                          <p className="text-xs text-slate-400">{simulatedCaller.number}</p>

                          {/* Animated Voice Orb */}
                          <div className="relative my-4">
                            <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
                              callStatus === 'ACTIVE'
                                ? 'bg-gradient-to-tr from-blue-600 via-indigo-600 to-teal-400 shadow-xl shadow-blue-500/40 animate-pulse'
                                : 'bg-slate-800'
                            }`}>
                              <Mic className="w-8 h-8 text-white" />
                            </div>
                            {isAiThinking && (
                              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-bold px-2 py-0.5 rounded-full bg-teal-500 text-slate-950">
                                Gemini Thinking...
                              </div>
                            )}
                          </div>

                          {emergencyAlert && (
                            <div className="w-full p-2 rounded-xl bg-rose-500/20 border border-rose-500 text-rose-300 text-xs font-bold flex items-center space-x-2 my-1">
                              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                              <span>Urgent keyword detected. Consider manual takeover.</span>
                            </div>
                          )}
                        </div>

                        {/* Live Call Transcript Bubble Stream */}
                        <div className="flex-1 my-2 rounded-2xl border border-slate-800 bg-slate-900/60 p-3 overflow-y-auto space-y-2 max-h-[220px]">
                          {transcript.length === 0 ? (
                            <div className="h-full flex items-center justify-center text-xs text-slate-500">
                              Listening for incoming audio speech...
                            </div>
                          ) : (
                            transcript.map((item, idx) => (
                              <div
                                key={idx}
                                className={`flex flex-col ${item.role === 'assistant' ? 'items-start' : 'items-end'}`}
                              >
                                <span className="text-[10px] font-bold text-slate-400 mb-0.5">
                                  {item.role === 'assistant' ? '🤖 AI Assistant' : '👤 Caller'}
                                </span>
                                <div
                                  className={`rounded-xl px-3 py-1.5 text-xs max-w-[85%] ${
                                    item.role === 'assistant'
                                      ? 'bg-slate-800 text-teal-200 border border-slate-700'
                                      : 'bg-blue-600 text-white'
                                  }`}
                                >
                                  {item.text}
                                </div>
                              </div>
                            ))
                          )}
                        </div>

                        {/* Caller Speech Input Simulator */}
                        <div className="space-y-3">
                          <div className="flex items-center space-x-2">
                            <input
                              type="text"
                              value={callerInputText}
                              onChange={(e) => setCallerInputText(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleCallerSpeech(callerInputText)}
                              placeholder="Speak as caller (English or Urdu)..."
                              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                            />
                            <button
                              onClick={toggleSpeechRecognition}
                              className={`p-2 rounded-xl border transition-colors ${
                                isSpeechRecognitionActive
                                  ? 'bg-rose-600 border-rose-500 text-white animate-pulse'
                                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                              }`}
                              title="Speak via Microphone"
                            >
                              <Mic className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleCallerSpeech(callerInputText)}
                              className="p-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                          </div>

                          {/* In-Call Telecom Controls */}
                          <div className="flex items-center justify-around pt-2 border-t border-slate-900">
                            <button
                              onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                              className={`p-3 rounded-full ${isSpeakerOn ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                              title="Speakerphone"
                            >
                              {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                            </button>

                            <button
                              onClick={() => setCallStatus('TAKEOVER')}
                              className={`px-3 py-2 rounded-xl text-xs font-bold ${
                                callStatus === 'TAKEOVER'
                                  ? 'bg-purple-600 text-white'
                                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                              }`}
                            >
                              Take Over
                            </button>

                            <button
                              onClick={() => setIsMuted(!isMuted)}
                              className={`p-3 rounded-full ${isMuted ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                              title="Mute"
                            >
                              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                            </button>

                            <button
                              onClick={endCurrentCall}
                              className="p-3 rounded-full bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30"
                              title="End Call"
                            >
                              <PhoneOff className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* SCREEN: CUSTOM INSTRUCTIONS */}
                    {deviceScreen === 'instructions' && (
                      <div className="flex-1 flex flex-col space-y-3 py-1 overflow-y-auto">
                        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                          <button
                            onClick={() => setDeviceScreen('dashboard')}
                            className="text-xs text-blue-400 font-semibold"
                          >
                            ← Back
                          </button>
                          <span className="text-sm font-bold text-white">AI Custom Instructions</span>
                          <span className="w-8" />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[11px] font-bold text-slate-300">Assistant Persona Name</label>
                          <input
                            type="text"
                            value={settings.assistantName}
                            onChange={(e) => setSettings({ ...settings, assistantName: e.target.value })}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[11px] font-bold text-slate-300">English Greeting</label>
                          <textarea
                            value={settings.greetingEn}
                            onChange={(e) => setSettings({ ...settings, greetingEn: e.target.value })}
                            rows={2}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white resize-none"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[11px] font-bold text-slate-300">Urdu Greeting (اردو تعارف)</label>
                          <textarea
                            value={settings.greetingUr}
                            onChange={(e) => setSettings({ ...settings, greetingUr: e.target.value })}
                            rows={2}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white text-right resize-none font-sans"
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center space-x-1.5 text-rose-400">
                            <ShieldAlert className="w-3.5 h-3.5" />
                            <label className="text-[11px] font-bold">STRICT FORBIDDEN TOPICS (Never Disclose)</label>
                          </div>
                          <textarea
                            value={settings.forbiddenTopics}
                            onChange={(e) => setSettings({ ...settings, forbiddenTopics: e.target.value })}
                            rows={2}
                            className="w-full bg-slate-900 border border-rose-500/30 rounded-xl px-3 py-1.5 text-xs text-rose-200 resize-none"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[11px] font-bold text-slate-300">Permitted Topics</label>
                          <textarea
                            value={settings.allowedTopics}
                            onChange={(e) => setSettings({ ...settings, allowedTopics: e.target.value })}
                            rows={2}
                            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white resize-none"
                          />
                        </div>

                        <button
                          onClick={() => setDeviceScreen('dashboard')}
                          className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs"
                        >
                          Save Instructions
                        </button>
                      </div>
                    )}

                    {/* SCREEN: CONTACT RULES */}
                    {deviceScreen === 'contacts' && (
                      <div className="flex-1 flex flex-col space-y-3 py-1 overflow-y-auto">
                        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                          <button
                            onClick={() => setDeviceScreen('dashboard')}
                            className="text-xs text-blue-400 font-semibold"
                          >
                            ← Back
                          </button>
                          <span className="text-sm font-bold text-white">Contact Routing Rules</span>
                          <span className="w-8" />
                        </div>

                        <p className="text-[11px] text-slate-400">
                          VIP callers bypass the AI voice agent directly. Blacklisted callers are rejected pre-ring by CallScreeningService.
                        </p>

                        <div className="space-y-2">
                          {contactRules.map((rule) => (
                            <div key={rule.id} className="p-3 rounded-xl border border-slate-800 bg-slate-900/60">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-xs text-white">{rule.name}</span>
                                <span
                                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                    rule.ruleType === 'VIP_BYPASS_AI'
                                      ? 'bg-emerald-500/20 text-emerald-400'
                                      : rule.ruleType === 'BLOCK_CALLER'
                                      ? 'bg-rose-500/20 text-rose-400'
                                      : 'bg-blue-500/20 text-blue-400'
                                  }`}
                                >
                                  {rule.ruleType === 'VIP_BYPASS_AI'
                                    ? 'VIP Direct'
                                    : rule.ruleType === 'BLOCK_CALLER'
                                    ? 'Auto Block'
                                    : 'AI Assist'}
                                </span>
                              </div>
                              <p className="text-xs text-slate-400 mt-1">{rule.phoneNumber}</p>
                              <p className="text-[10px] text-slate-500">{rule.customNotes}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* SCREEN: HISTORY */}
                    {deviceScreen === 'history' && (
                      <div className="flex-1 flex flex-col space-y-3 py-1 overflow-y-auto">
                        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                          <button
                            onClick={() => setDeviceScreen('dashboard')}
                            className="text-xs text-blue-400 font-semibold"
                          >
                            ← Back
                          </button>
                          <span className="text-sm font-bold text-white">Call Logs & Summaries</span>
                          <div className="flex items-center space-x-1.5">
                            <button
                              onClick={exportTranscriptsAsJson}
                              className="text-xs text-slate-300 hover:text-white p-1 rounded hover:bg-slate-800"
                              title="Export call logs as JSON"
                            >
                              <Download className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (window.confirm('Delete all call logs and recorded transcripts?')) {
                                  setCallLogs([]);
                                }
                              }}
                              className="text-xs text-rose-400 hover:text-rose-300 p-1 rounded hover:bg-rose-500/10"
                              title="Delete all history"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Privacy & Incognito Quick Bar */}
                        <div className="p-2.5 rounded-xl border border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs">
                          <div className="flex items-center space-x-2">
                            <Shield className={`w-3.5 h-3.5 ${incognitoMode ? 'text-amber-400' : 'text-emerald-400'}`} />
                            <span className="text-[11px] text-slate-300">
                              {incognitoMode ? 'Incognito Mode: Active (No recordings saved)' : 'Standard Logging: Retained locally'}
                            </span>
                          </div>
                          <button
                            onClick={() => setIncognitoMode(!incognitoMode)}
                            className={`text-[10px] px-2 py-0.5 rounded font-bold border transition-colors ${
                              incognitoMode
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                            }`}
                          >
                            {incognitoMode ? 'Disable' : 'Enable Incognito'}
                          </button>
                        </div>

                        {callLogs.length === 0 ? (
                          <div className="py-8 text-center text-slate-500 text-xs">
                            <p>No call logs stored.</p>
                            <p className="text-[10px] mt-1 text-slate-600">Simulate or receive a call to generate transcripts.</p>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            {callLogs.map((log) => (
                              <div key={log.id} className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 space-y-2 relative group">
                                <div className="flex items-center justify-between">
                                  <span className="font-bold text-xs text-white">{log.callerName}</span>
                                  <div className="flex items-center space-x-1.5">
                                    <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded">
                                      {log.urgency}
                                    </span>
                                    <button
                                      onClick={() => setCallLogs((prev) => prev.filter((item) => item.id !== log.id))}
                                      className="text-slate-500 hover:text-rose-400 p-0.5 transition-colors"
                                      title="Delete this message"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                                <p className="text-xs font-semibold text-teal-300">{log.summaryTitle}</p>
                                <p className="text-xs text-slate-300">{log.summaryIntent}</p>
                                <div className="space-y-1 pt-1 border-t border-slate-800/80">
                                  {log.keyPoints.map((pt, i) => (
                                    <p key={i} className="text-[11px] text-slate-400 flex items-start space-x-1">
                                      <span className="text-blue-400 font-bold">•</span>
                                      <span>{pt}</span>
                                    </p>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    {/* SCREEN: SETTINGS */}
                    {deviceScreen === 'settings' && (
                      <div className="flex-1 flex flex-col space-y-3 py-1 overflow-y-auto">
                        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                          <button
                            onClick={() => setDeviceScreen('dashboard')}
                            className="text-xs text-blue-400 font-semibold"
                          >
                            ← Back
                          </button>
                          <span className="text-sm font-bold text-white">Telecom & Audio Settings</span>
                          <span className="w-8" />
                        </div>

                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-300">
                            Auto-Answer Delay: {settings.autoAnswerDelaySeconds} seconds
                          </label>
                          <input
                            type="range"
                            min="1"
                            max="12"
                            value={settings.autoAnswerDelaySeconds}
                            onChange={(e) => setSettings({ ...settings, autoAnswerDelaySeconds: parseInt(e.target.value) })}
                            className="w-full accent-blue-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-xs font-bold text-slate-300">Spoken Language Mode</label>
                          <div className="grid grid-cols-3 gap-2">
                            {(['ur', 'auto', 'en'] as const).map((lang) => (
                              <button
                                key={lang}
                                onClick={() => setSettings({ ...settings, languagePreference: lang })}
                                className={`py-1.5 px-2 rounded-xl text-xs font-semibold border ${
                                  settings.languagePreference === lang
                                    ? 'bg-blue-600 text-white border-blue-500'
                                    : 'bg-slate-900 text-slate-400 border-slate-800'
                                }`}
                              >
                                {lang === 'ur' ? 'Urdu (اردو • Default)' : lang === 'auto' ? 'Auto Detect' : 'English'}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold text-slate-300">AI Voice Persona (Gemini Live / TTS)</label>
                            <span className="text-[10px] text-teal-400 font-semibold">Male Urdu Default</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            {([
                              { id: 'Puck', label: 'Puck (Male • Default)', desc: 'Natural Pakistani Urdu' },
                              { id: 'Charon', label: 'Charon (Male)', desc: 'Calm, deep executive' },
                              { id: 'Fenrir', label: 'Fenrir (Male)', desc: 'Authoritative, clear' },
                              { id: 'Zephyr', label: 'Zephyr (Neutral)', desc: 'Soothing delivery' },
                              { id: 'Kore', label: 'Kore (Female)', desc: 'Articulate tone' },
                            ] as const).map((v) => (
                              <button
                                key={v.id}
                                onClick={() => setSettings({ ...settings, voicePersona: v.id })}
                                className={`p-2 rounded-xl text-left border transition-all ${
                                  settings.voicePersona === v.id
                                    ? 'bg-blue-600/20 text-white border-blue-500'
                                    : 'bg-slate-900 text-slate-400 border-slate-800'
                                }`}
                              >
                                <p className="text-[11px] font-bold">{v.label}</p>
                                <p className="text-[9px] text-slate-400">{v.desc}</p>
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 space-y-1">
                          <p className="text-xs font-bold text-white">Default Phone App Status</p>
                          <p className="text-[11px] text-emerald-400 font-semibold">Granted (RoleManager.ROLE_DIALER)</p>
                          <p className="text-[10px] text-slate-400">Permits Telecom answer() and disconnect() APIs.</p>
                        </div>
                      </div>
                    )}

                    {/* SCREEN: PERMISSION & VIVO GUIDE */}
                    {deviceScreen === 'permissions' && (
                      <div className="flex-1 flex flex-col space-y-3 py-1 overflow-y-auto">
                        <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                          <button
                            onClick={() => setDeviceScreen('dashboard')}
                            className="text-xs text-blue-400 font-semibold"
                          >
                            ← Back
                          </button>
                          <span className="text-sm font-bold text-white">Vivo 15 Permissions</span>
                          <span className="w-8" />
                        </div>

                        <div className="space-y-2">
                          <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 flex items-center justify-between">
                            <div>
                              <p className="text-xs font-bold text-white">High Background Battery</p>
                              <p className="text-[10px] text-slate-400">Settings → Battery → Background power</p>
                            </div>
                            <span className="text-xs text-emerald-400 font-bold">Allowed</span>
                          </div>

                          <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 flex items-center justify-between">
                            <div>
                              <p className="text-xs font-bold text-white">iManager Autostart</p>
                              <p className="text-[10px] text-slate-400">Applications → Autostart Manager</p>
                            </div>
                            <span className="text-xs text-emerald-400 font-bold">Allowed</span>
                          </div>

                          <div className="p-3 rounded-xl border border-slate-800 bg-slate-900/60 flex items-center justify-between">
                            <div>
                              <p className="text-xs font-bold text-white">Recent Apps Lock</p>
                              <p className="text-[10px] text-slate-400">Task switcher padlock locked</p>
                            </div>
                            <span className="text-xs text-emerald-400 font-bold">Active</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Android Navigation Bar Bar */}
                  <div className="h-6 flex items-center justify-center">
                    <div className="w-32 h-1 rounded-full bg-slate-700" />
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Telephony Test Bench & Trigger Controls */}
            <div className="lg:col-span-6 space-y-5">
              {/* Trigger Interactive Simulation Card */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 shadow-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Play className="w-5 h-5 text-blue-400" />
                    <h2 className="font-bold text-base text-white">Test Real Telecom Simulation</h2>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    Live Gemini AI Loop
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                  Trigger a live incoming SIM call to test the entire Android Telecom lifecycle: Ringing → Countdown →
                  InCallService auto-answer → Gemini speech reasoning → Live transcription → AI summary generation.
                </p>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <button
                    onClick={() => triggerIncomingCall('Dr. Tariq Mahmood (Urdu Caller)', '+92 300 4819203')}
                    disabled={callStatus !== 'IDLE'}
                    className="p-3 rounded-xl border border-blue-500/30 bg-blue-600/10 hover:bg-blue-600/20 text-left transition-all disabled:opacity-40"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-base">🇵🇰</span>
                      <span className="font-bold text-xs text-white">Urdu / Bilingual Call</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">Tests Urdu speech greeting & reasoning</p>
                  </button>

                  <button
                    onClick={() => triggerIncomingCall('Sarah Jenkins (English Inquiry)', '+1 415 892 1092')}
                    disabled={callStatus !== 'IDLE'}
                    className="p-3 rounded-xl border border-teal-500/30 bg-teal-600/10 hover:bg-teal-600/20 text-left transition-all disabled:opacity-40"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-base">🇺🇸</span>
                      <span className="font-bold text-xs text-white">English Business Call</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">Tests appointment & message recording</p>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => triggerIncomingCall('Mom (VIP Contact)', '+92 300 1234567')}
                    disabled={callStatus !== 'IDLE'}
                    className="p-3 rounded-xl border border-emerald-500/30 bg-emerald-600/10 hover:bg-emerald-600/20 text-left transition-all disabled:opacity-40"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-base">⭐</span>
                      <span className="font-bold text-xs text-white">VIP Direct Ring</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">Bypasses AI, rings directly</p>
                  </button>

                  <button
                    onClick={() => triggerIncomingCall('Spam Telemarketer', '+92 345 0000000')}
                    disabled={callStatus !== 'IDLE'}
                    className="p-3 rounded-xl border border-rose-500/30 bg-rose-600/10 hover:bg-rose-600/20 text-left transition-all disabled:opacity-40"
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-base">🚫</span>
                      <span className="font-bold text-xs text-white">Blacklisted Caller</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">Pre-ring silent drop test</p>
                  </button>
                </div>
              </div>

              {/* Real-time Telecom Engine State Inspector */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-teal-400" />
                    <span>Android 15 Telecom State Engine</span>
                  </h3>
                  <span className="text-xs text-slate-400">Real-Time Event Stream</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Telecom State</span>
                    <p className="text-xs font-bold text-teal-400 mt-0.5">
                      {callStatus === 'IDLE' && 'STATE_IDLE'}
                      {callStatus === 'RINGING' && 'STATE_RINGING'}
                      {callStatus === 'AUTO_ANSWERING' && 'COROUTINE_COUNTDOWN'}
                      {callStatus === 'ACTIVE' && 'STATE_ACTIVE (AI Dialog)'}
                      {callStatus === 'TAKEOVER' && 'STATE_ACTIVE (Owner Takeover)'}
                      {callStatus === 'ENDED' && 'STATE_DISCONNECTED'}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">Audio Route</span>
                    <p className="text-xs font-bold text-blue-400 mt-0.5">
                      {isSpeakerOn ? 'CallAudioState.ROUTE_SPEAKER' : 'CallAudioState.ROUTE_EARPIECE'}
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Emergency Bypass Guard:</span>
                    <span className="text-emerald-400 font-bold">Active (112 / 911 / 15 Checked)</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>SELinux Voice Call Source:</span>
                    <span className="text-amber-400 font-bold">Standard AudioRecord + Speaker Route</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Gemini Server Endpoint:</span>
                    <span className="text-teal-400 font-bold">POST /api/gemini/converse (Secure)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: AI CONVERSATION STUDIO */}
        {activeTab === 'ai_chat' && (
          <AiChatStudio
            settings={settings}
            onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
            isDarkTheme={isDarkTheme}
          />
        )}

        {/* TAB: VOICE SERVICE & TELEPHONY CONSOLE */}
        {activeTab === 'voice_service' && (
          <VoiceServiceConsole />
        )}

        {/* TAB: ANDROID 15 CODEBASE BROWSER */}
        {activeTab === 'code' && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-2xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center space-x-2">
                  <FileCode2 className="w-5 h-5 text-blue-400" />
                  <span>Production Android 15 Kotlin Codebase</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Complete Gradle, Telecom InCallService, and Jetpack Compose project files located in <code className="text-teal-400">/android</code>
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => copyToClipboard(androidFiles[selectedFileForInspection]?.content || '')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 flex items-center space-x-1.5 transition-colors"
                >
                  {copiedFile ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedFile ? 'Copied' : 'Copy File Content'}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-4">
              {/* File List Navigation */}
              <div className="md:col-span-4 space-y-1 bg-slate-950 p-2 rounded-xl border border-slate-800 max-h-[600px] overflow-y-auto">
                <span className="text-[10px] font-bold text-slate-500 uppercase px-2 py-1 block">
                  Android Project Files
                </span>
                {Object.keys(androidFiles).map((fileName) => (
                  <button
                    key={fileName}
                    onClick={() => setSelectedFileForInspection(fileName)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-between transition-colors ${
                      selectedFileForInspection === fileName
                        ? 'bg-blue-600 text-white font-semibold'
                        : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                    }`}
                  >
                    <span className="truncate">{fileName}</span>
                    <ChevronRight className="w-3.5 h-3.5 opacity-60 shrink-0" />
                  </button>
                ))}
              </div>

              {/* Code Viewer */}
              <div className="md:col-span-8 flex flex-col bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
                <div className="px-4 py-2 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-mono text-[11px]">
                    {androidFiles[selectedFileForInspection]?.path}
                  </span>
                  <span className="text-[11px] font-semibold text-teal-400 uppercase">
                    {androidFiles[selectedFileForInspection]?.language}
                  </span>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto overflow-y-auto max-h-[550px] leading-relaxed select-text">
                  <code>{androidFiles[selectedFileForInspection]?.content}</code>
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB: TELECOM & SELINUX ARCHITECTURE REALITY */}
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 space-y-4">
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <Layers className="w-6 h-6 text-blue-400" />
                <span>Android 15 Telecom Architecture & SELinux Audio Reality</span>
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                As a senior Android systems engineer and architect, it is vital to be transparent about what Android 15 permits
                and where third-party apps are constrained by Linux kernel SELinux security policies:
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-950/20 space-y-2">
                  <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirmed & Legitimate Capabilities</span>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4 leading-relaxed">
                    <li>
                      <strong>Telecom InCallService Role:</strong> Requesting <code className="text-emerald-300 font-mono">RoleManager.ROLE_DIALER</code> gives the application full authoritative control over incoming call state callbacks (<code className="text-emerald-300 font-mono">onCallAdded</code>, <code className="text-emerald-300 font-mono">onCallRemoved</code>).
                    </li>
                    <li>
                      <strong>Programmatic Auto-Answer:</strong> Calling <code className="text-emerald-300 font-mono">call.answer(VideoProfile.STATE_AUDIO_ONLY)</code> answers incoming calls cleanly after user-configured coroutine delays.
                    </li>
                    <li>
                      <strong>CallScreeningService:</strong> Blocks nuisance telemarketers pre-ring via <code className="text-emerald-300 font-mono">setDisallowCall(true)</code> and passes VIP calls directly.
                    </li>
                    <li>
                      <strong>Emergency Guarantee:</strong> System emergency calls (<code className="text-emerald-300 font-mono">112, 911, 15</code>) are never intercepted or delayed.
                    </li>
                  </ul>
                </div>

                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-950/20 space-y-2">
                  <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
                    <AlertTriangle className="w-4 h-4" />
                    <span>SELinux Audio Routing Restrictions</span>
                  </div>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4 leading-relaxed">
                    <li>
                      <strong>Raw Cellular Audio Ingestion:</strong> Android 9 through Android 15 prohibits third-party apps from tapping baseband hardware downlink audio via <code className="text-amber-300 font-mono">VOICE_CALL</code> or <code className="text-amber-300 font-mono">VOICE_DOWNLINK</code> without system firmware signature.
                    </li>
                    <li>
                      <strong>The Legitimate Solution Implemented Here:</strong> Switching the call to <code className="text-amber-300 font-mono">CallAudioState.ROUTE_SPEAKER</code> allows the phone microphone to capture caller speech through standard Android AudioRecord and speak AI responses back through AudioTrack/TTS.
                    </li>
                    <li>
                      <strong>VoIP Calls (WhatsApp, SIP):</strong> Free from cellular baseband hardware isolation; direct two-way PCM audio streaming to Gemini Live API works natively.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: VIVO 15 OPTIMIZATION GUIDE */}
        {activeTab === 'vivo_guide' && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 space-y-6">
            <div>
              <h2 className="text-xl font-bold text-white flex items-center space-x-2">
                <BatteryCharging className="w-6 h-6 text-teal-400" />
                <span>Vivo OriginOS 5 & FuntouchOS 15 Background Optimization</span>
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                Vivo smartphones (X100, V40, V30 series) aggressively enforce aggressive background process killing in iManager.
                Follow this 4-step checklist to ensure your AI Call Assistant service remains alive 24/7.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <span className="text-xs font-bold text-blue-400">Step 1 • High Background Battery</span>
                <h3 className="font-bold text-sm text-white">Disable Background Power Killing</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Open Vivo <strong>Settings → Battery → Background power consumption management</strong>. Find "AI Call Assistant" and select <strong>"Allow high background power consumption"</strong>.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <span className="text-xs font-bold text-teal-400">Step 2 • iManager Autostart</span>
                <h3 className="font-bold text-sm text-white">Authorize Background Autostart</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Open Vivo <strong>iManager → App Management → Autostart Manager</strong>. Toggle "AI Call Assistant" to <strong>Enabled</strong> so InCallService restarts on phone reboot.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <span className="text-xs font-bold text-purple-400">Step 3 • Lock in Task Switcher</span>
                <h3 className="font-bold text-sm text-white">Padlock App in Recent Apps Tray</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Swipe up to open Multitasking tray. Locate AI Call Assistant, tap the three dots or swipe down on the preview card, and tap the <strong>Lock (padlock icon)</strong>.
                </p>
              </div>

              <div className="p-4 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                <span className="text-xs font-bold text-emerald-400">Step 4 • Set Default Phone App</span>
                <h3 className="font-bold text-sm text-white">RoleManager Authorization</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Go to <strong>Settings → Apps → Default Apps → Phone App</strong> and choose <strong>AI Call Assistant</strong> to activate Telecom InCallService.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/60 py-3 px-4 text-center text-xs text-slate-500">
        AI Call Assistant for Vivo Android 15 • Powered by Google Gemini Live Voice Intelligence • Telecom InCallService Architecture
      </footer>
    </div>
  );
}
