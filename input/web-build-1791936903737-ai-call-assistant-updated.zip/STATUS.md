# AI Call Assistant — honest status (audited 2026-10-14)

Native Android app (Kotlin + Compose) in `android/`, plus a React/Express web demo + backend (`src/`, `server.ts`).
Nothing here has been compiled or run on a device by the author of this audit (no Android SDK available).

## Working in code (not device-tested)
- Compose UI: dashboard, instructions, contacts, history, settings, Vivo guide, permission wizard
- Settings/instructions persisted in DataStore (privacy toggles + voice were NOT persisted before this audit; now fixed)
- InCallService: detects calls, emergency bypass, timed `call.answer()` — requires Default Phone App role; UNTESTED on real SIM calls
- CallScreeningService: blocks numbers from the (in-memory) block list
- Backend `/api/gemini/converse`, `/summarize`, `/tts`, `/voices` — key stays on the server
- Voice: Settings has language + voice chips and a **Test Voice** button (new) that calls the backend and plays the audio

## Simulated / placeholder
- "Test Incoming Call Simulation" on the dashboard is a simulation, not a SIM call
- Contact rules are in-memory with 3 hard-coded sample entries; lost on restart
- Call-log "history" shows only calls the app itself recorded

## NOT implemented
- Caller audio -> AI: nothing records/transcribes the caller. `processCallerSpeech()` is only fed by the typed "simulated speech" box. Android blocks apps from cellular call audio (VOICE_CALL/DOWNLINK). Speakerphone + mic is only a hack and is unreliable.
- AI audio -> caller: AI speech plays on the phone's own output (USAGE_VOICE_COMMUNICATION); it is not injected into the cellular uplink.
- Gemini Live API streaming: not used. Pipeline is turn-based REST (text -> Gemini -> TTS).
- `AiVoiceService` interface exists but nothing implements it.
- Foreground-notification/urgent push to owner, retention auto-delete (setting stored, no job runs).

## Voice facts (checked against ai.google.dev/gemini-api/docs/speech-generation)
- "Adam" is not a Gemini voice. Valid names include Puck, Charon, Fenrir, Orus, Zephyr, Kore, ... (30 total).
- Google doesn't publish voice gender. Puck/Charon/Fenrir/Orus are commonly heard as male. Default: Puck.
- Urdu is NOT in the published TTS language table. Whether it sounds right must be judged with Test Voice.
- If Gemini TTS fails during a call the app falls back to Android's own TTS (needs an Urdu voice installed).

## Build
- No `gradlew`/wrapper jar in the project; the GitHub workflow installs Gradle 8.10.2 itself. Android Studio also works.
- Set the backend: `gradle assembleDebug -PAI_BACKEND_URL=https://your-backend` (GitHub: repo Variables -> AI_BACKEND_URL).
- Deploy `server.ts` over HTTPS (e.g. Cloud Run) with `GEMINI_API_KEY` set as a server env var.
