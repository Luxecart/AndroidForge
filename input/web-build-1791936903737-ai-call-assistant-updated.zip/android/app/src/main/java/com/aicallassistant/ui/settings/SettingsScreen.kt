package com.aicallassistant.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.ai.VoiceTestState
import com.aicallassistant.ai.VoiceTester
import com.aicallassistant.data.model.AssistantSettings
import kotlinx.coroutines.launch
import com.aicallassistant.ui.theme.*

@Composable
fun SettingsScreen(
    settings: AssistantSettings,
    isDefaultDialer: Boolean,
    onRequestDefaultDialerRole: () -> Unit,
    onNavigateToVivoGuide: () -> Unit,
    onUpdateSettings: (AssistantSettings) -> Unit,
    onBack: () -> Unit
) {
    var delaySec by remember { mutableStateOf(settings.autoAnswerDelaySeconds.toFloat()) }
    var requireConsent by remember { mutableStateOf(settings.requireCallerConsentForSummary) }
    var keepLocalOnly by remember { mutableStateOf(settings.keepRecordingsLocally) }
    val voiceTestState by VoiceTester.state.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                }
                Text("Settings & Telecom Setup", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Android Telecom Role", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Android 15 requires AI Call Assistant to hold the Default Phone App role (RoleManager.ROLE_DIALER) to legitimately intercept and answer calls programmatically via InCallService.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onRequestDefaultDialerRole,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDefaultDialer) EmeraldGreen else VivoBlue
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isDefaultDialer) "Default Phone App (Active)" else "Set as Default Phone App")
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Auto-Answer Timing", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "Delay before AI voice assistant automatically picks up the incoming SIM call. Gives you time to answer manually if desired.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Answer Delay: ${delaySec.toInt()} seconds",
                            fontWeight = FontWeight.Bold,
                            color = VivoBlue,
                            fontSize = 14.sp
                        )
                        Slider(
                            value = delaySec,
                            onValueChange = {
                                delaySec = it
                                onUpdateSettings(settings.copy(autoAnswerDelaySeconds = it.toInt()))
                            },
                            valueRange = 1f..15f,
                            steps = 13
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("AI Voice & Language", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Voice is generated by the backend using Gemini's prebuilt voices. Google does not label voice gender; Puck, Charon, Fenrir and Orus are commonly heard as male. Urdu is not in Google's published TTS language list, so use Test Voice to judge the Urdu quality yourself.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Language", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("ur" to "اردو (Urdu)", "en" to "English", "auto" to "Auto").forEach { (code, label) ->
                                FilterChip(
                                    selected = settings.languagePreference == code,
                                    onClick = { onUpdateSettings(settings.copy(languagePreference = code)) },
                                    label = { Text(label) }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Voice", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Puck", "Charon", "Fenrir", "Orus", "Zephyr", "Kore").forEach { v ->
                                FilterChip(
                                    selected = settings.voiceName == v,
                                    onClick = { onUpdateSettings(settings.copy(voiceName = v)) },
                                    label = { Text(v) }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    VoiceTester.test(settings.voiceName, settings.languagePreference)
                                }
                            },
                            enabled = voiceTestState !is VoiceTestState.Loading && voiceTestState !is VoiceTestState.Playing,
                            colors = ButtonDefaults.buttonColors(containerColor = VivoBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                when (voiceTestState) {
                                    is VoiceTestState.Loading -> "Generating voice…"
                                    is VoiceTestState.Playing -> "Playing…"
                                    else -> "Test Voice"
                                }
                            )
                        }
                        (voiceTestState as? VoiceTestState.Error)?.let { err ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Voice test failed: ${err.message}. Check that the backend URL is set and the backend has a valid GEMINI_API_KEY.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Vivo OriginOS / FuntouchOS 15 Optimization", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Vivo smartphones apply aggressive background power killing. Tap below to follow the exact checklist to keep InCallService running reliably.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = onNavigateToVivoGuide,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Open Vivo Background Settings Checklist")
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Privacy & Security Controls", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Inform Caller of AI Identity", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Assistant will always introduce itself as an AI and never deceive the caller.", fontSize = 11.sp, color = TextMuted)
                            }
                            Switch(checked = true, onCheckedChange = null, enabled = false)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Store Transcripts On-Device Only", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("Transcripts and summaries remain in private app sandbox.", fontSize = 11.sp, color = TextMuted)
                            }
                            Switch(
                                checked = keepLocalOnly,
                                onCheckedChange = {
                                    keepLocalOnly = it
                                    onUpdateSettings(settings.copy(keepRecordingsLocally = it))
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
