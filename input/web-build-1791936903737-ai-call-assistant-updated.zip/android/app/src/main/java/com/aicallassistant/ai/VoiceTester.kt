package com.aicallassistant.ai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface VoiceTestState {
    object Idle : VoiceTestState
    object Loading : VoiceTestState
    data class Playing(val voice: String) : VoiceTestState
    data class Error(val message: String) : VoiceTestState
}

/** Drives the Settings "Test Voice" button through the same backend path used in calls. */
object VoiceTester {
    const val URDU_SAMPLE =
        "السلام علیکم! میں آپ کا اے آئی کال اسسٹنٹ ہوں۔ میں آپ کا پیغام نوٹ کر سکتا ہوں۔"
    const val ENGLISH_SAMPLE =
        "Hello! I am your AI call assistant. I can take a message for you."

    private val _state = MutableStateFlow<VoiceTestState>(VoiceTestState.Idle)
    val state: StateFlow<VoiceTestState> = _state.asStateFlow()
    private val client = GeminiVoiceClient()

    suspend fun test(voice: String, language: String) {
        if (_state.value is VoiceTestState.Loading || _state.value is VoiceTestState.Playing) return
        _state.value = VoiceTestState.Loading
        val text = if (language == "en") ENGLISH_SAMPLE else URDU_SAMPLE
        when (val r = client.synthesizeSpeech(text, voice, language)) {
            is GeminiVoiceClient.SpeechResult.Failure ->
                _state.value = VoiceTestState.Error(r.reason)
            is GeminiVoiceClient.SpeechResult.Success -> {
                _state.value = VoiceTestState.Playing(r.voice)
                try {
                    GeminiSpeechPlayer.play(r.audio, r.mimeType)
                    _state.value = VoiceTestState.Idle
                } catch (e: Exception) {
                    _state.value = VoiceTestState.Error("Playback failed: ${e.message}")
                }
            }
        }
    }

    fun dismissError() {
        if (_state.value is VoiceTestState.Error) _state.value = VoiceTestState.Idle
    }
}
