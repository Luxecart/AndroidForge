package com.aicallassistant.ai

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Plays audio returned by the backend TTS endpoint (16-bit mono PCM, either a WAV file or raw L16).
 * This plays through the phone's own audio output. It does NOT inject audio into a cellular call.
 */
object GeminiSpeechPlayer {

    private const val DEFAULT_RATE = 24000
    @Volatile private var current: AudioTrack? = null

    fun stop() {
        current?.let { runCatching { it.stop() }; runCatching { it.release() } }
        current = null
    }

    suspend fun play(audio: ByteArray, mimeType: String, forCall: Boolean = false) = withContext(Dispatchers.IO) {
        stop()
        val (pcm, rate) = extractPcm(audio, mimeType)
        if (pcm.isEmpty()) throw IllegalStateException("Empty audio data")

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(
                        if (forCall) AudioAttributes.USAGE_VOICE_COMMUNICATION
                        else AudioAttributes.USAGE_MEDIA
                    )
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(pcm.size)
            .build()
        current = track
        track.write(pcm, 0, pcm.size)
        track.play()

        val durationMs = pcm.size * 1000L / (rate * 2)
        delay(durationMs + 200)
        if (current === track) stop()
    }

    private fun extractPcm(data: ByteArray, mimeType: String): Pair<ByteArray, Int> {
        var rate = Regex("rate=(\\d+)").find(mimeType)?.groupValues?.get(1)?.toIntOrNull() ?: DEFAULT_RATE
        val isRiff = data.size > 12 && String(data, 0, 4, Charsets.US_ASCII) == "RIFF"
        if (!isRiff) return data to rate

        // Walk WAV chunks to find "fmt " (sample rate) and "data".
        var pos = 12
        while (pos + 8 <= data.size) {
            val id = String(data, pos, 4, Charsets.US_ASCII)
            val size = le32(data, pos + 4)
            val body = pos + 8
            if (id == "fmt " && body + 8 <= data.size) rate = le32(data, body + 4)
            if (id == "data") {
                val end = minOf(data.size, body + size)
                return data.copyOfRange(body, end) to rate
            }
            pos = body + size + (size and 1)
        }
        return data.copyOfRange(44.coerceAtMost(data.size), data.size) to rate
    }

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
}
