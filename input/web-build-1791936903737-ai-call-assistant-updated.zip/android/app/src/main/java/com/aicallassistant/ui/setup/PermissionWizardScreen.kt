package com.aicallassistant.ui.setup

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.ui.theme.*

@Composable
fun PermissionWizardScreen(
    isDefaultDialer: Boolean,
    hasRecordAudio: Boolean,
    hasContactsPermission: Boolean,
    hasNotificationPermission: Boolean,
    onRequestDefaultDialer: () -> Unit,
    onRequestAudio: () -> Unit,
    onRequestContacts: () -> Unit,
    onRequestNotifications: () -> Unit,
    onFinish: () -> Unit
) {
    Scaffold { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Permission & Setup Wizard",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "To allow the AI Assistant to legitimately answer incoming SIM calls and communicate with callers, Android 15 requires explicit role authorization.",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }

            item {
                PermissionStepCard(
                    title = "1. Default Phone App Role",
                    description = "Required for InCallService to receive incoming call events and invoke answer() and disconnect() APIs.",
                    isGranted = isDefaultDialer,
                    icon = Icons.Default.PhoneInTalk,
                    actionText = "Grant Phone Role",
                    onAction = onRequestDefaultDialer
                )
            }

            item {
                PermissionStepCard(
                    title = "2. Microphone & Audio",
                    description = "Required for real-time speech recognition so Gemini can hear what the caller is saying.",
                    isGranted = hasRecordAudio,
                    icon = Icons.Default.Mic,
                    actionText = "Grant Audio Permission",
                    onAction = onRequestAudio
                )
            }

            item {
                PermissionStepCard(
                    title = "3. Post Notifications",
                    description = "Required for the ongoing Foreground Service and delivering call summaries.",
                    isGranted = hasNotificationPermission,
                    icon = Icons.Default.Notifications,
                    actionText = "Grant Notification Permission",
                    onAction = onRequestNotifications
                )
            }

            item {
                PermissionStepCard(
                    title = "4. Contacts (Optional)",
                    description = "Used strictly to identify VIP callers and blacklist entries in your address book.",
                    isGranted = hasContactsPermission,
                    icon = Icons.Default.Contacts,
                    actionText = "Grant Contacts Access",
                    onAction = onRequestContacts
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onFinish,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = VivoBlue)
                ) {
                    Text("Proceed to Dashboard", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun PermissionStepCard(
    title: String,
    description: String,
    isGranted: Boolean,
    icon: ImageVector,
    actionText: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isGranted) EmeraldGreen.copy(alpha = 0.2f) else VivoBlue.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = if (isGranted) EmeraldGreen else VivoBlue, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isGranted) EmeraldGreen else TextMuted
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(description, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)

            if (!isGranted) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onAction,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(actionText, fontSize = 12.sp)
                }
            }
        }
    }
}
