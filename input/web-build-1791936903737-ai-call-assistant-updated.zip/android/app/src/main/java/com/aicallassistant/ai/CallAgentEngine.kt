package com.aicallassistant.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.telecom.Call
import android.util.Log
import com.aicallassistant.ai.models.ConversationMessage
import com.aicallassistant.ai.models.ConverseRequest
import com.aicallassistant.ai.models.CustomInstructions
import com.aicallassistant.ai.models.SummarizeRequest
import com.aicallassistant.data.model.CallLogEntry
import com.aicallassistant.data.repository.CallHistoryRepository
import com.aicallassistant.data.repository.SettingsRepository
import com.aicallassistant.telecom.CallStateManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Stateful AI Voice dialog manager during active phone calls.
 * Manages turn taking, greetings in Urdu/English, speech synthesis (Android TTS/Gemini),
 * message logging, and emergency detection.
 */
object CallAgentEngine {

    private const val TAG = "CallAgentEngine"
    private val engineScope = CoroutineScope(Dispatchers.Main + Job())
    private var textToSpeech: TextToSpeech? = null
    private val conversationHistory = mutableListOf<ConversationMessage>()
    private var activeCall: Call? = null
    private var onConcludeCallback: (() -> Unit)? = null
    private val voiceClient = GeminiVoiceClient()

    fun startVoiceSession(
        context: Context,
        call: Call,
        onConclude: () -> Unit
    ) {
        Log.i(TAG, "Starting AI Voice Agent Session for call: ${call.details?.handle}")
        activeCall = call
        onConcludeCallback = onConclude
        conversationHistory.clear()

        val settingsRepo = SettingsRepository.getInstance(context)
        val settings = settingsRepo.getSettingsSnapshot()

        initTts(context) {
            // Deliver introductory greeting
            engineScope.launch {
                delay(600) // Brief natural pause after pick-up
                val greeting = if (settings.languagePreference == "ur") {
                    settings.greetingUr
                } else {
                    settings.greetingEn
                }

                playSpeechResponse(context, greeting, isUrdu = settings.languagePreference == "ur")
                CallStateManager.addTranscript("AI Assistant", greeting, isUrdu = settings.languagePreference == "ur")
                conversationHistory.add(ConversationMessage("assistant", greeting))
            }
        }
    }

    /**
     * Process a recognized utterance from the caller (e.g. from SpeechRecognizer or audio bridge)
     */
    fun processCallerSpeech(context: Context, callerText: String) {
        if (callerText.isBlank()) return

        Log.d(TAG, "Processing caller speech: $callerText")
        CallStateManager.addTranscript("Caller", callerText)
        conversationHistory.add(ConversationMessage("user", callerText))

        engineScope.launch {
            val settingsRepo = SettingsRepository.getInstance(context)
            val settings = settingsRepo.getSettingsSnapshot()

            val request = ConverseRequest(
                callerText = callerText,
                history = conversationHistory.toList(),
                callerNumber = CallStateManager.uiState.value.callerNumber,
                callerName = CallStateManager.uiState.value.callerName,
                languagePreference = settings.languagePreference,
                customInstructions = CustomInstructions(
                    assistantName = settings.assistantName,
                    ownerName = settings.ownerName,
                    greetingEn = settings.greetingEn,
                    greetingUr = settings.greetingUr,
                    allowedTopics = settings.allowedTopics,
                    forbiddenTopics = settings.forbiddenTopics,
                    urgentRules = settings.urgentRules,
                    personality = settings.personality
                ),
                callMode = settings.mode
            )

            val response = voiceClient.converseWithAgent(request)

            val isUrdu = response.languageDetected == "ur"
            playSpeechResponse(context, response.replyText, isUrdu = isUrdu)
            CallStateManager.addTranscript("AI Assistant", response.replyText, isUrdu = isUrdu)
            conversationHistory.add(ConversationMessage("assistant", response.replyText))

            if (response.isEmergency) {
                Log.w(TAG, "Emergency detected in conversation turn!")
                CallStateManager.setEmergency(true)
            }

            if (response.suggestHangup) {
                delay(2000)
                onConcludeCallback?.invoke()
            }
        }
    }

    /**
     * Speaks via the backend Gemini voice chosen in Settings. If that fails (offline, backend
     * error, unsupported voice) it falls back to the device's own TTS and logs which path was used.
     */
    private fun playSpeechResponse(context: Context, text: String, isUrdu: Boolean) {
        engineScope.launch {
            val settings = SettingsRepository.getInstance(context).getSettingsSnapshot()
            val result = voiceClient.synthesizeSpeech(text, settings.voiceName, if (isUrdu) "ur" else "en")
            when (result) {
                is GeminiVoiceClient.SpeechResult.Success -> try {
                    Log.i(TAG, "Speaking with Gemini voice ${result.voice}")
                    GeminiSpeechPlayer.play(result.audio, result.mimeType, forCall = true)
                    return@launch
                } catch (e: Exception) {
                    Log.w(TAG, "Gemini audio playback failed, using device TTS", e)
                }
                is GeminiVoiceClient.SpeechResult.Failure ->
                    Log.w(TAG, "Gemini TTS unavailable (${result.reason}), using device TTS")
            }
            speakWithDeviceTts(text, isUrdu)
        }
    }

    private fun speakWithDeviceTts(text: String, isUrdu: Boolean) {
        textToSpeech?.let { tts ->
            val locale = if (isUrdu) Locale("ur", "PK") else Locale.US
            val result = tts.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Language $locale not fully supported by device TTS engine, falling back to default")
            }
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "UTTERANCE_ID_${System.currentTimeMillis()}")
        }
    }

    private fun initTts(context: Context, onReady: () -> Unit) {
        if (textToSpeech != null) {
            onReady()
            return
        }
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.setSpeechRate(0.95f) // Natural conversational cadence
                onReady()
            } else {
                Log.e(TAG, "Failed to initialize Android TextToSpeech engine")
            }
        }
    }

    fun stopVoiceSession() {
        GeminiSpeechPlayer.stop()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
        activeCall = null
        onConcludeCallback = null
    }

    suspend fun saveCompletedCallSummary(context: Context) {
        if (conversationHistory.isEmpty()) return

        val state = CallStateManager.uiState.value
        val summarizeRequest = SummarizeRequest(
            transcript = conversationHistory.toList(),
            callerNumber = state.callerNumber,
            callerName = state.callerName,
            durationSeconds = state.callDurationSeconds,
            timestamp = System.currentTimeMillis().toString()
        )

        val summary = voiceClient.generateCallSummary(summarizeRequest)

        val entry = CallLogEntry(
            id = System.currentTimeMillis().toString(),
            callerNumber = state.callerNumber,
            callerName = state.callerName ?: "Unknown",
            timestamp = System.currentTimeMillis(),
            durationSeconds = state.callDurationSeconds,
            summaryTitle = summary.title,
            summaryIntent = summary.callerIntent,
            urgency = summary.urgency,
            keyPoints = summary.keyPoints,
            callbackRequested = summary.callbackRequested,
            transcript = conversationHistory.toList()
        )

        CallHistoryRepository.getInstance(context).addCallLog(entry)
    }
}
