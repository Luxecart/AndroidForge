package com.aicallassistant.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aicallassistant.data.model.AssistantSettings
import com.aicallassistant.data.model.CallLogEntry
import com.aicallassistant.ui.theme.*

@Composable
fun DashboardScreen(
    settings: AssistantSettings,
    recentCalls: List<CallLogEntry>,
    isDefaultDialer: Boolean,
    isVivoOptimized: Boolean,
    onToggleAssistant: (Boolean) -> Unit,
    onSelectMode: (String) -> Unit,
    onNavigateToCallTest: () -> Unit,
    onNavigateToInstructions: () -> Unit,
    onNavigateToContacts: () -> Unit,
    onNavigateToVivoGuide: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            HeaderSection(
                assistantName = settings.assistantName,
                isDefaultDialer = isDefaultDialer,
                onNavigateToSettings = onNavigateToSettings
            )
        }

        item {
            MainMasterSwitchCard(
                isEnabled = settings.isAssistantEnabled,
                mode = settings.mode,
                onToggle = onToggleAssistant,
                onSelectMode = onSelectMode,
                onTestCall = onNavigateToCallTest
            )
        }

        item {
            VivoAndSystemStatusRow(
                isDefaultDialer = isDefaultDialer,
                isVivoOptimized = isVivoOptimized,
                onNavigateToVivoGuide = onNavigateToVivoGuide
            )
        }

        item {
            QuickStatsRow(
                totalAnswered = recentCalls.size,
                highPriority = recentCalls.count { it.urgency == "HIGH" || it.urgency == "URGENT" },
                callbacksPending = recentCalls.count { it.callbackRequested }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Handled Activity",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                TextButton(onClick = onNavigateToHistory) {
                    Text("View All", color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        if (recentCalls.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No call activity recorded yet. Trigger a simulated call to test.",
                            color = TextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(recentCalls.take(3)) { call ->
                RecentCallCard(call = call, onClick = onNavigateToHistory)
            }
        }

        item {
            QuickActionGrid(
                onInstructions = onNavigateToInstructions,
                onContacts = onNavigateToContacts,
                onVivo = onNavigateToVivoGuide,
                onSettings = onNavigateToSettings
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HeaderSection(
    assistantName: String,
    isDefaultDialer: Boolean,
    onNavigateToSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "AI Call Assistant",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(VivoBlue.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Vivo Origin/Funtouch 15",
                        color = VivoBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Text(
                text = "Voice Agent: $assistantName • Gemini Real-time",
                fontSize = 13.sp,
                color = TextSecondary
            )
        }

        IconButton(
            onClick = onNavigateToSettings,
            modifier = Modifier
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
        ) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun MainMasterSwitchCard(
    isEnabled: Boolean,
    mode: String,
    onToggle: (Boolean) -> Unit,
    onSelectMode: (String) -> Unit,
    onTestCall: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(20.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (isEnabled)
                                    Brush.linearGradient(listOf(VivoBlue, AccentTeal))
                                else
                                    Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF1E293B)))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isEnabled) Icons.Default.PhoneCallback else Icons.Default.PhoneDisabled,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = if (isEnabled) "AI Assistant Active" else "Assistant Paused",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isEnabled) "Managing incoming SIM calls" else "Manual phone answering only",
                            fontSize = 13.sp,
                            color = if (isEnabled) AccentTeal else TextMuted
                        )
                    }
                }

                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = VivoBlue
                    )
                )
            }

            Spacer(modifier = Modifier.height(18.dp))
            Divider(color = CardBorder)
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Assistant Response Mode:",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ModeChip("BUSY", "Busy", Icons.Default.WorkOutline, mode == "BUSY") { onSelectMode("BUSY") }
                ModeChip("SLEEP", "Sleep", Icons.Default.Bedtime, mode == "SLEEP") { onSelectMode("SLEEP") }
                ModeChip("CUSTOM", "Custom", Icons.Default.Tune, mode == "CUSTOM") { onSelectMode("CUSTOM") }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onTestCall,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VivoBlue.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = VivoBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Test Incoming Call Simulation", color = VivoBlue, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ModeChip(
    id: String,
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) VivoBlue else CardBorder.copy(alpha = 0.5f))
            .clickable { onSelect() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else TextSecondary
            )
        }
    }
}

@Composable
fun VivoAndSystemStatusRow(
    isDefaultDialer: Boolean,
    isVivoOptimized: Boolean,
    onNavigateToVivoGuide: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatusCard(
            modifier = Modifier.weight(1f),
            title = "Default Phone App",
            statusText = if (isDefaultDialer) "Enabled (Telecom Active)" else "Role Required",
            isOk = isDefaultDialer,
            icon = Icons.Default.PhoneInTalk
        )
        StatusCard(
            modifier = Modifier.weight(1f).clickable { onNavigateToVivoGuide() },
            title = "Vivo Background Opt.",
            statusText = if (isVivoOptimized) "Whitelisted (Protected)" else "Setup Guide",
            isOk = isVivoOptimized,
            icon = Icons.Default.BatteryChargingFull
        )
    }
}

@Composable
fun StatusCard(
    modifier: Modifier = Modifier,
    title: String,
    statusText: String,
    isOk: Boolean,
    icon: ImageVector
) {
    Card(
        modifier = modifier.border(1.dp, CardBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isOk) EmeraldGreen.copy(alpha = 0.15f) else AmberWarning.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = if (isOk) EmeraldGreen else AmberWarning,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, fontSize = 11.sp, color = TextMuted)
                Text(
                    statusText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isOk) EmeraldGreen else AmberWarning
                )
            }
        }
    }
}

@Composable
fun QuickStatsRow(
    totalAnswered: Int,
    highPriority: Int,
    callbacksPending: Int
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatBox(Modifier.weight(1f), "Answered", "$totalAnswered", AccentTeal)
        StatBox(Modifier.weight(1f), "Urgent", "$highPriority", RoseDanger)
        StatBox(Modifier.weight(1f), "Callbacks", "$callbacksPending", AmberWarning)
    }
}

@Composable
fun StatBox(modifier: Modifier, label: String, count: String, color: Color) {
    Card(
        modifier = modifier.border(1.dp, CardBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 11.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(2.dp))
            Text(count, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
        }
    }
}

@Composable
fun RecentCallCard(call: CallLogEntry, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = call.callerName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = call.callerNumber,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (call.urgency) {
                                "URGENT", "HIGH" -> RoseDanger.copy(alpha = 0.2f)
                                "MEDIUM" -> AmberWarning.copy(alpha = 0.2f)
                                else -> EmeraldGreen.copy(alpha = 0.2f)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = call.urgency,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (call.urgency) {
                            "URGENT", "HIGH" -> RoseDanger
                            "MEDIUM" -> AmberWarning
                            else -> EmeraldGreen
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = call.summaryTitle,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = call.summaryIntent,
                fontSize = 12.sp,
                color = TextSecondary,
                maxLines = 2
            )
        }
    }
}

@Composable
fun QuickActionGrid(
    onInstructions: () -> Unit,
    onContacts: () -> Unit,
    onVivo: () -> Unit,
    onSettings: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActionTile(Modifier.weight(1f), "Custom Instructions", Icons.Default.Psychology, onInstructions)
            ActionTile(Modifier.weight(1f), "Contact Rules", Icons.Default.Contacts, onContacts)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActionTile(Modifier.weight(1f), "Vivo OriginOS Setup", Icons.Default.PowerSettingsNew, onVivo)
            ActionTile(Modifier.weight(1f), "Telecom & Voice", Icons.Default.Tune, onSettings)
        }
    }
}

@Composable
fun ActionTile(modifier: Modifier, label: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = modifier
            .border(1.dp, CardBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = VivoBlue, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
