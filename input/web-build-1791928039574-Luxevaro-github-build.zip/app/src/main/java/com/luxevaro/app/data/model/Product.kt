package com.luxevaro.app.data.model

data class Product(
    val id: String,
    val title: String,
    val category: String,
    val price: Double,
    val priceFormatted: String,
    val currency: String = "USD",
    val image: String,
    val url: String,
    val isFeatured: Boolean = false,
    val isNewArrival: Boolean = false,
    val description: String = ""
)
