package com.luxevaro.app.data.repository

import com.luxevaro.app.data.model.Product

object ProductRepository {
    const val STORE_URL = "https://luxevaro.wed2c.com"

    val categories = listOf(
        "Home & Kitchen",
        "Pet Supplies",
        "Beauty & Personal Care",
        "Mobile Accessories",
        "Car Accessories",
        "Fashion Accessories"
    )

    val products = listOf(
        Product(
            id = "lxv-1",
            title = "Chinese Herbal Bracelet",
            category = "Fashion Accessories",
            price = 33.72,
            priceFormatted = "$33.72",
            image = "https://cf.cjdropshipping.com/de2f9952-16ab-424f-8d74-cbfec9c46e58.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2602211723143225100&recommendProductId=2610130907000355500&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-2",
            title = "Soft And Comfortable Home Women\'s Nightdress",
            category = "Fashion Accessories",
            price = 17.67,
            priceFormatted = "$17.67",
            image = "https://oss-cf.cjdropshipping.com/product/2024/11/17/06/ed542aed-7e7e-4bd3-a5f0-a5ae124c8154.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2411171526150352700&recommendProductId=2610130935480324300&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-3",
            title = "Casual Hoodies Kangaroo Dog Pet Holder Carrier Big Pouch Sweatshirt",
            category = "Pet Supplies",
            price = 26.69,
            priceFormatted = "$26.69",
            image = "https://cf.cjdropshipping.com/quick/product/38f26cb3-5f8b-401e-a38e-655106a00910.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2606141215563209200&recommendProductId=2610130907340320200&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-4",
            title = "Home Bedroom HD Portable Video Player",
            category = "Home & Kitchen",
            price = 20.02,
            priceFormatted = "$20.02",
            image = "https://oss-cf.cjdropshipping.com/product/2024/08/14/07/ee78ccd4-06a1-4ef7-af4d-e33e774ff1b9_trans.jpeg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2503171211100326400&recommendProductId=2610130935570344800&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-5",
            title = "Dog Puzzle Feeder Interactive Pet Food Treat Dispenser Cartoon Duck",
            category = "Pet Supplies",
            price = 12.57,
            priceFormatted = "$12.57",
            image = "https://oss-cf.cjdropshipping.com/product/2025/05/26/07/e895da1c-f45f-48be-9179-0557b5fb2b28.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2505261714100326800&recommendProductId=2610130900160352500&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-6",
            title = "Home Electronic Clock with LED Time Display",
            category = "Home & Kitchen",
            price = 15.49,
            priceFormatted = "$15.49",
            image = "https://cf.cjdropshipping.com/20200226/190636993830.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=1658059119661301760&recommendProductId=2610130935300323100&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = false,
        ),
        Product(
            id = "lxv-7",
            title = "Outdoor Home Indoor Driving Mouse Ultrasonic Protection",
            category = "Home & Kitchen",
            price = 12.76,
            priceFormatted = "$12.76",
            image = "https://cf.cjdropshipping.com/quick/product/ff748a21-95dc-4d8b-8fe9-b00a043f2869.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2406181626230359100&recommendProductId=2610130935180329200&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-8",
            title = "Traditional Chinese Medicine Healing Bead Bracelet",
            category = "Fashion Accessories",
            price = 44.28,
            priceFormatted = "$44.28",
            image = "https://cf.cjdropshipping.com/b27a5744-6452-4a64-8dd7-9c636f5fcf58.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2603021839260353900&recommendProductId=2610130907130331600&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-9",
            title = "KP-227 Best-Selling In-Ear Bluetooth Earbuds Digital Battery Display",
            category = "Mobile Accessories",
            price = 20.64,
            priceFormatted = "$20.64",
            image = "https://cf.cjdropshipping.com/7e37fac8-1bbb-4b13-a632-73127788df92.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2607141751430343100&recommendProductId=2610130906450337600&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-10",
            title = "KP-226 Fabric-Wrapped Mini In-Ear Bluetooth Earbuds",
            category = "Mobile Accessories",
            price = 26.42,
            priceFormatted = "$26.42",
            image = "https://cf.cjdropshipping.com/8626f1cb-587a-464c-8d06-6c4028f6edec.png",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2607251751300339600&recommendProductId=2610130906340346200&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-11",
            title = "5-Seat Car Seat Cover Classic Luxury Timeless Design 2mm",
            category = "Car Accessories",
            price = 32.37,
            priceFormatted = "$32.37",
            image = "https://cf.cjdropshipping.com/58789521-d6f6-48a7-8249-dc8a9f70a328.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2608211006520322000&recommendProductId=2610130905170351600&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-12",
            title = "2 Front Car Seat Covers Digitally Printed Butterfly Pattern",
            category = "Car Accessories",
            price = 23.71,
            priceFormatted = "$23.71",
            image = "https://cf.cjdropshipping.com/d7dabc7e-f1ba-4572-9d5a-5c5556f9f900.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2608071012290332100&recommendProductId=2610130905420351300&hyId=kibt-fe-cj",
            isFeatured = false,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-13",
            title = "Cordless Wraparound Heated Vibration Massager LED Touch",
            category = "Beauty & Personal Care",
            price = 68.66,
            priceFormatted = "$68.66",
            image = "https://cf.cjdropshipping.com/205bc1fc-b72a-4ba1-8f2e-c1a3a46ad4d5.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2608261521220327300&recommendProductId=2610130905010336600&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = true,
        ),
        Product(
            id = "lxv-14",
            title = "Electric Gua Sha Board Beauty Meridian Cupping Massager",
            category = "Beauty & Personal Care",
            price = 33.78,
            priceFormatted = "$33.78",
            image = "https://oss-cf.cjdropshipping.com/product/2026/03/10/07/e17da40f-f35f-4efb-a910-38281e67a5d6.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2602252230050343300&recommendProductId=2610130904490345600&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = false,
        ),
        Product(
            id = "lxv-15",
            title = "Luxury Pet Car Safety Bed Multifunctional Travel Carrier",
            category = "Pet Supplies",
            price = 54.07,
            priceFormatted = "$54.07",
            image = "https://cf.cjdropshipping.com/quick/product/8325a7aa-9c64-4b17-91fd-2007aeb7f134.jpg",
            url = "https://luxevaro.wed2c.com/goodsDetails?jobsProductId=2409140635340346300&hyId=kibt-fe-cj",
            isFeatured = true,
            isNewArrival = false,
        )
    )

    fun getProductById(id: String): Product? = products.find { it.id == id }

    fun getProductsByCategory(category: String): List<Product> = 
        products.filter { it.category.equals(category, ignoreCase = true) }

    fun search(query: String): List<Product> =
        products.filter { it.title.contains(query.trim(), ignoreCase = true) || it.category.contains(query.trim(), ignoreCase = true) }

    fun getFeatured(): List<Product> = products.filter { it.isFeatured }
    fun getNewArrivals(): List<Product> = products.filter { it.isNewArrival }
}
