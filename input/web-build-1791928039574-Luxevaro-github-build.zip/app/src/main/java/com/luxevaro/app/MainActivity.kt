package com.luxevaro.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import com.luxevaro.app.data.model.Product
import com.luxevaro.app.data.repository.ProductRepository
import com.luxevaro.app.navigation.Screen
import com.luxevaro.app.theme.*
import com.luxevaro.app.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LuxevaroTheme {
                LuxevaroApp(
                    onOpenWebsite = { url -> openWebsite(url) }
                )
            }
        }
    }

    private fun openWebsite(url: String) {
        try {
            val customTabsIntent = CustomTabsIntent.Builder()
                .setShowTitle(true)
                .build()
            customTabsIntent.launchUrl(this, Uri.parse(url))
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(browserIntent)
        }
    }
}

@Composable
fun rememberIsOnline(): State<Boolean> {
    val context = LocalContext.current
    val cm = remember { context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager }
    val online = remember {
        mutableStateOf(
            cm.getNetworkCapabilities(cm.activeNetwork)
                ?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        )
    }
    DisposableEffect(cm) {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { online.value = true }
            override fun onLost(network: Network) { online.value = false }
        }
        cm.registerDefaultNetworkCallback(callback)
        onDispose { cm.unregisterNetworkCallback(callback) }
    }
    return online
}

@Composable
fun LuxevaroApp(
    onOpenWebsite: (String) -> Unit
) {
    val navController = rememberNavController()
    val isOnline by rememberIsOnline()
    val cartItems = remember { mutableStateListOf<Product>() }
    val wishlistItems = remember { mutableStateListOf<Product>() }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val isSplashScreen = currentRoute == Screen.Splash.route

    Scaffold(
        bottomBar = {
            if (!isSplashScreen) {
                NavigationBar(
                    containerColor = BackgroundDark,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentRoute == Screen.Home.route,
                        onClick = { navController.navigate(Screen.Home.route) { launchSingleTop = true } },
                        icon = { Icon(if (currentRoute == Screen.Home.route) Icons.Filled.Home else Icons.Outlined.Home, "Home") },
                        label = { Text("Home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GoldPrimary,
                            selectedTextColor = GoldPrimary,
                            indicatorColor = CardDark,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Categories.route,
                        onClick = { navController.navigate(Screen.Categories.route) { launchSingleTop = true } },
                        icon = { Icon(if (currentRoute == Screen.Categories.route) Icons.Filled.GridView else Icons.Outlined.GridView, "Categories") },
                        label = { Text("Categories") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GoldPrimary,
                            selectedTextColor = GoldPrimary,
                            indicatorColor = CardDark,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Wishlist.route,
                        onClick = { navController.navigate(Screen.Wishlist.route) { launchSingleTop = true } },
                        icon = { 
                            BadgedBox(badge = {
                                if (wishlistItems.isNotEmpty()) {
                                    Badge(containerColor = GoldPrimary, contentColor = BackgroundDark) {
                                        Text(wishlistItems.size.toString())
                                    }
                                }
                            }) {
                                Icon(if (currentRoute == Screen.Wishlist.route) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Wishlist")
                            }
                        },
                        label = { Text("Wishlist") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GoldPrimary,
                            selectedTextColor = GoldPrimary,
                            indicatorColor = CardDark,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                    NavigationBarItem(
                        selected = currentRoute == Screen.Cart.route,
                        onClick = { navController.navigate(Screen.Cart.route) { launchSingleTop = true } },
                        icon = { 
                            BadgedBox(badge = {
                                if (cartItems.isNotEmpty()) {
                                    Badge(containerColor = GoldPrimary, contentColor = BackgroundDark) {
                                        Text(cartItems.size.toString())
                                    }
                                }
                            }) {
                                Icon(if (currentRoute == Screen.Cart.route) Icons.Filled.ShoppingCart else Icons.Outlined.ShoppingCart, "Cart")
                            }
                        },
                        label = { Text("Cart") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GoldPrimary,
                            selectedTextColor = GoldPrimary,
                            indicatorColor = CardDark,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
        if (!isOnline) {
            Surface(color = SurfaceDark, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "No internet connection. Product images and the store need internet.",
                        modifier = Modifier.weight(1f),
                        color = ErrorRed,
                        fontSize = 12.sp
                    )
                    TextButton(onClick = { onOpenWebsite(ProductRepository.STORE_URL) }) {
                        Text("Open store", color = GoldPrimary)
                    }
                }
            }
        }
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.weight(1f)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(
                    onFinish = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }
            composable(Screen.Home.route) {
                HomeScreen(
                    navController = navController,
                    onProductClick = { product ->
                        navController.navigate(Screen.ProductDetails.createRoute(product.id))
                    },
                    onOpenWebsite = onOpenWebsite
                )
            }
            composable(Screen.Categories.route) {
                CategoriesScreen(
                    navController = navController,
                    onProductClick = { product ->
                        navController.navigate(Screen.ProductDetails.createRoute(product.id))
                    }
                )
            }
            composable(Screen.ProductDetails.route) { backStackEntry ->
                val productId = backStackEntry.arguments?.getString("productId") ?: ""
                val product = ProductRepository.getProductById(productId)
                if (product != null) {
                    ProductDetailsScreen(
                        product = product,
                        isInWishlist = wishlistItems.any { it.id == product.id },
                        onToggleWishlist = {
                            if (wishlistItems.any { it.id == product.id }) {
                                wishlistItems.removeAll { it.id == product.id }
                            } else {
                                wishlistItems.add(product)
                            }
                        },
                        onAddToCart = {
                            cartItems.add(product)
                        },
                        onBuyNow = {
                            onOpenWebsite(product.url)
                        },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
            composable(Screen.Cart.route) {
                CartScreen(
                    cartItems = cartItems,
                    onRemove = { product -> cartItems.remove(product) },
                    onCheckout = {
                        onOpenWebsite(ProductRepository.STORE_URL)
                    },
                    onBrowse = { navController.navigate(Screen.Home.route) }
                )
            }
            composable(Screen.Wishlist.route) {
                WishlistScreen(
                    wishlistItems = wishlistItems,
                    onRemove = { product -> wishlistItems.remove(product) },
                    onAddToCart = { product -> cartItems.add(product) },
                    onProductClick = { product ->
                        navController.navigate(Screen.ProductDetails.createRoute(product.id))
                    }
                )
            }
            composable(Screen.Contact.route) {
                ContactScreen(
                    onBack = { navController.popBackStack() },
                    onOpenWebsite = { onOpenWebsite(ProductRepository.STORE_URL) }
                )
            }
            composable(Screen.About.route) {
                AboutScreen(
                    onBack = { navController.popBackStack() },
                    onOpenWebsite = { onOpenWebsite(ProductRepository.STORE_URL) }
                )
            }
            composable(Screen.Shipping.route) {
                ShippingScreen(
                    onBack = { navController.popBackStack() },
                    onOpenWebsite = { onOpenWebsite(ProductRepository.STORE_URL) }
                )
            }
        }
        }
    }
}
